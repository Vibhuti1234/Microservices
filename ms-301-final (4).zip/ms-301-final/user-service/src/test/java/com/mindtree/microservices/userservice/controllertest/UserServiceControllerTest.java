package com.mindtree.microservices.userservice.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.microservices.userservice.controller.UserServiceController;
import com.mindtree.microservices.userservice.dto.BookingDto1;
import com.mindtree.microservices.userservice.dto.CustomerDto;
import com.mindtree.microservices.userservice.entity.Booking;
import com.mindtree.microservices.userservice.exception.UserServiceApplicationException;
import com.mindtree.microservices.userservice.proxy.MovieCatalogServiceProxy;
import com.mindtree.microservices.userservice.service.UserService;

@SpringBootTest
public class UserServiceControllerTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	private UserServiceController userServiceController;
	@Mock
	private UserService userService;
	@Mock
	private MovieCatalogServiceProxy movieCatalogServiceProxy;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(userServiceController).build();
	}

	@Test
	public void addingCustomerDetails() {
	    CustomerDto customerDto=new CustomerDto();

		customerDto.setEmail("kumarvibhuti8@gmail.com");
        customerDto.setUserName("Vibhuti123");
        Mockito.when(userService.addingCustomerDetails(Mockito.any())).thenReturn(customerDto);
        assertEquals("kumarvibhuti8@gmail.com", userServiceController.addingCustomerDetails(customerDto).getBody().getEmail());
        assertEquals("Vibhuti123", userServiceController.addingCustomerDetails(customerDto).getBody().getUserName());

	}

	@Test
	public void customerShowBookingTest() {
		String customerEmail = "kumarvibhuti8@gmail.com";

		int bookingId = 1;
		String message="booking successfull";
		
		try {
			Mockito.when(userService.customerShowBooking(Mockito.anyString(), Mockito.anyInt())).thenReturn(message);
		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			assertEquals("booking successfull",
					userServiceController.customerShowBooking(customerEmail, bookingId).getBody());
		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test
	public void fetchAllCustomersTest()
	{
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerdto = new CustomerDto();
		customerdto.setEmail("kumarvibhuti8@gmail.com");
		customerdto.setUserName("Vibhuti123");
		customerDtos.add(customerdto);
		try {
			Mockito.when(userService.fetchAllCustomers()).thenReturn(customerDtos);
		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("kumarvibhuti8@gmail.com", userServiceController.fetchAllCustomers().getBody().get(0).getEmail());
			assertEquals("Vibhuti123", userServiceController.fetchAllCustomers().getBody().get(0).getUserName());

		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	@Test
	public void fetchCustomerByEmailTest()
	{
		CustomerDto customerdto = new CustomerDto();
		customerdto.setEmail("kumarvibhuti8@gmail.com");
		customerdto.setUserName("Vibhuti123");
		try {
			Mockito.when(userService.fetchCustomerByEmail(Mockito.anyString())).thenReturn(customerdto);
		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("kumarvibhuti8@gmail.com", userServiceController.fetchCustomerByEmail("xyz").getBody().getEmail());
			assertEquals("Vibhuti123", userServiceController.fetchCustomerByEmail("xyz").getBody().getUserName());

		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	@Test
	public void fetchAllBookingsByCustomerEmailTest()
	{
		List<BookingDto1> bookings = new ArrayList<>();
		BookingDto1 booking = new BookingDto1();
		booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		bookings.add(booking);
		try {
			Mockito.when(userService.fetchAllBookingsByCustomerEmail(Mockito.anyString())).thenReturn(bookings);
		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(1, userServiceController.fetchAllBookingsByCustomerEmail("xyz").getBody().get(0).getBookingId());
			assertEquals(1123, userServiceController.fetchAllBookingsByCustomerEmail("xyz").getBody().get(0).getConfirmationNumber());

		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
