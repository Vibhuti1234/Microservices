package com.mindtree.microservices.userservice.dto;

public class BookingDto1 {
	private int bookingId;
	private int confirmationNumber;
	private String showId;

	public BookingDto1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingDto1(int bookingId, int confirmationNumber, String showId) {
		super();
		this.bookingId = bookingId;
		this.confirmationNumber = confirmationNumber;
		this.showId = showId;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getConfirmationNumber() {
		return confirmationNumber;
	}

	public void setConfirmationNumber(int confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

}
