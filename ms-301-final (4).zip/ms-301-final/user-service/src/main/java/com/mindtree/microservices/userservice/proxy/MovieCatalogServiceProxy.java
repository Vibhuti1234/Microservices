package com.mindtree.microservices.userservice.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.microservices.userservice.dto.BookingDto1;

@FeignClient(name = "booking-service", url = "localhost:8083")

public interface MovieCatalogServiceProxy {
	@GetMapping(value = "getBookingById/{bookingId}")
	public BookingDto1 getBookingById(@PathVariable int bookingId);

}
