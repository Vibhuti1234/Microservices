package com.mindtree.microservices.moviecatalogservice.exception;

public class NoSuchShowFoundException extends ServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchShowFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSuchShowFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
