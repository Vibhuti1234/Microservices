package com.mindtree.microservices.moviecatalogservice.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;

public class RestrictionsDto {
	private int restrictionId;
	private String foodAllowed;
	private int noOfBagsAllowed;
	@JsonIgnore
	private Theatre theatre;

	public RestrictionsDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RestrictionsDto(int restrictionId, String foodAllowed, int noOfBagsAllowed, Theatre theatre) {
		super();
		this.restrictionId = restrictionId;
		this.foodAllowed = foodAllowed;
		this.noOfBagsAllowed = noOfBagsAllowed;
		this.theatre = theatre;
	}

	/**
	 * @return the restrictionId
	 */
	public int getRestrictionId() {
		return restrictionId;
	}

	/**
	 * @param restrictionId the restrictionId to set
	 */
	public void setRestrictionId(int restrictionId) {
		this.restrictionId = restrictionId;
	}

	/**
	 * @return the foodAllowed
	 */
	public String getFoodAllowed() {
		return foodAllowed;
	}

	/**
	 * @param foodAllowed the foodAllowed to set
	 */
	public void setFoodAllowed(String foodAllowed) {
		this.foodAllowed = foodAllowed;
	}

	/**
	 * @return the noOfBagsAllowed
	 */
	public int getNoOfBagsAllowed() {
		return noOfBagsAllowed;
	}

	/**
	 * @param noOfBagsAllowed the noOfBagsAllowed to set
	 */
	public void setNoOfBagsAllowed(int noOfBagsAllowed) {
		this.noOfBagsAllowed = noOfBagsAllowed;
	}

	/**
	 * @return the theatre
	 */
	public Theatre getTheatre() {
		return theatre;
	}

	/**
	 * @param theatre the theatre to set
	 */
	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

}
