package com.mindtree.microservices.moviecatalogservice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.microservices.moviecatalogservice.entity.Review;

public class MovieDto {
	private String movieId;
	private String movieName;
	private String actors;
	private String plot;
	private int rating;
	private byte poster;
	@JsonIgnore
	private List<Review> reviews;

	public MovieDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MovieDto(String movieId, String movieName, String actors, String plot, int rating, byte poster,
			List<Review> reviews) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.actors = actors;
		this.plot = plot;
		this.rating = rating;
		this.poster = poster;
		this.reviews = reviews;
	}

	/**
	 * @return the movieId
	 */
	public String getMovieId() {
		return movieId;
	}

	/**
	 * @param movieId the movieId to set
	 */
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}

	/**
	 * @return the movieName
	 */
	public String getMovieName() {
		return movieName;
	}

	/**
	 * @param movieName the movieName to set
	 */
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	/**
	 * @return the actors
	 */
	public String getActors() {
		return actors;
	}

	/**
	 * @param actors the actors to set
	 */
	public void setActors(String actors) {
		this.actors = actors;
	}

	/**
	 * @return the plot
	 */
	public String getPlot() {
		return plot;
	}

	/**
	 * @param plot the plot to set
	 */
	public void setPlot(String plot) {
		this.plot = plot;
	}

	/**
	 * @return the rating
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * @param rating the rating to set
	 */
	public void setRating(int rating) {
		this.rating = rating;
	}

	/**
	 * @return the poster
	 */
	public byte getPoster() {
		return poster;
	}

	/**
	 * @param poster the poster to set
	 */
	public void setPoster(byte poster) {
		this.poster = poster;
	}

	/**
	 * @return the reviews
	 */
	public List<Review> getReviews() {
		return reviews;
	}

	/**
	 * @param reviews the reviews to set
	 */
	public void setReviews(List<Review> reviews) {
		this.reviews = reviews;
	}

}
