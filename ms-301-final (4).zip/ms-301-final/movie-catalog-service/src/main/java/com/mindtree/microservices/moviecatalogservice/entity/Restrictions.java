package com.mindtree.microservices.moviecatalogservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Restrictions {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int restrictionId;
	private String foodAllowed;
	private int noOfBagsAllowed;
	@OneToOne
	private Theatre theatre;
	public Restrictions() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Restrictions(int restrictionId, String foodAllowed, int noOfBagsAllowed, Theatre theatre) {
		super();
		this.restrictionId = restrictionId;
		this.foodAllowed = foodAllowed;
		this.noOfBagsAllowed = noOfBagsAllowed;
		this.theatre = theatre;
	}

	public int getRestrictionId() {
		return restrictionId;
	}
	public void setRestrictionId(int restrictionId) {
		this.restrictionId = restrictionId;
	}
	public String getFoodAllowed() {
		return foodAllowed;
	}
	public void setFoodAllowed(String foodAllowed) {
		this.foodAllowed = foodAllowed;
	}
	public int getNoOfBagsAllowed() {
		return noOfBagsAllowed;
	}
	public void setNoOfBagsAllowed(int noOfBagsAllowed) {
		this.noOfBagsAllowed = noOfBagsAllowed;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}
	

}
