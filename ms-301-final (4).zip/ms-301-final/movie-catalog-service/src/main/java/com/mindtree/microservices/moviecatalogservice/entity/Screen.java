package com.mindtree.microservices.moviecatalogservice.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Screen {
	@Id
	private String screenId;
	
	private String screenName;
	private String screentype;
	private int capacity;
	private int totalNoOfSeats;
	private int totalDamagedSeats;
	private int numberOfRows;
	@OneToMany(cascade=CascadeType.PERSIST)
	@JoinColumn(name="screen_id")
	private List<Shows> shows=new ArrayList<Shows>();

	
	public Screen() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Screen(String screenId, String screenName, String screentype, int capacity, int totalNoOfSeats,
			int totalDamagedSeats, int numberOfRows, List<Shows> shows) {
		super();
		this.screenId = screenId;
		this.screenName = screenName;
		this.screentype = screentype;
		this.capacity = capacity;
		this.totalNoOfSeats = totalNoOfSeats;
		this.totalDamagedSeats = totalDamagedSeats;
		this.numberOfRows = numberOfRows;
		this.shows = shows;
	}

	public List<Shows> getShows() {
		return shows;
	}

	public void setShows(List<Shows> shows) {
		this.shows = shows;
	}

	public String getScreenId() {
		return screenId;
	}


	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}


	public String getScreenName() {
		return screenName;
	}


	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}


	public String getScreentype() {
		return screentype;
	}


	public void setScreentype(String screentype) {
		this.screentype = screentype;
	}


	public int getCapacity() {
		return capacity;
	}


	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}


	

	public int getTotalNoOfSeats() {
		return totalNoOfSeats;
	}


	public void setTotalNoOfSeats(int totalNoOfSeats) {
		this.totalNoOfSeats = totalNoOfSeats;
	}


	public int getTotalDamagedSeats() {
		return totalDamagedSeats;
	}


	public void setTotalDamagedSeats(int totalDamagedSeats) {
		this.totalDamagedSeats = totalDamagedSeats;
	}


	public int getNumberOfRows() {
		return numberOfRows;
	}


	public void setNumberOfRows(int numberOfRows) {
		this.numberOfRows = numberOfRows;
	}


	
}
