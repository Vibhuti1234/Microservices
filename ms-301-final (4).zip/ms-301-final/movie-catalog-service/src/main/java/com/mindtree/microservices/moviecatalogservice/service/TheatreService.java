package com.mindtree.microservices.moviecatalogservice.service;

import java.util.List;

import com.mindtree.microservices.moviecatalogservice.dto.AddressDto;
import com.mindtree.microservices.moviecatalogservice.dto.RestrictionsDto;
import com.mindtree.microservices.moviecatalogservice.dto.TheatreDto;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;

public interface TheatreService {

	TheatreDto addTheatre(TheatreDto theatreDto);

	AddressDto assignAdressDetailsToTheatre(AddressDto addressDto, String theatreId)
			throws MovieCatalogServiceApplicationException;

	RestrictionsDto provideRestrictionToTheatre(RestrictionsDto restrictionsDto, String theatreId)
			throws MovieCatalogServiceApplicationException;

	List<TheatreDto> fetchAllTheaters() throws MovieCatalogServiceApplicationException;

	TheatreDto fetchTheaterById(String theatreId) throws MovieCatalogServiceApplicationException;

}
