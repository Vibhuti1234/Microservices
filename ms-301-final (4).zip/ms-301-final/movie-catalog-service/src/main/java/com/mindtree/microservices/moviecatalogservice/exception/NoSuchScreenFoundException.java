package com.mindtree.microservices.moviecatalogservice.exception;

public class NoSuchScreenFoundException extends ServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoSuchScreenFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchScreenFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public NoSuchScreenFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchScreenFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public NoSuchScreenFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
