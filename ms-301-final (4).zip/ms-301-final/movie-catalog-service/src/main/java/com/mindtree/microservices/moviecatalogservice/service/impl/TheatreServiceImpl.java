package com.mindtree.microservices.moviecatalogservice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.microservices.moviecatalogservice.dto.AddressDto;
import com.mindtree.microservices.moviecatalogservice.dto.RestrictionsDto;
import com.mindtree.microservices.moviecatalogservice.dto.TheatreDto;
import com.mindtree.microservices.moviecatalogservice.entity.Address;
import com.mindtree.microservices.moviecatalogservice.entity.Restrictions;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.TheatreRepository;
import com.mindtree.microservices.moviecatalogservice.service.TheatreService;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class TheatreServiceImpl implements TheatreService {
	@Autowired
	private TheatreRepository theatreRepository;
	Logger logger = Logger.getLogger(TheatreServiceImpl.class.getName());

	ModelMapper modelMapper = new ModelMapper();

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public TheatreDto addTheatre(TheatreDto theatreDto) {
		// TODO Auto-generated method stub
		Theatre theatre = convertDtoToEntity(theatreDto);
		theatreRepository.save(theatre);
		return theatreDto;
	}

	private Theatre convertDtoToEntity(TheatreDto theatreDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(theatreDto, Theatre.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public AddressDto assignAdressDetailsToTheatre(AddressDto addressDto, String theatreId)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no theatre of such Id then it will throw no theatre found exception");
		Theatre theatre = theatreRepository.findAll().stream().filter(i -> i.getTheatreId().equals(theatreId)).findAny()
				.orElseThrow(() -> new NoSuchTheatreFoundException("No Theatre Found of this Id:"));
		Address address = convertDtoToEntity(addressDto);
		address.setTheatre(theatre);
		theatre.setAddress(address);
		theatreRepository.saveAndFlush(theatre);
		return addressDto;
	}

	private Address convertDtoToEntity(AddressDto addressDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(addressDto, Address.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public RestrictionsDto provideRestrictionToTheatre(RestrictionsDto restrictionsDto, String theatreId)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no theatre of such Id then it will throw no theatre found exception");
		Theatre theatre = theatreRepository.findAll().stream().filter(i -> i.getTheatreId().equals(theatreId)).findAny()
				.orElseThrow(() -> new NoSuchTheatreFoundException("No Theatre Found of this Id:"));
		Restrictions restrictions = convertDtoToEntity(restrictionsDto);
		theatre.setRestrictions(restrictions);
		restrictions.setTheatre(theatre);
		theatreRepository.saveAndFlush(theatre);

		return restrictionsDto;
	}

	private Restrictions convertDtoToEntity(RestrictionsDto restrictionsDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(restrictionsDto, Restrictions.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<TheatreDto> fetchAllTheaters() throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no theatre in database then it will throw no theatre found exception");

		if (theatreRepository.findAll().isEmpty() || theatreRepository.findAll() == null) {
			throw new NoSuchTheatreFoundException("No theatre found");
		}
		List<TheatreDto> theatreDtos = new ArrayList<TheatreDto>();
		theatreDtos = theatreRepository.findAll().stream().map(entity -> convertEntityToDto(entity))
				.collect(Collectors.toList());
		return theatreDtos;
	}

	private TheatreDto convertEntityToDto(Theatre entity) {
		// TODO Auto-generated method stub
		return modelMapper.map(entity, TheatreDto.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public TheatreDto fetchTheaterById(String theatreId) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning(
				"if there is no theatre of such Id in database then it will throw no such  theatre found exception");
		Theatre theatre = theatreRepository.findAll().stream().filter(i -> i.getTheatreId().equals(theatreId)).findAny()
				.orElseThrow(() -> new NoSuchTheatreFoundException("No theater available of such id"));
		return convertEntityToDto(theatre);
	}

}
