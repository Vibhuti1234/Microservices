package com.mindtree.microservices.moviecatalogservice.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.microservices.moviecatalogservice.controller.MovieCatalogServiceApplicationController;
import com.mindtree.microservices.moviecatalogservice.dto.AddressDto;
import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.RestrictionsDto;
import com.mindtree.microservices.moviecatalogservice.dto.ReviewDto;
import com.mindtree.microservices.moviecatalogservice.dto.ScreenDto;
import com.mindtree.microservices.moviecatalogservice.dto.ShowsDto;
import com.mindtree.microservices.moviecatalogservice.dto.TheatreDto;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.service.MovieService;
import com.mindtree.microservices.moviecatalogservice.service.ScreenService;
import com.mindtree.microservices.moviecatalogservice.service.ShowService;
import com.mindtree.microservices.moviecatalogservice.service.TheatreService;

@SpringBootTest
public class MovieCatalogServiceApplicationControllerTest {

	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	private MovieCatalogServiceApplicationController movieCatalogServiceApplicationController;
	@Mock
	private TheatreService theatreService;
	@Mock
	private MovieService movieService;
	@Mock
	private ShowService showService;
	@Mock
	private ScreenService screenService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(movieCatalogServiceApplicationController).build();
	}

	@Test
	public void addTheatreTest() {
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setNoOfScreens(4);
		theatreDto.setTheatreName("Theatre1");
		Mockito.when(theatreService.addTheatre(theatreDto)).thenReturn(theatreDto);
		assertEquals(200, movieCatalogServiceApplicationController.addTheatre(theatreDto).getStatusCodeValue());
		assertNotEquals(404, movieCatalogServiceApplicationController.addTheatre(theatreDto).getStatusCodeValue());
		assertEquals(HttpStatus.OK, movieCatalogServiceApplicationController.addTheatre(theatreDto).getStatusCode());
		assertNotEquals(HttpStatus.BAD_REQUEST,
				movieCatalogServiceApplicationController.addTheatre(theatreDto).getStatusCode());
		assertEquals("T1",
				movieCatalogServiceApplicationController.addTheatre(theatreDto).getBody().getData().getTheatreId());
		assertEquals("Theatre1",
				movieCatalogServiceApplicationController.addTheatre(theatreDto).getBody().getData().getTheatreName());
	}

	@Test
	public void assignAdressDetailsToTheatreTest() {
		String theatreId = "T1";
		AddressDto addressDto = new AddressDto();
		addressDto.setAddressId("A1");
		addressDto.setCity("Kol");
		addressDto.setLatitude(30);
		addressDto.setState("WB");
		try {
			Mockito.when(theatreService.assignAdressDetailsToTheatre(addressDto, theatreId)).thenReturn(addressDto);
		} catch (MovieCatalogServiceApplicationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			assertEquals("A1", movieCatalogServiceApplicationController
					.assignAdressDetailsToTheatre(addressDto, theatreId).getBody().getData().getAddressId());
			assertEquals(200, movieCatalogServiceApplicationController
					.assignAdressDetailsToTheatre(addressDto, theatreId).getStatusCodeValue());
			assertNotEquals(HttpStatus.BAD_REQUEST, movieCatalogServiceApplicationController
					.assignAdressDetailsToTheatre(addressDto, theatreId).getStatusCode());
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void provideRestrictionToTheatreTest() {
		String theatreId = "T1";
		RestrictionsDto restrictionsDto = new RestrictionsDto();
		restrictionsDto.setFoodAllowed("chips and popcorn");
		restrictionsDto.setRestrictionId(1);
		restrictionsDto.setNoOfBagsAllowed(4);
		try {
			Mockito.when(theatreService.provideRestrictionToTheatre(restrictionsDto, theatreId))
					.thenReturn(restrictionsDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(1, movieCatalogServiceApplicationController
					.provideRestrictionToTheatre(restrictionsDto, theatreId).getBody().getData().getRestrictionId());
			assertNotEquals(2, movieCatalogServiceApplicationController
					.provideRestrictionToTheatre(restrictionsDto, theatreId).getBody().getData().getRestrictionId());
			assertEquals(4, movieCatalogServiceApplicationController
					.provideRestrictionToTheatre(restrictionsDto, theatreId).getBody().getData().getNoOfBagsAllowed());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void allocateScreensToTheatreTest() {
		String theatreId = "T1";
		ScreenDto screenDto = new ScreenDto();
		screenDto.setCapacity(4);
		screenDto.setScreenId("S1");
		try {
			Mockito.when(screenService.allocateScreensToTheatre(screenDto, theatreId)).thenReturn(screenDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("S1", movieCatalogServiceApplicationController.allocateScreensToTheatre(screenDto, theatreId)
					.getBody().getData().getScreenId());
			assertNotEquals("S2", movieCatalogServiceApplicationController
					.allocateScreensToTheatre(screenDto, theatreId).getBody().getData().getScreenId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void addShowsTest() {
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		Mockito.when(showService.addShows(showsDto)).thenReturn(showsDto);
		assertEquals("S1", movieCatalogServiceApplicationController.addShows(showsDto).getBody().getData().getShowId());
		assertNotEquals("S2",
				movieCatalogServiceApplicationController.addShows(showsDto).getBody().getData().getShowId());

	}

	@Test
	public void assignShowsToTheatreTest() {
		String showId = "S1";
		String screenId = "S1";
		String theatreId = "T1";
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(2);
		try {
			Mockito.when(showService.assignShowsToTheatre(showId, screenId, theatreId)).thenReturn(showsDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("S1", movieCatalogServiceApplicationController
					.assignShowsToTheatre(showId, screenId, theatreId).getBody().getData().getShowId());
			assertNotEquals("S2", movieCatalogServiceApplicationController
					.assignShowsToTheatre(showId, screenId, theatreId).getBody().getData().getShowId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void assignMoviesToTheatreTest() {
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("KFG");
		String showId = "S1";
		String theatreId = "T1";
		try {
			Mockito.when(showService.assignMoviesToTheatre(movieDto, showId, theatreId)).thenReturn(movieDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("M1", movieCatalogServiceApplicationController
					.assignMoviesToTheatre(movieDto, showId, theatreId).getBody().getData().getMovieId());
			assertNotEquals("M2", movieCatalogServiceApplicationController
					.assignMoviesToTheatre(movieDto, showId, theatreId).getBody().getData().getMovieId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void addReviewsToMoviesTest() {
		ReviewDto reviewDto = new ReviewDto();
		reviewDto.setReviewerId("R1");
		reviewDto.setReviewDetails("very good movie");
		String movieId = "M1";
		try {
			Mockito.when(movieService.addReviewsToMovies(reviewDto, movieId)).thenReturn(reviewDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("R1", movieCatalogServiceApplicationController.addReviewsToMovies(reviewDto, movieId).getBody()
					.getData().getReviewerId());
			assertNotEquals("very bad movie", movieCatalogServiceApplicationController
					.addReviewsToMovies(reviewDto, movieId).getBody().getData().getReviewDetails());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void getAllShowsTest() {
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(2);
		List<ShowsDto> showsDtos = new ArrayList<ShowsDto>();
		showsDtos.add(showsDto);
		try {
			Mockito.when(showService.getAllShows()).thenReturn(showsDtos);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("S1",
					movieCatalogServiceApplicationController.getAllShows().getBody().getData().get(0).getShowId());
			assertNotEquals("S2",
					movieCatalogServiceApplicationController.getAllShows().getBody().getData().get(0).getShowId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void getShowByIdTest() {
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(2);
		String showId = "S1";
		try {
			Mockito.when(showService.getShowById(showId)).thenReturn(showsDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("S1",
					movieCatalogServiceApplicationController.getShowById(showId).getBody().getData().getShowId());
			assertNotEquals("S2",
					movieCatalogServiceApplicationController.getShowById(showId).getBody().getData().getShowId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void fetchAllMoviesTest() {
		List<MovieDto> movieDtos = new ArrayList<>();
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("KFG");
		movieDtos.add(movieDto);
		try {
			Mockito.when(movieService.fetchAllMovies()).thenReturn(movieDtos);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("M1",
					movieCatalogServiceApplicationController.fetchAllMovies().getBody().getData().get(0).getMovieId());
			assertNotEquals("M2",
					movieCatalogServiceApplicationController.fetchAllMovies().getBody().getData().get(0).getMovieId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void fetchAllTheatersTest() {
		List<TheatreDto> theatreDtos = new ArrayList<>();
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		theatreDtos.add(theatreDto);
		try {
			Mockito.when(theatreService.fetchAllTheaters()).thenReturn(theatreDtos);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("T1", movieCatalogServiceApplicationController.fetchAllTheaters().getBody().getData().get(0)
					.getTheatreId());
			assertNotEquals("T2", movieCatalogServiceApplicationController.fetchAllTheaters().getBody().getData().get(0)
					.getTheatreId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void fetchMovieByIdTest() {
		String movieId = "M1";
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("KFG");
		try {
			Mockito.when(movieService.fetchMovieById(movieId)).thenReturn(movieDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("M1",
					movieCatalogServiceApplicationController.fetchMovieById(movieId).getBody().getData().getMovieId());
			assertNotEquals("M2",
					movieCatalogServiceApplicationController.fetchMovieById(movieId).getBody().getData().getMovieId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void fetchTheaterByIdTest() {
		String theatreId = "T1";
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		try {
			Mockito.when(theatreService.fetchTheaterById(theatreId)).thenReturn(theatreDto);
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals("T1", movieCatalogServiceApplicationController.fetchTheaterById(theatreId).getBody().getData()
					.getTheatreId());
			assertNotEquals("T2", movieCatalogServiceApplicationController.fetchTheaterById(theatreId).getBody()
					.getData().getTheatreId());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
