package com.mindtree.microservices.moviecatalogservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.moviecatalogservice.dto.ScreenDto;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;
import com.mindtree.microservices.moviecatalogservice.exception.CapacityFullException;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.AddressRepository;
import com.mindtree.microservices.moviecatalogservice.repository.MovieRepository;
import com.mindtree.microservices.moviecatalogservice.repository.RestrictionsRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ReviewRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ScreenRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ShowsRepository;
import com.mindtree.microservices.moviecatalogservice.repository.TheatreRepository;
import com.mindtree.microservices.moviecatalogservice.service.impl.ScreenServiceImpl;

@SpringBootTest
public class ScreenServiceImplTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	ScreenServiceImpl screenServiceImpl;
	@Mock
	AddressRepository addressRepository;
	
	@Mock
	MovieRepository movieRepository;
	@Mock
	RestrictionsRepository restrictionsRepository;
	@Mock
	ReviewRepository reviewRepository;
	@Mock 
	ScreenRepository screenRepository;
	@Mock
	ShowsRepository showsRepository;
	@Mock
	TheatreRepository theatreRepository;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(screenServiceImpl).build();
	}
	@Test
	public void allocateScreensToTheatreTest() throws MovieCatalogServiceApplicationException
	{   ScreenDto screenDto=new ScreenDto();
	screenDto.setScreenId("S1");
	screenDto.setScreenName("Screen1");
	screenDto.setScreentype("3D");
	screenDto.setCapacity(10);
	screenDto.setNumberOfRows(10);
	Theatre theatre=new Theatre();
    theatre.setTheatreId("T1");
    theatre.setTheatreName("Theatre1");
    theatre.setNoOfScreens(2);
	String theatreId="T1";
	List<Theatre> theatres=new ArrayList<Theatre>();
	theatres.add(theatre);

	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
	assertEquals(10, screenServiceImpl.allocateScreensToTheatre(screenDto, theatreId).getCapacity());
	

	
		
	}
	@Test(expected=NoSuchTheatreFoundException.class)
	public void allocateScreensToTheatreTestForException() throws MovieCatalogServiceApplicationException
	{   ScreenDto screenDto=new ScreenDto();
	screenDto.setScreenId("S1");
	screenDto.setScreenName("Screen1");
	screenDto.setScreentype("3D");
	screenDto.setCapacity(10);
	screenDto.setNumberOfRows(10);
	Theatre theatre=new Theatre();
    theatre.setTheatreId("T1");
    theatre.setTheatreName("Theatre1");
    theatre.setNoOfScreens(2);
	String theatreId="T2";
	List<Theatre> theatres=new ArrayList<Theatre>();
	theatres.add(theatre);

	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
	 screenServiceImpl.allocateScreensToTheatre(screenDto, theatreId);	
	}
	@Test(expected=CapacityFullException.class)
	public void allocateScreensToTheatreTestForCapacityException() throws MovieCatalogServiceApplicationException
	{   ScreenDto screenDto=new ScreenDto();
	screenDto.setScreenId("S1");
	screenDto.setScreenName("Screen1");
	screenDto.setScreentype("3D");
	screenDto.setCapacity(10);
	screenDto.setNumberOfRows(10);
	Theatre theatre=new Theatre();
    theatre.setTheatreId("T1");
    theatre.setTheatreName("Theatre1");
    theatre.setNoOfScreens(0);
	String theatreId="T1";
	List<Theatre> theatres=new ArrayList<Theatre>();
	theatres.add(theatre);

	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
 screenServiceImpl.allocateScreensToTheatre(screenDto, theatreId);	
	}
	@Test(expected=CapacityFullException.class)
	public void allocateScreensToTheatreTestForCapacityEXception2() throws MovieCatalogServiceApplicationException
	{   ScreenDto screenDto=new ScreenDto();
	screenDto.setScreenId("S1");
	screenDto.setScreenName("Screen1");
	screenDto.setScreentype("3D");
	screenDto.setCapacity(10);
	screenDto.setNumberOfRows(10);
	Theatre theatre=new Theatre();
    theatre.setTheatreId("T1");
    theatre.setTheatreName("Theatre1");
    theatre.setNoOfScreens(-1);
	String theatreId="T1";
	List<Theatre> theatres=new ArrayList<Theatre>();
	theatres.add(theatre);

	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
	 screenServiceImpl.allocateScreensToTheatre(screenDto, theatreId);
	

	
		
	}
}
