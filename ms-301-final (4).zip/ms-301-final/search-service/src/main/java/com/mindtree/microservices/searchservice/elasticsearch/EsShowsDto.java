package com.mindtree.microservices.searchservice.elasticsearch;

import javax.persistence.Id;

import org.springframework.data.elasticsearch.annotations.Document;

import com.mindtree.microservices.searchservice.dto.ShowsDto;

@Document(indexName="shows",type="shows")
public class EsShowsDto {
	@Id
	private String id;
	private String showId;
	private String timings;
	private String duration;
	
	private int totalNoOfSeats;
	private int totalBookedSeats;
	private int totalFreeSeats;
	private int totalDamagedSeats;
	private int numberOfRows;
	public EsShowsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EsShowsDto(String id, String showId, String timings, String duration, int totalNoOfSeats,
			int totalBookedSeats, int totalFreeSeats, int totalDamagedSeats, int numberOfRows) {
		
		this.id = id;
		this.showId = showId;
		this.timings = timings;
		this.duration = duration;
		this.totalNoOfSeats = totalNoOfSeats;
		this.totalBookedSeats = totalBookedSeats;
		this.totalFreeSeats = totalFreeSeats;
		this.totalDamagedSeats = totalDamagedSeats;
		this.numberOfRows = numberOfRows;
	}
	public EsShowsDto(ShowsDto showsDto) {
	
		this.id = showsDto.getShowId();
		this.showId = showsDto.getShowId();
		this.timings = showsDto.getTimings();
		this.duration = showsDto.getDuration();
		this.totalNoOfSeats = showsDto.getTotalNoOfSeats();
		this.totalBookedSeats = showsDto.getTotalBookedSeats();
		this.totalFreeSeats = showsDto.getTotalFreeSeats();
		this.totalDamagedSeats = showsDto.getTotalDamagedSeats();
		this.numberOfRows = showsDto.getNumberOfRows();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public int getTotalNoOfSeats() {
		return totalNoOfSeats;
	}
	public void setTotalNoOfSeats(int totalNoOfSeats) {
		this.totalNoOfSeats = totalNoOfSeats;
	}
	public int getTotalBookedSeats() {
		return totalBookedSeats;
	}
	public void setTotalBookedSeats(int totalBookedSeats) {
		this.totalBookedSeats = totalBookedSeats;
	}
	public int getTotalFreeSeats() {
		return totalFreeSeats;
	}
	public void setTotalFreeSeats(int totalFreeSeats) {
		this.totalFreeSeats = totalFreeSeats;
	}
	public int getTotalDamagedSeats() {
		return totalDamagedSeats;
	}
	public void setTotalDamagedSeats(int totalDamagedSeats) {
		this.totalDamagedSeats = totalDamagedSeats;
	}
	public int getNumberOfRows() {
		return numberOfRows;
	}
	public void setNumberOfRows(int numberOfRows) {
		this.numberOfRows = numberOfRows;
	}
	
	
}
