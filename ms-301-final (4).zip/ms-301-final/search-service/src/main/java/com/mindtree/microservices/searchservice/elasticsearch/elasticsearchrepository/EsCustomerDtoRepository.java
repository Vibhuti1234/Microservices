package com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.microservices.searchservice.elasticsearch.EsCustomerDto;

@Repository
public interface EsCustomerDtoRepository  extends ElasticsearchRepository<EsCustomerDto,String>{
	

}
