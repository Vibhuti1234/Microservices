package com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.ElasticSearchServiceController;
import com.mindtree.microservices.searchservice.dto.ErrorDto;
import com.mindtree.microservices.searchservice.exception.ServiceException;
@RestControllerAdvice(assignableTypes= {ElasticSearchServiceController.class})
public class ElasticSearchControllerExceptionHandler {
	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<ErrorDto> serviceExceptionHandler(Exception e, Throwable cause){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorDto(e.getMessage(), cause));
	}
}
