package com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchBookingDto;
@Repository
public interface ElasticSearchBookingDtoRepository extends ElasticsearchRepository<ElasticSearchBookingDto,String> {

}
