package com.mindtree.microservices.searchservice.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class BookingDto {

	private int bookingId;
	private int confirmationNumber;
	@JsonIgnore
	private ShowsDto shows;
	public BookingDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public BookingDto(int bookingId, int confirmationNumber, ShowsDto shows) {
		super();
		this.bookingId = bookingId;
		this.confirmationNumber = confirmationNumber;
		this.shows = shows;
	}

	/**
	 * @return the bookingId
	 */
	public int getBookingId() {
		return bookingId;
	}
	/**
	 * @param bookingId the bookingId to set
	 */
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	/**
	 * @return the confirmationNumber
	 */
	public int getConfirmationNumber() {
		return confirmationNumber;
	}
	/**
	 * @param confirmationNumber the confirmationNumber to set
	 */
	public void setConfirmationNumber(int confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

	public ShowsDto getShows() {
		return shows;
	}

	public void setShows(ShowsDto shows) {
		this.shows = shows;
	}
	
	
	
}
