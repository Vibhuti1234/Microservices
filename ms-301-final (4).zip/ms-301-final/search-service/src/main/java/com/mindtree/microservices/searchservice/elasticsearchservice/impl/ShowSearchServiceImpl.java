package com.mindtree.microservices.searchservice.elasticsearchservice.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.ElasticSearchServiceController;
import com.mindtree.microservices.searchservice.dto.ShowsDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsCustomerDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsShowsDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.EsShowsDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.ShowSearchService;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoShowsFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchShowFoundException;
import com.mindtree.microservices.searchservice.proxy.SearchServiceProxy;

@Service
public class ShowSearchServiceImpl implements ShowSearchService{
	private static Logger logger = LogManager.getLogger(ElasticSearchServiceController.class);

   @Autowired
   private EsShowsDtoRepository esShowsDtoRepository;
   @Autowired
   private SearchServiceProxy searchServiceProxy;
	@Override
	public Iterable<EsShowsDto> fetchAllShows() throws MovieCatalogServiceApplicationException {
		// TODO o-generated method stub
		List<ShowsDto> showsDtos=searchServiceProxy.getAllShows().getBody().getData();
		if(showsDtos.isEmpty() || showsDtos==null)
		{
			throw new NoShowsFoundException("No shows details found!");
		}
		for (ShowsDto showsDto : showsDtos) {
			esShowsDtoRepository.save(new EsShowsDto(showsDto));
			
		}
		return esShowsDtoRepository.findAll();
	}
	@Override
	public EsShowsDto fetchShowById(String showId) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<ShowsDto> showsDtos=searchServiceProxy.getAllShows().getBody().getData();
		if(showsDtos.isEmpty() || showsDtos==null)
		{
			throw new NoShowsFoundException("No shows details found!");
		}
		for (ShowsDto showsDto : showsDtos) {
			esShowsDtoRepository.save(new EsShowsDto(showsDto));
			
		}
		logger.warn("if No such show id  found then it will throw  NoSuchShowFoundException!");

		EsShowsDto esShowsDto=esShowsDtoRepository.findById(showId).orElseThrow(()->new NoSuchShowFoundException("No Such Show Found"));
		return esShowsDto;
	}

}
