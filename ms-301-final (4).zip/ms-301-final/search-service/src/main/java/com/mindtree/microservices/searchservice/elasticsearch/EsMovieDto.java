package com.mindtree.microservices.searchservice.elasticsearch;

import javax.persistence.Id;

import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.elasticsearch.annotations.Document;

import com.mindtree.microservices.searchservice.dto.MovieDto;
@Document(indexName="movie",type="movie")
public class EsMovieDto {
	@Id
	private String id;
	private String movieId;
	private String movieName;
	private String actors;
	private String plot;
	private int rating;
	private byte poster;
	public EsMovieDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@PersistenceConstructor
	public EsMovieDto(String id, String movieId, String movieName, String actors, String plot, int rating,
			byte poster) {

		this.id = id;
		this.movieId = movieId;
		this.movieName = movieName;
		this.actors = actors;
		this.plot = plot;
		this.rating = rating;
		this.poster = poster;
	}
	public EsMovieDto(MovieDto movieDto) {
	
		this.id = movieDto.getMovieId();
		this.movieId = movieDto.getMovieId();
		this.movieName = movieDto.getMovieName();
		this.actors = movieDto.getActors();
		this.plot = movieDto.getPlot();
		this.rating = movieDto.getRating();
		this.poster = movieDto.getPoster();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMovieId() {
		return movieId;
	}
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getActors() {
		return actors;
	}
	public void setActors(String actors) {
		this.actors = actors;
	}
	public String getPlot() {
		return plot;
	}
	public void setPlot(String plot) {
		this.plot = plot;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public byte getPoster() {
		return poster;
	}
	public void setPoster(byte poster) {
		this.poster = poster;
	}
	

}
