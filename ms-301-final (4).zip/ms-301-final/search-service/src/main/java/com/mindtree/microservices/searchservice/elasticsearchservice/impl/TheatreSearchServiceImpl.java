package com.mindtree.microservices.searchservice.elasticsearchservice.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.ElasticSearchServiceController;
import com.mindtree.microservices.searchservice.dto.TheatreDto;
import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchTheatreDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.ElasticSearchTheatreDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.TheatreSearchService;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.searchservice.exception.NoTheatreFoundException;
import com.mindtree.microservices.searchservice.proxy.SearchServiceProxy;

@Service
public class TheatreSearchServiceImpl implements TheatreSearchService {
	int count = 0;
	private static Logger logger = LogManager.getLogger(ElasticSearchServiceController.class);
	@Autowired
	private SearchServiceProxy searchServiceProxy;
	@Autowired
	private ElasticSearchTheatreDtoRepository elasticSearchTheatreDtoRepository;

	@Override
	public Iterable<ElasticSearchTheatreDto> fetchAllTheatre() throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<TheatreDto> theatreDtos = searchServiceProxy.fetchAllTheaters().getBody().getData();
		if (theatreDtos == null || theatreDtos.isEmpty()) {
			throw new NoTheatreFoundException("No theatre found");
		}

		for (TheatreDto theatreDto2 : theatreDtos) {

			elasticSearchTheatreDtoRepository.save(new ElasticSearchTheatreDto(theatreDto2));
		}

		return elasticSearchTheatreDtoRepository.findAll();

	}

	@Override
	public ElasticSearchTheatreDto fetchTheatreById(String theatreId) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<TheatreDto> theatreDtos = searchServiceProxy.fetchAllTheaters().getBody().getData();
		if (theatreDtos == null || theatreDtos.isEmpty()) {
			throw new NoTheatreFoundException("No theatre found");
		}
		for (TheatreDto theatreDto2 : theatreDtos) {

			elasticSearchTheatreDtoRepository.save(new ElasticSearchTheatreDto(theatreDto2));
		}
		logger.warn("if No such theatre id  found then it will throw  NoSuchTheatreFoundException!");

		ElasticSearchTheatreDto elasticSearchTheatreDto = elasticSearchTheatreDtoRepository.findById(theatreId)
				.orElseThrow(() -> new NoSuchTheatreFoundException("No such theatre exists"));
		return elasticSearchTheatreDto;
	}

	@Override
	public List<ElasticSearchTheatreDto> fetchTheatreByName(String name)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<TheatreDto> theatreDtos = searchServiceProxy.fetchAllTheaters().getBody().getData();
		if (theatreDtos == null || theatreDtos.isEmpty()) {
			throw new NoTheatreFoundException("No theatre found!");
		}
		for (TheatreDto theatreDto2 : theatreDtos) {

			elasticSearchTheatreDtoRepository.save(new ElasticSearchTheatreDto(theatreDto2));
		}
		List<ElasticSearchTheatreDto> esElasticSearchTheatreDtos = elasticSearchTheatreDtoRepository
				.searchTheatreByName(name);
		if (esElasticSearchTheatreDtos.isEmpty() || esElasticSearchTheatreDtos == null) {
			throw new NoTheatreFoundException("No theatre found!");
		}
		return esElasticSearchTheatreDtos;
	}

}
