package com.mindtree.microservices.searchservice.elasticsearchservice.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.ElasticSearchServiceController;
import com.mindtree.microservices.searchservice.dto.MovieDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsMovieDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.EsMovieDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.MovieSearchService;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoMovieFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchMovieFoundException;
import com.mindtree.microservices.searchservice.proxy.SearchServiceProxy;
@Service
public class MovieSearchServiceImpl implements MovieSearchService{
	private static Logger logger = LogManager.getLogger(ElasticSearchServiceController.class);

@Autowired
private EsMovieDtoRepository esMovieDtoRepository;
@Autowired
private SearchServiceProxy searchServiceProxy;
@Override
public Iterable<EsMovieDto> fetchAllMovies() throws MovieCatalogServiceApplicationException {
	// TODO Auto-generated method stub
	List<MovieDto> movieDtos=searchServiceProxy.fetchAllMovies().getBody().getData();
	if(movieDtos.isEmpty() || movieDtos==null)
	{
		throw new NoMovieFoundException("No movie details available!");
	}
	for (MovieDto movieDto : movieDtos) {
		 esMovieDtoRepository.save(new EsMovieDto(movieDto));
	}
	return esMovieDtoRepository.findAll();
}
@Override
public EsMovieDto fetchMovieById(String movieId) throws MovieCatalogServiceApplicationException {
	// TODO Auto-generated method stub
	List<MovieDto> movieDtos=searchServiceProxy.fetchAllMovies().getBody().getData();
	if(movieDtos.isEmpty() || movieDtos==null)
	{
		throw new NoMovieFoundException("No movie details available!");
	}
	for (MovieDto movieDto : movieDtos) {
		 esMovieDtoRepository.save(new EsMovieDto(movieDto));
	}
	logger.warn("if No such movie id  found then it will throw  NoSuchMovieFoundException!");

	EsMovieDto esMovieDto =esMovieDtoRepository.findById(movieId).orElseThrow(()->new NoSuchMovieFoundException("No such movie details available"));
	return esMovieDto;
}

}
