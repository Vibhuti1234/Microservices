package com.mindtree.microservices.searchservice.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.microservices.searchservice.dto.BookingDto;
import com.mindtree.microservices.searchservice.dto.CustomerDto;
import com.mindtree.microservices.searchservice.dto.MovieDto;
import com.mindtree.microservices.searchservice.dto.ResponseDto;
import com.mindtree.microservices.searchservice.dto.ShowsDto;
import com.mindtree.microservices.searchservice.dto.TheatreDto;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;

@FeignClient(name="movie-catalog-service")
public interface SearchServiceProxy {
	@GetMapping(value="getAllShows")
	public ResponseEntity<ResponseDto<List<ShowsDto>>> getAllShows()  throws MovieCatalogServiceApplicationException; 
	@GetMapping(value="getShowById/{showId}")
	public ResponseEntity<ResponseDto<ShowsDto>> getShowById(@PathVariable("showId") String showId)  throws MovieCatalogServiceApplicationException ;
	@GetMapping(value="fetchAllMovies")
	public ResponseEntity<ResponseDto<List<MovieDto>>> fetchAllMovies() throws MovieCatalogServiceApplicationException;
	@GetMapping(value="fetchAllTheaters")
	public ResponseEntity<ResponseDto<List<TheatreDto>>> fetchAllTheaters() throws MovieCatalogServiceApplicationException;
	@GetMapping(value="fetchMovieById/{movieId}")
	public ResponseEntity<ResponseDto<MovieDto>> fetchMovieById(@PathVariable String movieId) throws MovieCatalogServiceApplicationException;
	@GetMapping(value="fetchTheaterById/{theatreId}")
	public ResponseEntity<ResponseDto<TheatreDto>> fetchTheaterById(@PathVariable String theatreId) throws MovieCatalogServiceApplicationException;
	
}
