package com.mindtree.microservices.searchservice.dto;

public class ShowsDto {
	private String showId;
	private String timings;
	private String duration;
	
	private int totalNoOfSeats;
	private int totalBookedSeats;
	private int totalFreeSeats;
	private int totalDamagedSeats;
	private int numberOfRows;
	public ShowsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShowsDto(String showId, String timings, String duration, int totalNoOfSeats, int totalBookedSeats,
			int totalFreeSeats, int totalDamagedSeats, int numberOfRows) {
		super();
		this.showId = showId;
		this.timings = timings;
		this.duration = duration;
		this.totalNoOfSeats = totalNoOfSeats;
		this.totalBookedSeats = totalBookedSeats;
		this.totalFreeSeats = totalFreeSeats;
		this.totalDamagedSeats = totalDamagedSeats;
		this.numberOfRows = numberOfRows;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getTimings() {
		return timings;
	}
	public void setTimings(String timings) {
		this.timings = timings;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public int getTotalNoOfSeats() {
		return totalNoOfSeats;
	}
	public void setTotalNoOfSeats(int totalNoOfSeats) {
		this.totalNoOfSeats = totalNoOfSeats;
	}
	public int getTotalBookedSeats() {
		return totalBookedSeats;
	}
	public void setTotalBookedSeats(int totalBookedSeats) {
		this.totalBookedSeats = totalBookedSeats;
	}
	public int getTotalFreeSeats() {
		return totalFreeSeats;
	}
	public void setTotalFreeSeats(int totalFreeSeats) {
		this.totalFreeSeats = totalFreeSeats;
	}
	public int getTotalDamagedSeats() {
		return totalDamagedSeats;
	}
	public void setTotalDamagedSeats(int totalDamagedSeats) {
		this.totalDamagedSeats = totalDamagedSeats;
	}
	public int getNumberOfRows() {
		return numberOfRows;
	}
	public void setNumberOfRows(int numberOfRows) {
		this.numberOfRows = numberOfRows;
	}
	
}
