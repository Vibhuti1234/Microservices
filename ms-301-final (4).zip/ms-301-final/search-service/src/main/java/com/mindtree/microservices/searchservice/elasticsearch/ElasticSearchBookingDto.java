package com.mindtree.microservices.searchservice.elasticsearch;

import javax.persistence.Id;

import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.elasticsearch.annotations.Document;

import com.mindtree.microservices.searchservice.dto.BookingDto;

@Document(indexName="booking",type="booking")
public class ElasticSearchBookingDto {
	@Id
	private String id;
	private int bookingId;
	private int confirmationNumber;
	public ElasticSearchBookingDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@PersistenceConstructor
	public ElasticSearchBookingDto(String id, int bookingId, int confirmationNumber) {
		// super();
		this.id = id;
		this.bookingId = bookingId;
		this.confirmationNumber = confirmationNumber;
	}

	
	 public ElasticSearchBookingDto(BookingDto bookingDto) {
	    this.id=""+bookingDto.getBookingId();
		this.bookingId = bookingDto.getBookingId();
		this.confirmationNumber = bookingDto.getConfirmationNumber();
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getConfirmationNumber() {
		return confirmationNumber;
	}
	public void setConfirmationNumber(int confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}

}
