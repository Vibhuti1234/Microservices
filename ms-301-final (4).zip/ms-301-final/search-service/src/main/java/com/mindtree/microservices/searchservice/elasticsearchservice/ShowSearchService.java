package com.mindtree.microservices.searchservice.elasticsearchservice;

import com.mindtree.microservices.searchservice.elasticsearch.EsShowsDto;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;

public interface ShowSearchService {

	Iterable<EsShowsDto> fetchAllShows() throws MovieCatalogServiceApplicationException;

	EsShowsDto fetchShowById(String showId) throws MovieCatalogServiceApplicationException;

}
