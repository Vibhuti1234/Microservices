package com.mindtree.microservices.searchservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.searchservice.dto.ResponseDto;
import com.mindtree.microservices.searchservice.dto.ShowsDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsShowsDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.EsShowsDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.impl.ShowSearchServiceImpl;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoShowsFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchShowFoundException;
import com.mindtree.microservices.searchservice.proxy.SearchServiceProxy;

@SpringBootTest
public class ShowSearchServiceTest {
	static String showsId;
	static int numberOfRows;
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	ShowSearchServiceImpl showSearchServiceImpl;
	@Mock
	private EsShowsDtoRepository esShowsDtoRepository;
	@Mock
	private SearchServiceProxy searchServiceProxy;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(showSearchServiceImpl).build();
	}

	@Test
	public void fetchAllShowsTest() {
		List<ShowsDto> showsDtos = new ArrayList<ShowsDto>();
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(3);
		showsDtos.add(showsDto);
		ResponseDto<List<ShowsDto>> response = new ResponseDto<List<ShowsDto>>(showsDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.getAllShows())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EsShowsDto> esShowsDtos = new ArrayList<>();
		EsShowsDto esShowsDto = new EsShowsDto(showsDto);
		esShowsDtos.add(esShowsDto);
		Collection<EsShowsDto> result = esShowsDtos;
		Iterable<EsShowsDto> iterable = result;
		Mockito.when(esShowsDtoRepository.findAll()).thenReturn(iterable);
		try {
			showSearchServiceImpl.fetchAllShows().forEach(i -> {
				showsId = i.getShowId();
				numberOfRows = i.getNumberOfRows();
			});
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("S1", showsId);
		assertEquals(3, numberOfRows);

	}

	@Test(expected = NoShowsFoundException.class)
	public void fetchAllShowsTestForException() throws MovieCatalogServiceApplicationException {
		List<ShowsDto> showsDtos = new ArrayList<ShowsDto>();
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(3);
		ResponseDto<List<ShowsDto>> response = new ResponseDto<List<ShowsDto>>(showsDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.getAllShows())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EsShowsDto> esShowsDtos = new ArrayList<>();
		EsShowsDto esShowsDto = new EsShowsDto(showsDto);
		esShowsDtos.add(esShowsDto);
		Collection<EsShowsDto> result = esShowsDtos;
		Iterable<EsShowsDto> iterable = result;
		Mockito.when(esShowsDtoRepository.findAll()).thenReturn(iterable);

		showSearchServiceImpl.fetchAllShows();

	}

	@Test
	public void fetchShowsByIdTest() {
		List<ShowsDto> showsDtos = new ArrayList<ShowsDto>();
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(3);
		showsDtos.add(showsDto);
		ResponseDto<List<ShowsDto>> response = new ResponseDto<List<ShowsDto>>(showsDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.getAllShows())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		EsShowsDto esShowsDto = new EsShowsDto(showsDto);

		Mockito.when(esShowsDtoRepository.findById(Mockito.anyString())).thenReturn(Optional.of(esShowsDto));

		try {
			assertEquals("S1", showSearchServiceImpl.fetchShowById("S1").getShowId());
			assertEquals(3, showSearchServiceImpl.fetchShowById("S1").getNumberOfRows());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test(expected = NoShowsFoundException.class)
	public void fetchShowsByIdTestForException() throws MovieCatalogServiceApplicationException {
		List<ShowsDto> showsDtos = new ArrayList<ShowsDto>();
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(3);
		ResponseDto<List<ShowsDto>> response = new ResponseDto<List<ShowsDto>>(showsDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.getAllShows())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		EsShowsDto esShowsDto = new EsShowsDto(showsDto);

		Mockito.when(esShowsDtoRepository.findById(Mockito.anyString())).thenReturn(Optional.of(esShowsDto));

		showSearchServiceImpl.fetchShowById("S1");

	}

	@Test(expected = NoSuchShowFoundException.class)
	public void fetchShowsByIdTestForException2() throws MovieCatalogServiceApplicationException {
		List<ShowsDto> showsDtos = new ArrayList<ShowsDto>();
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setNumberOfRows(3);
		showsDtos.add(showsDto);
		ResponseDto<List<ShowsDto>> response = new ResponseDto<List<ShowsDto>>(showsDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.getAllShows())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		showSearchServiceImpl.fetchShowById("S1");

	}

}
