package com.mindtree.microservices.searchservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.searchservice.dto.BookingDto;
import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchBookingDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.ElasticSearchBookingDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.impl.BookingSearchServiceImpl;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoBookingFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchBookingFoundException;
import com.mindtree.microservices.searchservice.proxy.BookingSearchServiceProxy;

@SpringBootTest
public class BookingSearchServiceTest {
	static int bookingId;

	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	BookingSearchServiceImpl bookingSearchServiceImpl;
	@Mock
	ElasticSearchBookingDtoRepository esBookingDtoRepository;
	@Mock
	private BookingSearchServiceProxy bookingSearchServiceProxy;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(bookingSearchServiceImpl).build();
	}

	@Test
	public void getAllBookingsTest() {
		List<BookingDto> bookingDtos = new ArrayList<BookingDto>();
		BookingDto bookingDto = new BookingDto();
		bookingDto.setBookingId(1);
		bookingDto.setConfirmationNumber(1234);
		bookingDtos.add(bookingDto);
		Mockito.when(bookingSearchServiceProxy.getAllBookings()).thenReturn(bookingDtos);
		List<ElasticSearchBookingDto> elasticSearchBookingDtos = new ArrayList<>();
		ElasticSearchBookingDto elasticSearchBookingDto = new ElasticSearchBookingDto(bookingDto);
		elasticSearchBookingDtos.add(elasticSearchBookingDto);
		Collection<ElasticSearchBookingDto> bookings = elasticSearchBookingDtos;
		Iterable<ElasticSearchBookingDto> iterable = bookings;
		Mockito.when(esBookingDtoRepository.findAll()).thenReturn(iterable);
		try {
			bookingSearchServiceImpl.getAllBookings().forEach(i -> {
				bookingId = i.getBookingId();
			});
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(1, bookingId);
	}

	@Test(expected = NoBookingFoundException.class)
	public void getAllBookingsTestForException() throws MovieCatalogServiceApplicationException {
		List<BookingDto> bookingDtos = new ArrayList<BookingDto>();
		BookingDto bookingDto = new BookingDto();
		bookingDto.setBookingId(1);
		bookingDto.setConfirmationNumber(1234);
		Mockito.when(bookingSearchServiceProxy.getAllBookings()).thenReturn(bookingDtos);
		List<ElasticSearchBookingDto> elasticSearchBookingDtos = new ArrayList<>();
		ElasticSearchBookingDto elasticSearchBookingDto = new ElasticSearchBookingDto(bookingDto);
		elasticSearchBookingDtos.add(elasticSearchBookingDto);
		Collection<ElasticSearchBookingDto> bookings = elasticSearchBookingDtos;
		Iterable<ElasticSearchBookingDto> iterable = null;
		Mockito.when(esBookingDtoRepository.findAll()).thenReturn(iterable);

		bookingSearchServiceImpl.getAllBookings();

	}

	@Test
	public void getBookingByIdTest() {
		List<BookingDto> bookingDtos = new ArrayList<BookingDto>();
	
		BookingDto bookingDto = new BookingDto();
		bookingDto.setBookingId(1);
		bookingDto.setConfirmationNumber(1234);
		bookingDtos.add(bookingDto);
		Mockito.when(bookingSearchServiceProxy.getAllBookings()).thenReturn(bookingDtos);
		ElasticSearchBookingDto elasticSearchBookingDto = new ElasticSearchBookingDto(bookingDto);
		Mockito.when(esBookingDtoRepository.findById(Mockito.any())).thenReturn(Optional.of(elasticSearchBookingDto));
		try {
			assertEquals(1, bookingSearchServiceImpl.getBookingById(1).getBookingId());
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test(expected=NoBookingFoundException.class)
	public void getBookingByIdTestForException() throws MovieCatalogServiceApplicationException {
		List<BookingDto> bookingDtos = new ArrayList<BookingDto>();
		BookingDto bookingDto = new BookingDto();
		bookingDto.setBookingId(1);
		bookingDto.setConfirmationNumber(1234);
	
		Mockito.when(bookingSearchServiceProxy.getAllBookings()).thenReturn(bookingDtos);
		ElasticSearchBookingDto elasticSearchBookingDto = new ElasticSearchBookingDto(bookingDto);
		Mockito.when(esBookingDtoRepository.findById(Mockito.any())).thenReturn(Optional.of(elasticSearchBookingDto));
	
			 bookingSearchServiceImpl.getBookingById(1);
		

	}
	@Test(expected=NoSuchBookingFoundException.class)
	public void getBookingByIdTestForException2() throws MovieCatalogServiceApplicationException {
		List<BookingDto> bookingDtos = new ArrayList<BookingDto>();
		BookingDto bookingDto = new BookingDto();
		bookingDto.setBookingId(1);
		bookingDto.setConfirmationNumber(1234);
	    bookingDtos.add(bookingDto);
		Mockito.when(bookingSearchServiceProxy.getAllBookings()).thenReturn(bookingDtos);
		ElasticSearchBookingDto elasticSearchBookingDto = new ElasticSearchBookingDto(bookingDto);	
			 bookingSearchServiceImpl.getBookingById(1);
		

	}
}
