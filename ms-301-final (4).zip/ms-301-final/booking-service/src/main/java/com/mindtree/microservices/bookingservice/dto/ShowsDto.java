package com.mindtree.microservices.bookingservice.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ShowsDto {
	private String showId;
	private String timings;
	private String duration;
	private int totalNoOfSeats;
	private int totalBookedSeats;
	private int totalFreeSeats;
	private int totalDamagedSeats;
	private int numberOfRows;
	@JsonIgnore
	private MovieDto movie;
	public ShowsDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ShowsDto(String showId, String timings, String duration, int totalNoOfSeats, int totalBookedSeats,
			int totalFreeSeats, int totalDamagedSeats, int numberOfRows, MovieDto movie) {
		super();
		this.showId = showId;
		this.timings = timings;
		this.duration = duration;
		this.totalNoOfSeats = totalNoOfSeats;
		this.totalBookedSeats = totalBookedSeats;
		this.totalFreeSeats = totalFreeSeats;
		this.totalDamagedSeats = totalDamagedSeats;
		this.numberOfRows = numberOfRows;
		this.movie = movie;
	}

	/**
	 * @return the movie
	 */
	public MovieDto getMovie() {
		return movie;
	}

	/**
	 * @param movie the movie to set
	 */
	public void setMovie(MovieDto movie) {
		this.movie = movie;
	}

	/**
	 * @return the showId
	 */
	public String getShowId() {
		return showId;
	}
	/**
	 * @param showId the showId to set
	 */
	public void setShowId(String showId) {
		this.showId = showId;
	}
	/**
	 * @return the timings
	 */
	public String getTimings() {
		return timings;
	}
	/**
	 * @param timings the timings to set
	 */
	public void setTimings(String timings) {
		this.timings = timings;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	/**
	 * @return the totalNoOfSeats
	 */
	public int getTotalNoOfSeats() {
		return totalNoOfSeats;
	}
	/**
	 * @param totalNoOfSeats the totalNoOfSeats to set
	 */
	public void setTotalNoOfSeats(int totalNoOfSeats) {
		this.totalNoOfSeats = totalNoOfSeats;
	}
	/**
	 * @return the totalBookedSeats
	 */
	public int getTotalBookedSeats() {
		return totalBookedSeats;
	}
	/**
	 * @param totalBookedSeats the totalBookedSeats to set
	 */
	public void setTotalBookedSeats(int totalBookedSeats) {
		this.totalBookedSeats = totalBookedSeats;
	}
	/**
	 * @return the totalFreeSeats
	 */
	public int getTotalFreeSeats() {
		return totalFreeSeats;
	}
	/**
	 * @param totalFreeSeats the totalFreeSeats to set
	 */
	public void setTotalFreeSeats(int totalFreeSeats) {
		this.totalFreeSeats = totalFreeSeats;
	}
	/**
	 * @return the totalDamagedSeats
	 */
	public int getTotalDamagedSeats() {
		return totalDamagedSeats;
	}
	/**
	 * @param totalDamagedSeats the totalDamagedSeats to set
	 */
	public void setTotalDamagedSeats(int totalDamagedSeats) {
		this.totalDamagedSeats = totalDamagedSeats;
	}
	/**
	 * @return the numberOfRows
	 */
	public int getNumberOfRows() {
		return numberOfRows;
	}
	/**
	 * @param numberOfRows the numberOfRows to set
	 */
	public void setNumberOfRows(int numberOfRows) {
		this.numberOfRows = numberOfRows;
	}


	
	
	
}
