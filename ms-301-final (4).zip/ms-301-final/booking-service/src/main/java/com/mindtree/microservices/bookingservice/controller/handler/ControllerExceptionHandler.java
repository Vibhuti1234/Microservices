package com.mindtree.microservices.bookingservice.controller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.microservices.bookingservice.controller.BookingServiceController;
import com.mindtree.microservices.bookingservice.dto.ErrorDto;
import com.mindtree.microservices.bookingservice.exception.ServiceException;
@RestControllerAdvice(assignableTypes= {BookingServiceController.class})
public class ControllerExceptionHandler {

	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<ErrorDto> serviceExceptionHandler(Exception e, Throwable cause){
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorDto(e.getMessage(), cause));
	}
}
