package com.mindtree.microservices.bookingservice.service;

import java.util.List;

import com.mindtree.microservices.bookingservice.dto.BookingDto;
import com.mindtree.microservices.bookingservice.entity.Booking;
import com.mindtree.microservices.bookingservice.exception.BookingServiceApplicationException;

public interface BookingService {

	Booking bookShow(String showId) throws BookingServiceApplicationException;

	BookingDto getBookingById(int bookingId) throws BookingServiceApplicationException;

	List<BookingDto> getAllBookings() throws BookingServiceApplicationException;

}
