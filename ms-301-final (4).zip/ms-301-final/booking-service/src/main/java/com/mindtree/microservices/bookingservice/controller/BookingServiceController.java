package com.mindtree.microservices.bookingservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.microservices.bookingservice.dto.BookingDto;
import com.mindtree.microservices.bookingservice.entity.Booking;
import com.mindtree.microservices.bookingservice.exception.BookingServiceApplicationException;
import com.mindtree.microservices.bookingservice.service.BookingService;

@RestController
@RequestMapping("/")
public class BookingServiceController {

	@Autowired
	private BookingService bookingService;

	@GetMapping(value = "bookShow/{showId}")
	public Booking bookShow(@PathVariable String showId) throws BookingServiceApplicationException {

		Booking bookingResult = bookingService.bookShow(showId);
		return bookingResult;

	}

	@GetMapping(value = "getBookingById/{bookingId}")
	public BookingDto getBookingById(@PathVariable int bookingId) throws BookingServiceApplicationException {
		return bookingService.getBookingById(bookingId);
	}

	@GetMapping(value = "getAllBookings")
	public List<BookingDto> getAllBookings() throws BookingServiceApplicationException {
		return bookingService.getAllBookings();
	}

}
