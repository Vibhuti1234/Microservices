package com.mindtree.cartservice.servicetest;

public class CartServiceApplicationTestService {

}
