package com.mindtree.cartservice.controllertest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.mindtree.cartservice.controller.CartController;
import com.mindtree.cartservice.dto.CartDto;
import com.mindtree.cartservice.exception.CartApplicationException;
import com.mindtree.cartservice.exception.ServiceException;
import com.mindtree.cartservice.service.CartService;

@SpringBootTest
public class CartServiceApplicationTestController {
	
	@InjectMocks
	CartController cartController;
	
	@Mock
	CartService cartService;
	
	private CartDto cartDto;
	
	private List<CartDto> cartDtoList;
	
	@BeforeEach
	void setUp()
	{
		MockitoAnnotations.initMocks(this);
		cartDto=getCartDto();
		cartDtoList=getCartDtoList();
	}
	private List<CartDto> getCartDtoList() {
		List<CartDto> cartDtoList=new ArrayList<CartDto>();
		CartDto cartDto1=new CartDto();
		cartDto1.setCartId(123);
		cartDto1.setCustomerId("customerId");
		cartDto1.setFoodName("foodName");
		cartDto1.setPrice(123.6);
		cartDto1.setQuantity(12);
		cartDto1.setRestaurantId("restaurantId");
		cartDto1.setRestaurantName("restaurantName");
		cartDtoList.add(cartDto1);
		return cartDtoList;
	}
	private CartDto getCartDto() {
		CartDto cartDto1=new CartDto();
		cartDto1.setCartId(123);
		cartDto1.setCustomerId("customerId");
		cartDto1.setFoodName("foodName");
		cartDto1.setPrice(123.6);
		cartDto1.setQuantity(12);
		cartDto1.setRestaurantId("restaurantId");
		cartDto1.setRestaurantName("restaurantName");
		return cartDto1;
	}
	@Test
	public void testaddToCart() throws CartApplicationException
	{
		when(cartService.addToCart(cartDto.getCustomerId(),cartDto.getRestaurantId(),cartDto.getFoodName(),cartDto.getQuantity())).thenReturn(cartDto);
		CartDto cartDto1=cartController.addToCart(cartDto.getCustomerId(),cartDto.getRestaurantId(),cartDto.getFoodName(),cartDto.getQuantity()).getBody();
		assertEquals(cartDto, cartDto1);
		
	}
	@Test
	public void testgetCartByCustomerId()
	{
		when(cartService.getCartByCustomerId(cartDto.getCustomerId())).thenReturn(cartDtoList);
		List<CartDto> cartDtoList1=cartController.getCartByCustomerId(cartDto.getCustomerId()).getBody();
		assertEquals(cartDtoList, cartDtoList1);
	}
	@Test
	public void testaddToCartException() throws CartApplicationException
	{
		when(cartService.addToCart(cartDto.getCustomerId(),cartDto.getRestaurantId(),cartDto.getFoodName(),cartDto.getQuantity())).thenThrow(new ServiceException());
		assertThrows(CartApplicationException.class, ()->cartController.addToCart(cartDto.getCustomerId(),cartDto.getRestaurantId(),cartDto.getFoodName(),cartDto.getQuantity()).getBody());
	}
	
	
	
	
	
	
}