package com.mindtree.cartservice.repository;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.mindtree.cartservice.entity.Cart;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

	@Transactional
	@Modifying
	@Query(value="delete from cart where customer_id=?1",nativeQuery = true)
	void deleteByCustomerId(String customerId);

}
