package com.mindtree.cartservice.service.impl;
import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.cartservice.dto.CartDto;
import com.mindtree.cartservice.dto.FoodDto;
import com.mindtree.cartservice.dto.RestaurantDto;
import com.mindtree.cartservice.entity.Cart;
import com.mindtree.cartservice.exception.FoodNotAvailabeException;
import com.mindtree.cartservice.exception.QuantityExceededException;
import com.mindtree.cartservice.exception.ServiceException;
import com.mindtree.cartservice.proxy.RestaurantProxy;
import com.mindtree.cartservice.repository.CartRepository;
import com.mindtree.cartservice.service.CartService;

import feign.FeignException;

@Service
public class CartServiceImpl implements CartService {
	
	@Autowired
	RestaurantProxy restaurantProxy;
	
	@Autowired
	CartRepository cartRepository;
	
	ModelMapper modelMapper=new ModelMapper();

	@Override
	public CartDto addToCart(String customerId, String restaurantId, String foodName,int quantity) throws ServiceException {
		double price=0.0;
		Cart cart=new Cart();
		List<FoodDto> foods=new ArrayList<FoodDto>();
		RestaurantDto restaurantDto=new RestaurantDto();
		cart.setCustomerId(customerId);
		cart.setRestaurantId(restaurantId);
		int foodquantity=0;
		try
		{
		restaurantDto=restaurantProxy.getRestaurantByRestaurantId(restaurantId).getBody();
		foods=restaurantDto.getFoods();
		}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
			
		}
		cart.setFoodName(foodName);
		for(FoodDto f : foods)
		{
			if(f.getFoodName().equalsIgnoreCase(foodName))
			{
				price=f.getFoodPrice();
				foodquantity=foodquantity+f.getQuantity();
			}
		}
		if(price==0.0)
		{
			throw new FoodNotAvailabeException("Food Not Present");
		}
		if(foodquantity>=quantity)
		{
			cart.setRestaurantName(restaurantDto.getRestaurantName());
			cart.setQuantity(quantity);
			cart.setPrice(price);
			Cart resultcart=cartRepository.save(cart);
			return convertToDto(resultcart);
		}
		else
		{
			throw new QuantityExceededException("Quantity Exceeded");
		}
	}

	private CartDto convertToDto(Cart cart) {
		
		return modelMapper.map(cart, CartDto.class);
	}

	@Override
	public List<CartDto> getCartByCustomerId(String customerId) {
		List<Cart> cartlist=cartRepository.findAll();
		List<Cart> resultcart=new ArrayList<Cart>();
		List<CartDto> cartDtoList=new ArrayList<CartDto>();
		for(Cart c : cartlist)
		{
			if(c.getCustomerId().equalsIgnoreCase(customerId))
			{
				resultcart.add(c);
			}
		}
		for(Cart c : resultcart)
		{
			cartDtoList.add(convertToDto(c));
		}
		return cartDtoList;
	}

	@Override
	public void deleteByCustomerId(String customerId) {
		cartRepository.deleteByCustomerId(customerId);
		
	}

}
