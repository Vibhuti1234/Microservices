package com.mindtree.cartservice.exception;

public class QuantityExceededException extends ServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QuantityExceededException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public QuantityExceededException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public QuantityExceededException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public QuantityExceededException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public QuantityExceededException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
