package com.mindtree.cartservice.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.cartservice.dto.CartDto;
import com.mindtree.cartservice.exception.CartApplicationException;
import com.mindtree.cartservice.service.CartService;

@RestController
public class CartController {
	
    @Autowired
    CartService cartService;
	
	@GetMapping("AddToCart/{customerId}/{restaurantId}/{foodName}/{quantity}")
	public ResponseEntity<CartDto> addToCart(@PathVariable String customerId, @PathVariable String restaurantId, @PathVariable String foodName,@PathVariable int quantity) throws CartApplicationException
	{
		return new ResponseEntity<CartDto>(cartService.addToCart(customerId,restaurantId,foodName,quantity),HttpStatus.OK);
	}
	@GetMapping("/getCartDetails/{customerId}")
	public ResponseEntity <List<CartDto>> getCartByCustomerId(@PathVariable String customerId)
	{
		return new ResponseEntity<List<CartDto>>(cartService.getCartByCustomerId(customerId),HttpStatus.OK);
		
	}
	@DeleteMapping("/deleteCartByCustomerId/{customerId}")
	public void deleteByCustomerId(@PathVariable String customerId)
	{
		cartService.deleteByCustomerId(customerId);
	}

}
