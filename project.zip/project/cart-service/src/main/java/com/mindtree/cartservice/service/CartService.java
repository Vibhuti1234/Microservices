package com.mindtree.cartservice.service;

import java.util.List;

import com.mindtree.cartservice.dto.CartDto;
import com.mindtree.cartservice.exception.ServiceException;

public interface CartService {

	CartDto addToCart(String customerId, String restaurantId, String foodName, int quantity) throws ServiceException;

	List<CartDto> getCartByCustomerId(String customerId);

	void deleteByCustomerId(String customerId);

}
