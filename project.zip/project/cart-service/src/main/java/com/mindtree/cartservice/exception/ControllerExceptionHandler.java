package com.mindtree.cartservice.exception;

import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
public class ControllerExceptionHandler{	
	@ExceptionHandler(CartApplicationException.class)
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	public ExceptionResponse handlerExceptionResponse(final CartApplicationException exception,final HttpServletRequest request)
	{
		ExceptionResponse exp=new ExceptionResponse();
		exp.setErrorMessage(exception.getMessage());
		exp.setRequesturl(request.getRequestURI());
		return exp;
	}
	
}

