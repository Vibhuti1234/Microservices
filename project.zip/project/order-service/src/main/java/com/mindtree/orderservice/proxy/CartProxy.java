package com.mindtree.orderservice.proxy;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.orderservice.dto.CartDto;

@FeignClient(name="cart-service")
public interface CartProxy {
	
	@GetMapping("/getCartDetails/{customerId}")
	public ResponseEntity <List<CartDto>> getCartByCustomerId(@PathVariable String customerId);
	
	@DeleteMapping("/deleteCartByCustomerId/{customerId}")
	public void deleteByCustomerId(@PathVariable String customerId);
	

}
