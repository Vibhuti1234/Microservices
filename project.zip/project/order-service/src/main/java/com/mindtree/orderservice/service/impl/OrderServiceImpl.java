package com.mindtree.orderservice.service.impl;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Service;
import com.mindtree.orderservice.dto.CartDto;
import com.mindtree.orderservice.dto.OrderDto;
import com.mindtree.orderservice.entity.Order;
import com.mindtree.orderservice.exception.NoOrderAvailableEception;
import com.mindtree.orderservice.exception.ServiceException;
import com.mindtree.orderservice.proxy.CartProxy;
import com.mindtree.orderservice.proxy.RestaurantProxy;
import com.mindtree.orderservice.repository.OrderRepository;
import com.mindtree.orderservice.service.OrderService;

import feign.FeignException;

@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	CartProxy cartProxy;
	
	@Autowired
	RestaurantProxy restaurantProxy;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	private static final String TOPIC ="TestTopic";
	
	private JavaMailSenderImpl mailSenderImpl=new JavaMailSenderImpl();
	
	ModelMapper modelMapper=new ModelMapper();
	
	@Bean
	public JavaMailSender getJavaMailSender()
	{
		mailSenderImpl.setHost("smtp.gmail.com");
		mailSenderImpl.setPort(587);
		
		Properties properties=mailSenderImpl.getJavaMailProperties();
		properties.put("mail.transport.protocol", "smtp");
		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.debug", "true");
		
		return mailSenderImpl;
		
	}

	@Override
	public OrderDto placeOrder(String customerId,String customerName) throws ServiceException {
		List<CartDto> cartDtoList=new ArrayList<CartDto>();
		try
		{
		cartDtoList=cartProxy.getCartByCustomerId(customerId).getBody();
		}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
		List<CartDto> resultcart=new ArrayList<CartDto>();
		List<String> foodlist=new ArrayList<String>();
		Order order=new Order();
		order.setCustomerId(customerId);
		order.setCustomerName(customerName);
		String restaurantId=null;
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		dateFormat.format(date);
		order.setDate(date);
		double totalPrice=0.0;
		for(CartDto c : cartDtoList)
		{
			if(c.getCustomerId().equalsIgnoreCase(customerId))
			{
				resultcart.add(c);				
		     }
		}
		for(CartDto c : resultcart)
		{
			foodlist.add(c.getFoodName());
			totalPrice=totalPrice+(c.getPrice()*c.getQuantity());
			order.setTotalPrice(totalPrice);
			order.setFoodNames(foodlist);
			order.setRestaurantName(c.getRestaurantName());
			restaurantId=c.getRestaurantId();
			restaurantProxy.deleteDataFromRestaurant(restaurantId,c.getFoodName(),c.getQuantity());
		}
		cartProxy.deleteByCustomerId(customerId);
		Order order1=orderRepository.save(order);
		return convertToDto(order1);
	}

	private OrderDto convertToDto(Order order1) {
		
		return modelMapper.map(order1, OrderDto.class);
	}

	@Override
	public List<OrderDto> getOrderDetails(String customerId) throws ServiceException {
		List<Order> orderlist=orderRepository.findAll();
		List<Order> resultOrder=new ArrayList<Order>();
		List<OrderDto> orderDtoList=new ArrayList<OrderDto>();
		for(Order o : orderlist)
		{
			if(o.getCustomerId().equalsIgnoreCase(customerId))
			{
				resultOrder.add(o);
			}
		}
		if(resultOrder.size()==0)
		{
			throw new NoOrderAvailableEception("No Order available for this customer");
		}
		else
		{
			for(Order o : resultOrder)
			{
				orderDtoList.add(converToDto(o));
			}
		}
		return orderDtoList;
	}

	private OrderDto converToDto(Order o) {
		
		return modelMapper.map(o, OrderDto.class);
	}

	@Override
	public void emailService() {
		
		SimpleMailMessage mail= new SimpleMailMessage();
		
		mailSenderImpl.setUsername("anjalireddyar2@gmail.com");
		
		mailSenderImpl.setPassword("AnjaliAR@123#");
		
		mail.setTo("jeebanjyoti.oec@gmail.com");
		mail.setSubject("First Mail");
		mail.setText("mail Sent");
		
//		kafkaTemplate.send(TOPIC, "kafka mail");
		mailSenderImpl.send(mail);
		
		
		
	}

}
