package com.mindtree.orderservice.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.orderservice.dto.OrderDto;
import com.mindtree.orderservice.exception.OrderApplicationException;
import com.mindtree.orderservice.service.OrderService;

@RestController
public class OrderController {
	
	@Autowired
	OrderService orderService;
	
	@GetMapping("/placeOrder/{customerId}/{customerName}")
	public ResponseEntity<OrderDto> placeOrder(@PathVariable String customerId,@PathVariable String customerName) throws OrderApplicationException
	{
		return new ResponseEntity<OrderDto>(orderService.placeOrder(customerId,customerName),HttpStatus.OK);	
	}
	@GetMapping("getOrderdetails/{customerId}")
	public ResponseEntity<List<OrderDto>> getOrderDetails(@PathVariable String customerId) throws OrderApplicationException
	{
		return new ResponseEntity<List<OrderDto>>(orderService.getOrderDetails(customerId),HttpStatus.OK);
	}
	@GetMapping("/sendMail")
	public void emailService()
	{
		orderService.emailService();
	}
	
	
}
