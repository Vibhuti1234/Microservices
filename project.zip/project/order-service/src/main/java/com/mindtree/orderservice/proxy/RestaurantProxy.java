package com.mindtree.orderservice.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="restaurant-service")
public interface RestaurantProxy {

	
	@DeleteMapping("/deleteFood/{restaurantId}/{foodName}/{quantity}")
	void deleteDataFromRestaurant(@PathVariable String restaurantId, @PathVariable String foodName,@PathVariable int quantity);
}
