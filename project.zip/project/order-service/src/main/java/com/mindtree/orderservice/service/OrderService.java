package com.mindtree.orderservice.service;

import java.util.List;

import com.mindtree.orderservice.dto.OrderDto;
import com.mindtree.orderservice.exception.ServiceException;

public interface OrderService {

	OrderDto placeOrder(String customerId, String customerName) throws ServiceException;

	List<OrderDto> getOrderDetails(String customerId) throws ServiceException;

	void emailService();

}
