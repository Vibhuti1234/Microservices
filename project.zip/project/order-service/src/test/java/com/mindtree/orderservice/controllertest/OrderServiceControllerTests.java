package com.mindtree.orderservice.controllertest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.mindtree.orderservice.controller.OrderController;
import com.mindtree.orderservice.dto.OrderDto;
import com.mindtree.orderservice.exception.OrderApplicationException;
import com.mindtree.orderservice.exception.ServiceException;
import com.mindtree.orderservice.service.OrderService;

@SpringBootTest
public class OrderServiceControllerTests {
	
	@InjectMocks
	OrderController orderController;
	
	@Mock
	OrderService orderService;
	
	private OrderDto orderDto;
	
	private List<OrderDto> orderDtoList;
	
	String customerId;
	
	String customerName;
	
	@BeforeEach
	void setUp()
	{
		MockitoAnnotations.initMocks(this);
	    orderDto=getOrderDto();
	    orderDtoList=getOrderDtoList();
	    customerId="customerId";
	    customerName="customerName";
		
	}
	private List<OrderDto> getOrderDtoList() {
		List<OrderDto> orderDtoList=new ArrayList<OrderDto>();
		OrderDto orderDto1=new OrderDto();
		orderDto1.setCustomerId("customerId");
		orderDto1.setCustomerName("customerName");
		orderDto1.setDate(java.sql.Date.valueOf(java.time.LocalDate.now()));
		orderDto1.setRestaurantName("restaurantName");
		orderDto1.setTotalPrice(123.8);
		//orderDto1.setFoodNames(null);
		orderDtoList.add(orderDto1);
		return orderDtoList;
	}
	private OrderDto getOrderDto() {
		OrderDto orderDto1=new OrderDto();
		orderDto1.setCustomerId("customerId");
		orderDto1.setCustomerName("customerName");
		orderDto1.setDate(java.sql.Date.valueOf(java.time.LocalDate.now()));
		orderDto1.setRestaurantName("restaurantName");
		orderDto1.setTotalPrice(123.8);
		//orderDto1.setFoodNames(null);
		return orderDto1;
	}
	@Test
	public void testplaceOrder() throws OrderApplicationException
	{
		when(orderService.placeOrder(customerId, customerName)).thenReturn(orderDto);
		OrderDto orderDto1=orderController.placeOrder(customerId, customerName).getBody();
		assertEquals(orderDto, orderDto1);
		
	}
	@Test
	public void testgetOrderDetails() throws OrderApplicationException
	{
		when(orderService.getOrderDetails(customerId)).thenReturn(orderDtoList);
		List<OrderDto> orderDtoList1=orderController.getOrderDetails(customerId).getBody();
		assertEquals(orderDtoList, orderDtoList1);
	}
	@Test
	public void testplaceOrderException() throws OrderApplicationException
	{
		when(orderService.placeOrder(customerId, customerName)).thenThrow(new ServiceException());
		assertThrows(OrderApplicationException.class,()->orderController.placeOrder(customerId, customerName).getBody());
	}
	@Test
	public void testgetOrderDetailsException() throws OrderApplicationException
	{
		when(orderService.getOrderDetails(customerId)).thenThrow(new ServiceException());
		assertThrows(OrderApplicationException.class,()->orderController.getOrderDetails(customerId).getBody());
		
	}

	

}
