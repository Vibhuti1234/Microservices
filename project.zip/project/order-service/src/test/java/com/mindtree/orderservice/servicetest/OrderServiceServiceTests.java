package com.mindtree.orderservice.servicetest;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OrderServiceServiceTests {


}
