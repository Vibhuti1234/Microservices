package com.mindtree.restaurantservice.servicetest;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.mindtree.restaurantservice.dto.FoodDto;
import com.mindtree.restaurantservice.dto.LocationDto;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.entity.Food;
import com.mindtree.restaurantservice.repository.FoodRepository;
import com.mindtree.restaurantservice.repository.LocationRepository;
import com.mindtree.restaurantservice.repository.RestaurantRepository;
import com.mindtree.restaurantservice.service.impl.FoodServiceImpl;
import com.mindtree.restaurantservice.service.impl.LocationServiceImpl;
import com.mindtree.restaurantservice.service.impl.RestaurantServiceImpl;

@SpringBootTest
public class RestaurantServiceServiceTest {
	
	@InjectMocks
	FoodServiceImpl foodServiceImpl;
	
	@InjectMocks
	RestaurantServiceImpl restaurantServiceImpl;
	
	@InjectMocks
	LocationServiceImpl locationServiceImpl;
	
	@Mock
	FoodRepository foodRepository;
	
	@Mock
	RestaurantRepository restaurantRepository;
	
	@Mock
	LocationRepository locationRepository;
	
	//private FoodDto foodDto;
	
	private RestaurantDto restaurantDto;
	
	private List<FoodDto> foodDtos;

	private LocationDto locationDto;
	
	private List<Food> foodList;
	
	@BeforeEach
	void setUp()
	{
		MockitoAnnotations.initMocks(this);
		//foodDto=getFoodDto();
		restaurantDto=getRestaurantDto();
		foodDtos=getFoodDtos();
		locationDto=getLocationDto();
		foodList=getFoodList();
		
	}
	private List<Food> getFoodList() {
		List<Food> foodList1=new ArrayList<>();
		Food food =new Food();
		food.setFoodId("foodId");
		food.setFoodName("foodName");
		food.setFoodPrice(123);
		food.setQuantity(12);
		food.setRestaurant(null);
		foodList1.add(food);
		return foodList1;
	}
/*	private FoodDto getFoodDto() {
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(5);
		foodDto1.setRestaurantdto(restaurantDto);
		return foodDto1;
	}*/
	private RestaurantDto getRestaurantDto() {
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		return restaurantDto1;
	}
	private LocationDto getLocationDto() {
		LocationDto locationDto1=new LocationDto();
		locationDto1.setLocationId("locationId");
		locationDto1.setLocationName("locationName");
		//locationDto1.setRestaurantDtos(restaurantDtoList);
		return locationDto1;
	}
    private List<FoodDto> getFoodDtos() {
		
		List<FoodDto> foodDtoList=new ArrayList<FoodDto>();
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(12);
		foodDto1.setRestaurantdto(restaurantDto);
		foodDtoList.add(foodDto1);
		return foodDtoList;
	}
	@Test
	public void testgetAllRestaurantByFoodName()
	{
		when(foodRepository.findAll()).thenReturn(foodList);
		
		
	}


}
