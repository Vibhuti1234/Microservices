package com.mindtree.restaurantservice.controllertest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.mindtree.restaurantservice.controller.FoodController;
import com.mindtree.restaurantservice.controller.LocationController;
import com.mindtree.restaurantservice.controller.RestaurantController;
import com.mindtree.restaurantservice.dto.FoodDto;
import com.mindtree.restaurantservice.dto.LocationDto;
import com.mindtree.restaurantservice.dto.RestaurantDetailsDto;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.exception.RestaurantApplicationException;
import com.mindtree.restaurantservice.exception.ServiceException;
import com.mindtree.restaurantservice.service.FoodService;
import com.mindtree.restaurantservice.service.LocationService;
import com.mindtree.restaurantservice.service.RestaurantService;

@SpringBootTest
public class RestaurantServiceControllerTest {
	
	@InjectMocks
	RestaurantController restaurantController;
	
	@InjectMocks
	FoodController foodController;
	
	@InjectMocks
	LocationController locationController;
	
	@Mock
    RestaurantService restaurantService;
	
	@Mock
	FoodService foodService;
	
	@Mock
	LocationService locationService;

	private FoodDto foodDto;

	private RestaurantDto restaurantDto;
	
	private List<RestaurantDetailsDto> restaurantDetailsDtos;

	private List<RestaurantDto> restaurantDtoList;

	private List<FoodDto> foodDtos;

	private LocationDto locationDto;

	@BeforeEach
	void  setUp()
	{
		MockitoAnnotations.initMocks(this);
		foodDto=getFoodDto();
		restaurantDto=getRestaurantDto();
		restaurantDetailsDtos=getRestaurantDetailsDto();
		restaurantDtoList=getRestaurantDtos();
		foodDtos=getFoodDtos();
		locationDto=getLocationDto();
	}
	private LocationDto getLocationDto() {
		LocationDto locationDto1=new LocationDto();
		locationDto1.setLocationId("locationId");
		locationDto1.setLocationName("locationName");
		return locationDto1;
	}
	private List<FoodDto> getFoodDtos() {
		
		List<FoodDto> foodDtoList=new ArrayList<FoodDto>();
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(12);
		foodDto1.setRestaurantdto(restaurantDto);
		foodDtoList.add(foodDto1);
		return foodDtoList;
	}
	private List<RestaurantDto> getRestaurantDtos() {
		List<RestaurantDto> restaurantDetailsDtos1=new ArrayList<RestaurantDto>();
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		restaurantDetailsDtos1.add(restaurantDto1);
		return restaurantDetailsDtos1;
	}
	private RestaurantDto getRestaurantDto() {
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		return restaurantDto1;
	}
	private FoodDto getFoodDto() {
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(5);
		foodDto1.setRestaurantdto(restaurantDto);
		return foodDto1;
	}
	private List<RestaurantDetailsDto> getRestaurantDetailsDto() {
		List<RestaurantDetailsDto> restaurantDetailsDtos=new ArrayList<RestaurantDetailsDto>();
		RestaurantDetailsDto restaurantDetailsDto=new RestaurantDetailsDto();
		restaurantDetailsDto.setRestaurantId("restaurantId");
		restaurantDetailsDto.setRestaurantName("restaurantName");
		restaurantDetailsDto.setLocation(locationDto);
		restaurantDetailsDto.setFoods(foodDtos);
		restaurantDetailsDtos.add(restaurantDetailsDto);
		return restaurantDetailsDtos;
	}
	@Test
	public void testaddFoodToRestaurant() throws RestaurantApplicationException
	{
		when(restaurantService.addFoodToRestaurant(restaurantDto.getRestaurantId(),foodDto)).thenReturn(restaurantDto);
		RestaurantDto restaurantDto1=foodController.addFoodToRestaurant(restaurantDto.getRestaurantId(),foodDto).getBody();
		assertEquals(restaurantDto, restaurantDto1);	
	}
	@Test
	public void testgetAllRestaurantByFoodName() throws RestaurantApplicationException
	{
		when(foodService.getAllRestaurantByFoodName(foodDto.getFoodName())).thenReturn(restaurantDtoList);
		List<RestaurantDto> restaurantList=foodController.getAllRestaurantByFoodName(foodDto.getFoodName()).getBody();
		assertEquals(restaurantDtoList, restaurantList);
	}
	@Test
	public void testaddFoodToRestaurantException() throws RestaurantApplicationException
	{
		when(restaurantService.addFoodToRestaurant(restaurantDto.getRestaurantId(),foodDto)).thenThrow(new ServiceException());
		assertThrows(RestaurantApplicationException.class, ()->foodController.addFoodToRestaurant(restaurantDto.getRestaurantId(),foodDto).getBody());
	}
	@Test
	public void testgetAllRestaurantByFoodNameException() throws RestaurantApplicationException
	{
		when(foodService.getAllRestaurantByFoodName(foodDto.getFoodName())).thenThrow(new ServiceException());
		assertThrows(RestaurantApplicationException.class, ()->foodController.getAllRestaurantByFoodName(foodDto.getFoodName()).getBody());
	}
	@Test
	public void testgetRestaurantsByLocationName() throws RestaurantApplicationException
	{
		when(locationService.getRestaurantsByLocationName(locationDto.getLocationName())).thenReturn(restaurantDtoList);
		List<RestaurantDto> restaurantList1=locationController.getRestaurantsByLocationName(locationDto.getLocationName()).getBody();
		assertEquals(restaurantDtoList, restaurantList1);
	}
	@Test
	public void testgetRestaurantsByLocationNameException() throws RestaurantApplicationException
	{
		when(locationService.getRestaurantsByLocationName(locationDto.getLocationName())).thenThrow(new ServiceException());
		assertThrows(RestaurantApplicationException.class, ()->locationController.getRestaurantsByLocationName(locationDto.getLocationName()));
	}
	@Test
	public void testgetAllDetails()
	{
		when(restaurantService.getAllDetails()).thenReturn(restaurantDetailsDtos);
		List<RestaurantDetailsDto> restaurantDetailsDtos1=restaurantController.getAllDetails().getBody();
		assertEquals(restaurantDetailsDtos, restaurantDetailsDtos1);
	}
	@Test
	public void testgetAllfoodByRestaurantName() throws RestaurantApplicationException
	{
		when(restaurantService.getAllfoodsByRestaurantName(restaurantDto.getRestaurantName())).thenReturn(restaurantDtoList);
		List<RestaurantDto> restaurantDtos1=restaurantController.getAllfoodByRestaurantName(restaurantDto.getRestaurantName()).getBody();
		assertEquals(restaurantDtoList,restaurantDtos1);
	}
	@Test
	public void testgetRestaurantByRestaurantId() throws RestaurantApplicationException
	{
		when(restaurantService.getResturantByRestaurantId(restaurantDto.getRestaurantId())).thenReturn(restaurantDto);
		RestaurantDto restaurantDto1=restaurantController.getRestaurantByRestaurantId(restaurantDto.getRestaurantId()).getBody();
		assertEquals(restaurantDto, restaurantDto1);
	}
	@Test
	public void testgetAllfoodByRestaurantNameException() throws RestaurantApplicationException
	{
		when(restaurantService.getAllfoodsByRestaurantName(restaurantDto.getRestaurantName())).thenThrow(new ServiceException());
		assertThrows(RestaurantApplicationException.class,()->restaurantController.getAllfoodByRestaurantName(restaurantDto.getRestaurantName()).getBody());
	}
	@Test
	public void testgetRestaurantByRestaurantIdException() throws RestaurantApplicationException
	{
		when(restaurantService.getResturantByRestaurantId(restaurantDto.getRestaurantId())).thenThrow(new ServiceException());
		assertThrows(RestaurantApplicationException.class,()->restaurantController.getRestaurantByRestaurantId(restaurantDto.getRestaurantId()).getBody());
	}
			

}










