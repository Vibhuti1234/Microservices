package com.mindtree.restaurantservice.service.impl;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.restaurantservice.dto.FoodDto;
import com.mindtree.restaurantservice.dto.RestaurantDetailsDto;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.entity.Food;
import com.mindtree.restaurantservice.entity.Restaurant;
import com.mindtree.restaurantservice.exception.RestaurantNotPresentException;
import com.mindtree.restaurantservice.exception.ServiceException;
import com.mindtree.restaurantservice.repository.RestaurantRepository;
import com.mindtree.restaurantservice.service.RestaurantService;

@Service
public class RestaurantServiceImpl implements RestaurantService {
	
	@Autowired
	private RestaurantRepository restaurantRepository;
	
	ModelMapper modelMapper =new ModelMapper();
	
	@Override
	public RestaurantDto addFoodToRestaurant(String restaurantId, FoodDto foodDto) throws ServiceException {
//		if(restaurantRepository.existsById(restaurantId))
//		{
		Restaurant restaurant=restaurantRepository.findById(restaurantId).orElseThrow(()->new RestaurantNotPresentException("Restaurant Not Present"));
		Food food=convertToEntity(foodDto);
		List<Food> foodlist=restaurant.getFoods();
		foodlist.add(food);
		foodlist.forEach(f->{
			f.setRestaurant(restaurant);
		});
		
//		for(Food f : foodlist)
//		{
//			f.setRestaurant(restaurant);
//		}
		restaurant.setFoods(foodlist);
		Restaurant restaurant1=restaurantRepository.save(restaurant);
		return convertToDto(restaurant1);
		}

//		else
//		{
//			throw new RestaurantNotPresentException("Restaurant Not Present");
//		}

	private RestaurantDto convertToDto(Restaurant restaurant1) {
		
		return modelMapper.map(restaurant1, RestaurantDto.class);
	}

	private Food convertToEntity(FoodDto foodDto) {
		
		return modelMapper.map(foodDto, Food.class);
	}
	@Override
	public List<RestaurantDto> getAllfoodsByRestaurantName(String restaurantName) throws ServiceException {
		List<Restaurant> restaurants=restaurantRepository.findAll();
		List<Restaurant> restaurantlist=new ArrayList<Restaurant>();
		List<RestaurantDto> restaurantDtos=new ArrayList<RestaurantDto>();
		restaurantlist = restaurants.stream().filter(restaurant->restaurant.getRestaurantName().equalsIgnoreCase(restaurantName)).collect(Collectors.toList());	
//		for(Restaurant r : restaurants)
//		{
//			if(r.getRestaurantName().equalsIgnoreCase(restaurantName))
//			{
//				restaurantlist.add(r);
//			}
//		}
		if(restaurantlist.isEmpty())
         {
	       throw new RestaurantNotPresentException("Restaurant Not present");
         }
         else
         {
        	 
//		for(Restaurant r : restaurantlist)
//		{
//			restaurantDtos.add(convertToDto(r));
//		}
        	 restaurantlist.forEach(r->{
        		 restaurantDtos.add(convertToDto(r));
     		}); 
         }
		return restaurantDtos;
	}
	
	@Override
	public List<RestaurantDetailsDto> getAllDetails() {
		
		List<Restaurant> restaurantlist=restaurantRepository.findAll();
		List<RestaurantDetailsDto> restaurantDtoList=new ArrayList<>();
		restaurantlist.forEach(f->restaurantDtoList.add(convertToDto1(f)));
//		for(Restaurant r : restaurantlist)
//		{
//			restaurantDtoList.add(convertToDto1(r));
//		}
		return restaurantDtoList;
	}
    private RestaurantDetailsDto convertToDto1 (Restaurant r) {		
		return modelMapper.map(r, RestaurantDetailsDto.class);
	}
	@Override
	public RestaurantDto getResturantByRestaurantId(String restaurantId) throws ServiceException {
		
		Restaurant restaurant=restaurantRepository.findById(restaurantId).orElseThrow(()->new RestaurantNotPresentException("Restaurant Not Present"));
		return convertToDto(restaurant);
	}
	
//		if(restaurantRepository.existsById(restaurantId))
//		{
//       Restaurant restaurant=restaurantRepository.findById(restaurantId).get();
//		return convertToDto(restaurant) ;
//		}
//		else
//		{
//			throw new RestaurantNotPresentException("restaurant Not Present");
//		}
//	}
	@Override
	public void deleteDataFromRestaurant(String restaurantId, String foodName, int quantity) {
	Restaurant restaurant=restaurantRepository.findById(restaurantId).get();
	List<Food> foodlist=restaurant.getFoods();
	
	foodlist.stream().filter(food->food.getFoodName().equalsIgnoreCase(foodName)).forEach(f->{
		f.setQuantity(f.getQuantity()-quantity);
			f.setRestaurant(restaurant)
			;});
//	for(Food f : foodlist)
//	{
//		if(f.getFoodName().equalsIgnoreCase(foodName))
//		{
//			f.setQuantity(f.getQuantity()-quantity);
//			f.setRestaurant(restaurant);
//		}
//	}
	restaurant.setFoods(foodlist);
	restaurantRepository.save(restaurant);
		
	}



}
