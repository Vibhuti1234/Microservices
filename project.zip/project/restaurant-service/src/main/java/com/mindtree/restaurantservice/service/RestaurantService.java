package com.mindtree.restaurantservice.service;

import java.util.List;

import com.mindtree.restaurantservice.dto.FoodDto;
import com.mindtree.restaurantservice.dto.RestaurantDetailsDto;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.exception.ServiceException;

public interface RestaurantService {

	List<RestaurantDto> getAllfoodsByRestaurantName(String restaurantName) throws ServiceException;

	RestaurantDto addFoodToRestaurant(String restaurantId, FoodDto foodDto) throws ServiceException;

	List<RestaurantDetailsDto> getAllDetails();

	RestaurantDto getResturantByRestaurantId(String restaurantId) throws ServiceException;

	void deleteDataFromRestaurant(String restaurantId, String foodName, int quantity);

}
