package com.mindtree.restaurantservice.service;
import java.util.List;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.exception.ServiceException;

public interface FoodService {

	List<RestaurantDto> getAllRestaurantByFoodName(String foodName) throws ServiceException;

}
