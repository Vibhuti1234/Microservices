package com.mindtree.restaurantservice.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.restaurantservice.dto.FoodDto;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.exception.RestaurantApplicationException;
import com.mindtree.restaurantservice.service.FoodService;
import com.mindtree.restaurantservice.service.RestaurantService;

@RestController
public class FoodController {
	
	@Autowired
	private RestaurantService restaurantService;
	
	@Autowired
	private FoodService foodService;
	

	@PostMapping("/addFoodToRestaurant/{restaurantId}")
	public ResponseEntity<RestaurantDto> addFoodToRestaurant(@PathVariable String restaurantId,@RequestBody FoodDto foodDto) throws RestaurantApplicationException
	{
		return new ResponseEntity<>(restaurantService.addFoodToRestaurant(restaurantId, foodDto),HttpStatus.OK);
		
	}
	@GetMapping("/getAllRestaurant/{foodName}")
	public ResponseEntity<List<RestaurantDto>> getAllRestaurantByFoodName(@PathVariable String foodName) throws RestaurantApplicationException
	{
		return new ResponseEntity<>(foodService.getAllRestaurantByFoodName(foodName),HttpStatus.OK);
	}

}
