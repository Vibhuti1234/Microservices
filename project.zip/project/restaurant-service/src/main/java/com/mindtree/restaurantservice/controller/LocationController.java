package com.mindtree.restaurantservice.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.exception.RestaurantApplicationException;
import com.mindtree.restaurantservice.service.LocationService;

@RestController
public class LocationController {
	
	@Autowired
	private LocationService locationService;
	
	@GetMapping("/getRestaurantByLocationName/{locationName}")
	public ResponseEntity<List<RestaurantDto>> getRestaurantsByLocationName(@PathVariable String locationName) throws RestaurantApplicationException
	{
		return new ResponseEntity<>(locationService.getRestaurantsByLocationName(locationName),HttpStatus.OK);
	}
	

}
