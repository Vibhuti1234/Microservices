package com.mindtree.restaurantservice.exception;
import javax.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
public class ControllerExceptionHandler{	
	@ExceptionHandler(RestaurantApplicationException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public ExceptionResponse handlerExceptionResponse(final RestaurantApplicationException exception,final HttpServletRequest request)
	{
		ExceptionResponse exp=new ExceptionResponse();
		exp.setErrorMessage(exception.getMessage());
		exp.setRequesturl(request.getRequestURI());
		return exp;
		
	}
}

