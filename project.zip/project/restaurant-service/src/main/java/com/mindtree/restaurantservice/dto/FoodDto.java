package com.mindtree.restaurantservice.dto;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class FoodDto implements Externalizable
{
	private String foodId;
	
	private String foodName;
	
	private int quantity;
	
	private int foodPrice;
	
	@JsonIgnore
	private RestaurantDto restaurantdto;

	public FoodDto() {
	}

	public String getFoodId() {
		return foodId;
	}

	public void setFoodId(String foodId) {
		this.foodId = foodId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(int foodPrice) {
		this.foodPrice = foodPrice;
	}

	public RestaurantDto getRestaurantdto() {
		return restaurantdto;
	}

	public void setRestaurantdto(RestaurantDto restaurantdto) {
		this.restaurantdto = restaurantdto;
	}

	@Override
	public void readExternal(ObjectInput arg0) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void writeExternal(ObjectOutput arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}
	
	

}
