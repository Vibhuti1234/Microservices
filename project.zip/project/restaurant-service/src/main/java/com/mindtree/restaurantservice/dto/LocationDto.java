package com.mindtree.restaurantservice.dto;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class LocationDto implements Externalizable {

	private String locationId;
	
	private String locationName;
	
	@JsonIgnore
	List<RestaurantDetailsDto> restaurantDtos;

	
	public LocationDto() {
		
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public List<RestaurantDetailsDto> getRestaurantDtos() {
		return restaurantDtos;
	}

	public void setRestaurantDtos(List<RestaurantDetailsDto> restaurantDtos) {
		this.restaurantDtos = restaurantDtos;
	}

	@Override
	public void readExternal(ObjectInput arg0) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void writeExternal(ObjectOutput arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}
	
	

}
