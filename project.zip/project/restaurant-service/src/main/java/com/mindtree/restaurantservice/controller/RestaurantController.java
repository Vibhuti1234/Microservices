package com.mindtree.restaurantservice.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.restaurantservice.dto.RestaurantDetailsDto;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.exception.RestaurantApplicationException;
import com.mindtree.restaurantservice.service.RestaurantService;

@RestController
public class RestaurantController {
	
	@Autowired
	private RestaurantService restaurantService;
	
	
	@GetMapping("/showAllDetails")
	public ResponseEntity<List<RestaurantDetailsDto>> getAllDetails()
	{
		return new ResponseEntity<>(restaurantService.getAllDetails(),HttpStatus.OK);	
	}
	@GetMapping("/getAllFood/{restaurantName}")
	public ResponseEntity<List<RestaurantDto>> getAllfoodByRestaurantName(@PathVariable String restaurantName) throws RestaurantApplicationException
	{
		return new ResponseEntity<>(restaurantService.getAllfoodsByRestaurantName(restaurantName),HttpStatus.OK);
	}
	@GetMapping("/getRestaurantById/{restaurantId}")
	public ResponseEntity<RestaurantDto> getRestaurantByRestaurantId(@PathVariable String restaurantId) throws RestaurantApplicationException
	{
		return new ResponseEntity<>(restaurantService.getResturantByRestaurantId(restaurantId),HttpStatus.OK);	
	}
	@DeleteMapping("/deleteFood/{restaurantId}/{foodName}/{quantity}")
	void deleteDataFromRestaurant(@PathVariable String restaurantId, @PathVariable String foodName,@PathVariable int quantity)
	{
		restaurantService.deleteDataFromRestaurant(restaurantId,foodName,quantity);
	}

}

