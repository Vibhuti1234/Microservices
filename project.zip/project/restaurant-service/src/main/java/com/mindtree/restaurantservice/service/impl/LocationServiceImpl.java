package com.mindtree.restaurantservice.service.impl;
import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.entity.Location;
import com.mindtree.restaurantservice.entity.Restaurant;
import com.mindtree.restaurantservice.exception.LocationDetailsNotAvailableException;
import com.mindtree.restaurantservice.exception.ServiceException;
import com.mindtree.restaurantservice.repository.LocationRepository;
import com.mindtree.restaurantservice.service.LocationService;

@Service
public class LocationServiceImpl implements LocationService {
	
	@Autowired
	private LocationRepository locationRepository;
	
	
	
	ModelMapper modelMapper=new ModelMapper();

	@Override
	public List<RestaurantDto> getRestaurantsByLocationName(String locationName) throws ServiceException {
		
		if(locationRepository.existsByLocationName(locationName))
		{
		Location location=locationRepository.findByLocationName(locationName);
		List<Restaurant> restaurantList=location.getRestaurants();
		List<RestaurantDto> restaurantDtos=new ArrayList<RestaurantDto>();
		for(Restaurant r : restaurantList)
		{
			restaurantDtos.add(convertToDto(r));
		}
		return restaurantDtos;
		}
		else
		{
			throw new LocationDetailsNotAvailableException("Location is Wrong");
		}
	}

	private RestaurantDto convertToDto(Restaurant r) {
		
		return modelMapper.map(r, RestaurantDto.class);
	}

	

}
