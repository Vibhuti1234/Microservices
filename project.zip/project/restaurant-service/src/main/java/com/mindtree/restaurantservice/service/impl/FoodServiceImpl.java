package com.mindtree.restaurantservice.service.impl;
import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.restaurantservice.dto.RestaurantDto;
import com.mindtree.restaurantservice.entity.Food;
import com.mindtree.restaurantservice.entity.Restaurant;
import com.mindtree.restaurantservice.exception.FoodNotAvailableException;
import com.mindtree.restaurantservice.exception.ServiceException;
import com.mindtree.restaurantservice.repository.FoodRepository;
import com.mindtree.restaurantservice.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService {
	
	@Autowired
	private FoodRepository foodRepository;
	
	ModelMapper modelMapper=new ModelMapper();

	@Override
	public List<RestaurantDto> getAllRestaurantByFoodName(String foodName) throws ServiceException
	{
		List<Food> foodList = foodRepository.findAll();
		List<Restaurant> restaurantList=new ArrayList<>();
		List<RestaurantDto> resultList=new ArrayList<>();
		for(Food f : foodList)
		{
			if(f.getFoodName().equalsIgnoreCase(foodName))
			{
				restaurantList.add(f.getRestaurant());
			}
		}
		if(restaurantList.isEmpty())
		{
			throw new FoodNotAvailableException("This Food is not Available");
		}
		else
		{
			 for(Restaurant r : restaurantList)
			   {
				resultList.add(convertToDto(r));
			   }
		}
		return resultList;
	}
	private RestaurantDto convertToDto(Restaurant r) {
		
		return modelMapper.map(r, RestaurantDto.class);
	}

}
