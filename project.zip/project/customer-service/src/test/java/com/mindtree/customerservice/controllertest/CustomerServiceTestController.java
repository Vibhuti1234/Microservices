package com.mindtree.customerservice.controllertest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.mindtree.customerservice.controller.CustomerController;
import com.mindtree.customerservice.dto.CartDto;
import com.mindtree.customerservice.dto.CustomerDto;
import com.mindtree.customerservice.dto.FoodDto;
import com.mindtree.customerservice.dto.LocationDto;
import com.mindtree.customerservice.dto.OrderDto;
import com.mindtree.customerservice.dto.RestaurantDetailsDto;
import com.mindtree.customerservice.dto.RestaurantDto;
import com.mindtree.customerservice.exception.CustomerApplicationException;
import com.mindtree.customerservice.exception.ServiceException;
import com.mindtree.customerservice.service.CustomerService;

@SpringBootTest
public class CustomerServiceTestController {
	
	@InjectMocks
	CustomerController customerController;
	
	@Mock
	CustomerService customerService;
	
	private List<RestaurantDetailsDto> restaurantDetailsDto;
	
	private FoodDto foodDto;
	
	private RestaurantDto restaurantDto;
	
	private List<RestaurantDto> restaurantDtoList;
	
	private List<FoodDto> foodDtos;
	
	private LocationDto locationDto;
	
	private CustomerDto customerDto;
	
	private CartDto cartDto;
	
	private OrderDto orderDto;
	
	private List<String> foodNames;
	
	@BeforeEach
	void  setUp()
	{
		MockitoAnnotations.initMocks(this);
		restaurantDetailsDto=getRestaurantDetailsDto();
		foodDto=getFoodDto();
		restaurantDto=getRestaurantDto();
		restaurantDtoList=getRestaurantDtos();
		foodDtos=getFoodDtos();
		locationDto=getLocationDto();
		customerDto=getCustomerDto();
		cartDto=getCartDto();
		orderDto=getOrderDto();
		foodNames=getFoodNames();
	}
	private List<String> getFoodNames() {
		List<String> foodNames1=new ArrayList<String>();
		foodNames1.add("food1");
		foodNames1.add("food2");
		return foodNames1;
	}
	private OrderDto getOrderDto() {
		OrderDto orderDto1=new OrderDto();
		orderDto1.setCustomerId("customerId");
		orderDto1.setCustomerName("customerName");
		orderDto1.setDate(java.sql.Date.valueOf(java.time.LocalDate.now()));
		orderDto1.setRestaurantName("restaurantName");
		orderDto1.setTotalPrice(123.8);
		orderDto1.setFoodNames(foodNames);
		return orderDto1;
	}
	private CartDto getCartDto() {
		CartDto cartDto1=new CartDto();
		cartDto1.setCartId(123);
		cartDto1.setCustomerId("customerId");
		cartDto1.setFoodName("foodName");
		cartDto1.setPrice(123);
		cartDto1.setQuantity(12);
		cartDto1.setRestaurantId("restaurantId");
		cartDto1.setRestaurantName("restaurantName");
		return cartDto1;
	}
	private CustomerDto getCustomerDto() {
		CustomerDto customerDto1=new CustomerDto();
		customerDto1.setCustomerId("customerId");
		customerDto1.setCustomerName("customerName");
		customerDto1.setCustomerAddress("customerAddress");
		customerDto1.setEmailId("emailId");
		return customerDto1;
	}
	private LocationDto getLocationDto() {
		LocationDto locationDto1=new LocationDto();
		locationDto1.setLocationId("locationId");
		locationDto1.setLocationName("locationName");
		locationDto1.setRestaurantDtos(restaurantDtoList);
		return locationDto1;
	}
	private List<FoodDto> getFoodDtos() {
		
		List<FoodDto> foodDtoList=new ArrayList<FoodDto>();
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(12);
		foodDto1.setRestaurantdto(restaurantDto);
		foodDtoList.add(foodDto1);
		return foodDtoList;
	}
	private List<RestaurantDto> getRestaurantDtos() {
		List<RestaurantDto> restaurantDetailsDtos1=new ArrayList<RestaurantDto>();
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		restaurantDetailsDtos1.add(restaurantDto1);
		return restaurantDetailsDtos1;
	}
	private RestaurantDto getRestaurantDto() {
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		return restaurantDto1;
	}
	private FoodDto getFoodDto() {
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(5);
		foodDto1.setRestaurantdto(restaurantDto);
		return foodDto1;
	}
	private List<RestaurantDetailsDto> getRestaurantDetailsDto() {
		List<RestaurantDetailsDto> restaurantDetailsDtos=new ArrayList<RestaurantDetailsDto>();
		RestaurantDetailsDto restaurantDetailsDto=new RestaurantDetailsDto();
		restaurantDetailsDto.setRestaurantId("restaurantId");
		restaurantDetailsDto.setRestaurantName("restaurantName");
		restaurantDetailsDto.setLocation(locationDto);
		restaurantDetailsDto.setFoods(foodDtos);
		restaurantDetailsDtos.add(restaurantDetailsDto);
		return restaurantDetailsDtos;
	}
	@Test
	public void testgetAllDetails()
	{
		when(customerService.getAllDetails()).thenReturn(restaurantDetailsDto);
		List<RestaurantDetailsDto> restaurantDetailsDtos1=customerController.getAllDetails().getBody();
		assertEquals(restaurantDetailsDto, restaurantDetailsDtos1);
	}
	@Test
	public void testgetAllfoodByRestaurantName() throws CustomerApplicationException
	{
		when(customerService.getAllfoodByRestaurantName(restaurantDto.getRestaurantName())).thenReturn(restaurantDetailsDto);
		List<RestaurantDetailsDto> restaurantDetailsDtos1=customerController.getAllfoodByRestaurantName(restaurantDto.getRestaurantName()).getBody();
		assertEquals(restaurantDetailsDto, restaurantDetailsDtos1);
	}
	@Test
	public void testgetAllRestaurantByFoodName() throws CustomerApplicationException
	{
		when(customerService.getAllRestaurantByFoodName(foodDto.getFoodName())).thenReturn(restaurantDtoList);
		List<RestaurantDto> restaurantDtos=customerController.getAllRestaurantByFoodName(foodDto.getFoodName()).getBody();
		assertEquals(restaurantDtoList, restaurantDtos );
		
	}
	@Test
	public void testgetRestaurantsByLocationName() throws CustomerApplicationException
	{
		when(customerService.getRestaurantsByLocationName(locationDto.getLocationName())).thenReturn(restaurantDtoList);
		List<RestaurantDto> restaurantDtos=customerController.getRestaurantsByLocationName(locationDto.getLocationName()).getBody();
		assertEquals(restaurantDtoList, restaurantDtos);
	}
	@Test
	public void testaddToCart() throws CustomerApplicationException
	{
		when(customerService.addToCart(customerDto.getCustomerId(), restaurantDto.getRestaurantId(), foodDto.getFoodName(), foodDto.getQuantity())).thenReturn(cartDto);
		CartDto cartDto1=customerController.addToCart(customerDto.getCustomerId(), restaurantDto.getRestaurantId(), foodDto.getFoodName(), foodDto.getQuantity()).getBody();
		assertEquals(cartDto, cartDto1);
	}
	@Test
	public void testplaceOrder() throws CustomerApplicationException
	{
		when(customerService.placeOrder(customerDto.getCustomerId())).thenReturn(orderDto);
		OrderDto orderDto1=customerController.placeOrder(customerDto.getCustomerId()).getBody();
		assertEquals(orderDto, orderDto1);
	}
	@Test
	public void testgetAllfoodByRestaurantNameException() throws CustomerApplicationException
	{
		when(customerService.getAllfoodByRestaurantName(restaurantDto.getRestaurantName())).thenThrow(new ServiceException());
		assertThrows(CustomerApplicationException.class,()->customerController.getAllfoodByRestaurantName(restaurantDto.getRestaurantName()).getBody());
	}
	@Test
	public void testgetAllRestaurantByFoodNameException() throws CustomerApplicationException
	{
		when(customerService.getAllRestaurantByFoodName(foodDto.getFoodName())).thenThrow(new ServiceException());
       assertThrows(CustomerApplicationException.class,()->customerController.getAllRestaurantByFoodName(foodDto.getFoodName()).getBody());
	}
	@Test
	public void testgetRestaurantsByLocationNameException() throws CustomerApplicationException
	{
		when(customerService.getRestaurantsByLocationName(locationDto.getLocationName())).thenThrow(new ServiceException());
	    assertThrows(CustomerApplicationException.class,()->customerController.getRestaurantsByLocationName(locationDto.getLocationName()).getBody());
	}
	@Test
	public void testaddToCartException() throws CustomerApplicationException
	{
		when(customerService.addToCart(customerDto.getCustomerId(), restaurantDto.getRestaurantId(), foodDto.getFoodName(), foodDto.getQuantity())).thenThrow(new ServiceException());
		 assertThrows(CustomerApplicationException.class,()->customerController.addToCart(customerDto.getCustomerId(), restaurantDto.getRestaurantId(), foodDto.getFoodName(), foodDto.getQuantity()).getBody());
	}
	@Test
	public void testPlaceOrderException() throws CustomerApplicationException
	{
		when(customerService.placeOrder(customerDto.getCustomerId())).thenThrow(new ServiceException());
		assertThrows(CustomerApplicationException.class, ()->customerController.placeOrder(customerDto.getCustomerId()).getBody());
	}
}
