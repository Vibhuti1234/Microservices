package com.mindtree.customerservice.servicetest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import com.mindtree.customerservice.dto.FoodDto;
import com.mindtree.customerservice.dto.LocationDto;
import com.mindtree.customerservice.dto.RestaurantDetailsDto;
import com.mindtree.customerservice.dto.RestaurantDto;
import com.mindtree.customerservice.exception.ServiceException;
import com.mindtree.customerservice.proxy.CartProxy;
import com.mindtree.customerservice.proxy.OrderProxy;
import com.mindtree.customerservice.proxy.RestaurantProxy;
import com.mindtree.customerservice.repository.CustomerRepository;
import com.mindtree.customerservice.service.impl.CustomerServiceImpl;

@SpringBootTest
public class CustomerServiceTestService {
	
	@InjectMocks
	CustomerServiceImpl customerServiceImpl;
	
	@Mock
	RestaurantProxy restaurantProxy;
	
	@Mock
	CartProxy cartProxy;
	
	@Mock
	OrderProxy orderProxy;
	
	@Mock
	CustomerRepository customerRepository;
	
	
	private List<RestaurantDetailsDto> restaurantDetailsDto;
	
	private List<FoodDto> foodDtos;
	
	private LocationDto locationDto;
	
	private RestaurantDto restaurantDto;
	
	private List<RestaurantDto> restaurantDtoList;
	
	@BeforeEach
	void setUp()
	{
		MockitoAnnotations.initMocks(this);
		foodDtos=getFoodDtos();
		locationDto=getLocationDto();
		restaurantDto=getRestaurantDto();
		restaurantDtoList=getRestaurantDtos();
		restaurantDetailsDto=getRestaurantDetailsDto();
		
	}
	private List<RestaurantDetailsDto> getRestaurantDetailsDto() {
	List<RestaurantDetailsDto> restaurantDetailsDtos=new ArrayList<RestaurantDetailsDto>();
	RestaurantDetailsDto restaurantDetailsDto1=new RestaurantDetailsDto();
	restaurantDetailsDto1.setRestaurantId("restaurantId");
	restaurantDetailsDto1.setRestaurantName("restaurantName");
	restaurantDetailsDto1.setLocation(locationDto);
	restaurantDetailsDto1.setFoods(foodDtos);
	restaurantDetailsDtos.add(restaurantDetailsDto1);
	return restaurantDetailsDtos;
	}
	private LocationDto getLocationDto() {
		LocationDto locationDto1=new LocationDto();
		locationDto1.setLocationId("locationId");
		locationDto1.setLocationName("locationName");
		locationDto1.setRestaurantDtos(restaurantDtoList);
		return locationDto1;
	}
	private List<FoodDto> getFoodDtos() {
		
		List<FoodDto> foodDtoList=new ArrayList<FoodDto>();
		FoodDto foodDto1=new FoodDto();
		foodDto1.setFoodId("foodId");
		foodDto1.setFoodName("foodName");
		foodDto1.setFoodPrice(123);
		foodDto1.setQuantity(12);
		foodDto1.setRestaurantdto(restaurantDto);
		foodDtoList.add(foodDto1);
		return foodDtoList;
	}
	private RestaurantDto getRestaurantDto() {
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		return restaurantDto1;
	}
	private List<RestaurantDto> getRestaurantDtos() {
		List<RestaurantDto> restaurantDetailsDtos1=new ArrayList<RestaurantDto>();
		RestaurantDto restaurantDto1=new RestaurantDto();
		restaurantDto1.setRestaurantId("restaurantId");
		restaurantDto1.setRestaurantName("restaurantName");
		restaurantDto1.setLocation(locationDto);
		restaurantDto1.setFoods(foodDtos);
		restaurantDetailsDtos1.add(restaurantDto1);
		return restaurantDetailsDtos1;
	}
	@Test
	public void testgetAllDetails()
	{
		when(restaurantProxy.getAllDetails().getBody()).thenReturn(restaurantDetailsDto);
		when(customerServiceImpl.getAllDetails()).thenReturn(restaurantDetailsDto);
		List<RestaurantDetailsDto> restaurantDetailsDtos1=customerServiceImpl.getAllDetails();
		assertEquals(restaurantDetailsDto, restaurantDetailsDtos1);
	}
	@Test
	public void testgetAllfoodByRestaurantName() throws ServiceException 
	{

//		when(restaurantProxy.getAllfoodByRestaurantName(restaurantDto.getRestaurantName()).getBody()).thenReturn(restaurantDetailsDto);
//		List<RestaurantDetailsDto> restaurantDetailsDtos1=customerServiceImpl.getAllfoodByRestaurantName(restaurantDto.getRestaurantName());
//		assertEquals(restaurantDetailsDto, restaurantDetailsDtos1);
	}
}
