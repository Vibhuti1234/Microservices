package com.mindtree.customerservice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class RestaurantDto {
	
	    private String restaurantId;
		
		private String restaurantName;
		
		@JsonIgnore
		private List<FoodDto> foods;
		
		private LocationDto location;

		public RestaurantDto() {
			
		}

		public String getRestaurantId() {
			return restaurantId;
		}

		public void setRestaurantId(String restaurantId) {
			this.restaurantId = restaurantId;
		}

		public String getRestaurantName() {
			return restaurantName;
		}

		public void setRestaurantName(String restaurantName) {
			this.restaurantName = restaurantName;
		}

		public List<FoodDto> getFoods() {
			return foods;
		}

		public void setFoods(List<FoodDto> foods) {
			this.foods = foods;
		}

		public LocationDto getLocation() {
			return location;
		}

		public void setLocation(LocationDto location) {
			this.location = location;
		}


}
