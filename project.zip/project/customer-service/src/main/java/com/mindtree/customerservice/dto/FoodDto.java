package com.mindtree.customerservice.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class FoodDto {
	
    private String foodId;
	
	private String foodName;
	
	private int quantity;
	
	private int foodPrice;
	
	@JsonIgnore
	private RestaurantDto restaurantdto;

	public FoodDto() {
	}

	public String getFoodId() {
		return foodId;
	}

	public void setFoodId(String foodId) {
		this.foodId = foodId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getFoodPrice() {
		return foodPrice;
	}

	public void setFoodPrice(int foodPrice) {
		this.foodPrice = foodPrice;
	}

	public RestaurantDto getRestaurantdto() {
		return restaurantdto;
	}

	public void setRestaurantdto(RestaurantDto restaurantdto) {
		this.restaurantdto = restaurantdto;
	}
	

}
