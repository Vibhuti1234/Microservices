package com.mindtree.customerservice.service.impl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.customerservice.dto.CartDto;
import com.mindtree.customerservice.dto.OrderDto;
import com.mindtree.customerservice.dto.RestaurantDetailsDto;
import com.mindtree.customerservice.dto.RestaurantDto;
import com.mindtree.customerservice.entity.Customer;
import com.mindtree.customerservice.exception.CustomerNotPresentException;
import com.mindtree.customerservice.exception.ServiceException;
import com.mindtree.customerservice.proxy.CartProxy;
import com.mindtree.customerservice.proxy.OrderProxy;
import com.mindtree.customerservice.proxy.RestaurantProxy;
import com.mindtree.customerservice.repository.CustomerRepository;
import com.mindtree.customerservice.service.CustomerService;

import feign.FeignException;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	RestaurantProxy restaurantProxy;
	
	@Autowired
	CartProxy CartProxy;
	
	@Autowired
	OrderProxy orderProxy;
	
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public List<RestaurantDetailsDto> getAllDetails() {
		
		List<RestaurantDetailsDto> liRestaurantDetailsDtos= restaurantProxy.getAllDetails().getBody();
		return liRestaurantDetailsDtos;

	}
	@Override
	public List<RestaurantDetailsDto> getAllfoodByRestaurantName(String restaurantName) throws ServiceException {
		try
		{
		return restaurantProxy.getAllfoodByRestaurantName(restaurantName).getBody();
		}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
	}

	@Override
	public List<RestaurantDto> getAllRestaurantByFoodName(String foodName) throws ServiceException {
		try
		{
		return restaurantProxy.getAllRestaurantByFoodName(foodName).getBody();
		}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
	}

	@Override
	public List<RestaurantDto> getRestaurantsByLocationName(String locationName) throws ServiceException {
		
		try
		{
		return restaurantProxy.getRestaurantsByLocationName(locationName).getBody();
	    }
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
	}

	@Override
	public CartDto addToCart(String customerId, String restaurantId, String foodName,int quantity) throws ServiceException {
		if(customerRepository.existsById(customerId))
		{
		try
			{
	     return CartProxy.addToCart(customerId, restaurantId, foodName,quantity).getBody();
			}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
		}
		else
		{
			throw new CustomerNotPresentException("Customer Not Present");
		}
	}
	@Override
	public OrderDto placeOrder(String customerId) throws ServiceException {
		
		if(customerRepository.existsById(customerId))
		{
		Customer customer=customerRepository.findById(customerId).get();
		try
		{
		return orderProxy.placeOrder(customerId,customer.getCustomerName()).getBody(); 
		}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
		}
		else
		{
			throw new CustomerNotPresentException("Customer Not Present");
		}
		
	}

	@Override
	public List<OrderDto> getOrderDetails(String customerId) throws ServiceException {
		try
		{
		return orderProxy.getOrderDetails(customerId).getBody();
		}
		catch(FeignException e)
		{
			throw new ServiceException(e.contentUTF8());
		}
	}

}
