package com.mindtree.customerservice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class LocationDto {
	
	 private String locationId;
		
		private String locationName;
		
		@JsonIgnore
		List<RestaurantDto> restaurantDtos;
		
		public LocationDto() {
			
		}

		public String getLocationId() {
			return locationId;
		}

		public void setLocationId(String locationId) {
			this.locationId = locationId;
		}

		public String getLocationName() {
			return locationName;
		}

		public void setLocationName(String locationName) {
			this.locationName = locationName;
		}

		public List<RestaurantDto> getRestaurantDtos() {
			return restaurantDtos;
		}

		public void setRestaurantDtos(List<RestaurantDto> restaurantDtos) {
			this.restaurantDtos = restaurantDtos;
		}
		

}
