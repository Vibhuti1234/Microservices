package com.mindtree.customerservice.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.customerservice.dto.OrderDto;
@FeignClient(name="order-service")
public interface OrderProxy {
	
	@GetMapping("/placeOrder/{customerId}/{customerName}")
	public ResponseEntity<OrderDto> placeOrder(@PathVariable String customerId,@PathVariable String customerName);
	
	@GetMapping("getOrderdetails/{customerId}")
	public ResponseEntity<List<OrderDto>> getOrderDetails(@PathVariable String customerId);

}
