package com.mindtree.customerservice.proxy;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.mindtree.customerservice.dto.RestaurantDetailsDto;
import com.mindtree.customerservice.dto.RestaurantDto;


@FeignClient(name="restaurant-service")
public interface RestaurantProxy {
	
	@GetMapping("/showAllDetails")
	public ResponseEntity<List<RestaurantDetailsDto>> getAllDetails();
	
	@GetMapping("/getAllFood/{restaurantName}")
	public ResponseEntity<List<RestaurantDetailsDto>> getAllfoodByRestaurantName(@PathVariable String restaurantName);
	
	@GetMapping("/getAllRestaurant/{foodName}")
	public ResponseEntity<List<RestaurantDto>> getAllRestaurantByFoodName(@PathVariable String foodName);
	
	@GetMapping("/getRestaurantByLocationName/{locationName}")
	public ResponseEntity<List<RestaurantDto>> getRestaurantsByLocationName(@PathVariable String locationName);
}
