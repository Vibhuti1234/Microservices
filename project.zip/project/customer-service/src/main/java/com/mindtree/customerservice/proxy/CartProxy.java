package com.mindtree.customerservice.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.customerservice.dto.CartDto;

@FeignClient(name="cart-service")
public interface CartProxy {
	
	@GetMapping("AddToCart/{customerId}/{restaurantId}/{foodName}/{quantity}")
	public ResponseEntity<CartDto> addToCart(@PathVariable String customerId, @PathVariable String restaurantId, @PathVariable String foodName,@PathVariable int quantity);
	

}
