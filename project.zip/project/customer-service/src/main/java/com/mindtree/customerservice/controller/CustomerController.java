package com.mindtree.customerservice.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.mindtree.customerservice.dto.CartDto;
import com.mindtree.customerservice.dto.OrderDto;
import com.mindtree.customerservice.dto.RestaurantDetailsDto;
import com.mindtree.customerservice.dto.RestaurantDto;
import com.mindtree.customerservice.exception.CustomerApplicationException;
import com.mindtree.customerservice.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	
	@GetMapping("/showAllDetails")
	public ResponseEntity<List<RestaurantDetailsDto>> getAllDetails()
	{
		return new ResponseEntity<List<RestaurantDetailsDto>>(customerService.getAllDetails(),HttpStatus.OK);	
	}
	
	
	@GetMapping("/getAllFood/{restaurantName}")
	public ResponseEntity<List<RestaurantDetailsDto>> getAllfoodByRestaurantName(@PathVariable String restaurantName) throws CustomerApplicationException{
		
		return new ResponseEntity<List<RestaurantDetailsDto>>(customerService.getAllfoodByRestaurantName(restaurantName),HttpStatus.OK);
	}
	

	@GetMapping("/getAllRestaurant/{foodName}")
	public ResponseEntity<List<RestaurantDto>> getAllRestaurantByFoodName(@PathVariable String foodName) throws CustomerApplicationException{
		return new ResponseEntity<List<RestaurantDto>>(customerService.getAllRestaurantByFoodName(foodName),HttpStatus.OK);
	}
	
	
	@GetMapping("/getRestaurantByLocationName/{locationName}")
	public ResponseEntity<List<RestaurantDto>> getRestaurantsByLocationName(@PathVariable String locationName) throws CustomerApplicationException{
		return new ResponseEntity<List<RestaurantDto>>(customerService.getRestaurantsByLocationName(locationName),HttpStatus.OK);
	}
	
	@GetMapping("AddToCart/{customerId}/{restaurantId}/{foodName}/{quantity}")
	public ResponseEntity<CartDto> addToCart(@PathVariable String customerId, @PathVariable String restaurantId, @PathVariable String foodName,@PathVariable int quantity) throws CustomerApplicationException
	{
		return new ResponseEntity<CartDto>(customerService.addToCart(customerId,restaurantId,foodName,quantity),HttpStatus.OK);
	}
	
	@GetMapping("/placeOrder/{customerId}")
	public ResponseEntity<OrderDto> placeOrder(@PathVariable String customerId) throws CustomerApplicationException
	{
		return new ResponseEntity<OrderDto>(customerService.placeOrder(customerId),HttpStatus.OK);
	}
	@GetMapping("/getOrderDetails/{customerId}")
	public ResponseEntity<List<OrderDto>> getOrderDetails(@PathVariable String customerId) throws CustomerApplicationException
	{
		return new ResponseEntity<List<OrderDto>>(customerService.getOrderDetails(customerId),HttpStatus.OK);
	}
	
	
}
