package com.mindtree.customerservice.service;
import java.util.List;
import com.mindtree.customerservice.dto.CartDto;
import com.mindtree.customerservice.dto.OrderDto;
import com.mindtree.customerservice.dto.RestaurantDetailsDto;
import com.mindtree.customerservice.dto.RestaurantDto;
import com.mindtree.customerservice.exception.ServiceException;

public interface CustomerService {

	List<RestaurantDetailsDto> getAllDetails();

	List<RestaurantDetailsDto> getAllfoodByRestaurantName(String restaurantName) throws ServiceException;

	List<RestaurantDto> getAllRestaurantByFoodName(String foodName) throws ServiceException;

	List<RestaurantDto> getRestaurantsByLocationName(String locationName) throws ServiceException;

	CartDto addToCart(String customerId, String restaurantId, String foodName, int quantity) throws ServiceException;

	OrderDto placeOrder(String customerId) throws ServiceException;

	List<OrderDto> getOrderDetails(String customerId) throws ServiceException;

}
