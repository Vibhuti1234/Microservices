package com.mindtree.microservices.bookingservice.dto;

public class ResponseDto<T> {
	private T data;
	private ErrorDto error;
	private String message;
	private boolean success;
	public ResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ResponseDto(T data, ErrorDto error, String message, boolean success) {
		super();
		this.data = data;
		this.error = error;
		this.message = message;
		this.success = success;
	}
	/**
	 * @return the data
	 */
	public T getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(T data) {
		this.data = data;
	}
	/**
	 * @return the error
	 */
	public ErrorDto getError() {
		return error;
	}
	/**
	 * @param error the error to set
	 */
	public void setError(ErrorDto error) {
		this.error = error;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * @return the success
	 */
	public boolean isSuccess() {
		return success;
	}
	/**
	 * @param success the success to set
	 */
	public void setSuccess(boolean success) {
		this.success = success;
	}
	
}
