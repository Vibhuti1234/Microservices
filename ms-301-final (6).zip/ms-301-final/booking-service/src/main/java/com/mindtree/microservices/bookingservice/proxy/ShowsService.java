package com.mindtree.microservices.bookingservice.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.mindtree.microservices.bookingservice.dto.ResponseDto;
import com.mindtree.microservices.bookingservice.dto.ShowsDto;

@FeignClient(name="movie-catalog-service",url="localhost:8080")
public interface ShowsService {
	@GetMapping(value="/getShowById/{showId}")
	public  ResponseEntity<ResponseDto<ShowsDto>> getShowById(@PathVariable("showId") String showId) ;
	
	

	


}
