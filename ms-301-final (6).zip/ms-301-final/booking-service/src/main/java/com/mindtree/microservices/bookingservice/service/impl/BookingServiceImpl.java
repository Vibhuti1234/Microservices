package com.mindtree.microservices.bookingservice.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.bookingservice.dto.BookingDto;
import com.mindtree.microservices.bookingservice.dto.ShowsDto;
import com.mindtree.microservices.bookingservice.entity.Booking;
import com.mindtree.microservices.bookingservice.exception.BookingServiceApplicationException;
import com.mindtree.microservices.bookingservice.exception.NoBookingFoundException;
import com.mindtree.microservices.bookingservice.exception.NoSeatsAvailableException;
import com.mindtree.microservices.bookingservice.exception.NoSuchBookingFoundException;
import com.mindtree.microservices.bookingservice.exception.NoSuchShowAvailableException;
import com.mindtree.microservices.bookingservice.proxy.ShowsService;
import com.mindtree.microservices.bookingservice.repository.BookingRepository;
import com.mindtree.microservices.bookingservice.service.BookingService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class BookingServiceImpl implements BookingService {
	private ModelMapper modelMapper = new ModelMapper();
	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	private ShowsService showsService;

	@HystrixCommand(fallbackMethod = "bookShowFallback", commandProperties = {

			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "10000"),

			@HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value = "5"),

			@HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value = "50"),

			@HystrixProperty(name = "circuitBreaker.sleepWindowInMilliseconds", value = "10000"), })

	public Booking bookShow(String showId) throws BookingServiceApplicationException {
		// TODO Auto-generated method stub
		ShowsDto showsDto = showsService.getShowById(showId).getBody().getData();

		if (showsDto == null) {
			throw new NoSuchShowAvailableException("No such show available");
		}
		if (showsDto.getTotalFreeSeats() <= 0) {
			throw new NoSeatsAvailableException("No seats available for booking");
		}
		showsDto.setTotalBookedSeats(showsDto.getTotalBookedSeats() + 1);
		showsDto.setTotalFreeSeats(showsDto.getTotalFreeSeats() - 1);
		Booking booking = new Booking();
		booking.setShowId(showsDto.getShowId());
		int confirmationNumber = (int) ((Math.random() * (10000 - 1000)) + 1000);
		booking.setConfirmationNumber(confirmationNumber);
		bookingRepository.save(booking);
		return 	booking;

	}

	public Booking bookShowFallback(String showId) {
		Booking booking = new Booking("Unable to reach the server no response is comming session timed out!");
		return booking;
	}

	@Override
	public BookingDto getBookingById(int bookingId) throws BookingServiceApplicationException {
		// TODO Auto-generated method stub
		Booking booking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new NoSuchBookingFoundException("invalid booking id!"));
		return convertEntityToDto(booking);
	}

	private BookingDto convertEntityToDto(Booking booking) {
		// TODO Auto-generated method stub
		return modelMapper.map(booking, BookingDto.class);
	}

	@Override
	public List<BookingDto> getAllBookings() throws BookingServiceApplicationException {
		// TODO Auto-generated method stub
		List<BookingDto> bookingDtos = bookingRepository.findAll().stream().map(booking -> convertEntityToDto(booking))
				.collect(Collectors.toList());
		if (bookingDtos == null || bookingDtos.isEmpty()) {
			throw new NoBookingFoundException("No booking available!");
		}

		return bookingDtos;
	}

}
