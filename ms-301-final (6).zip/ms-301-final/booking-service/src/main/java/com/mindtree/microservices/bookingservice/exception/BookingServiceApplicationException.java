package com.mindtree.microservices.bookingservice.exception;

public class BookingServiceApplicationException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BookingServiceApplicationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookingServiceApplicationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public BookingServiceApplicationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BookingServiceApplicationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BookingServiceApplicationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
