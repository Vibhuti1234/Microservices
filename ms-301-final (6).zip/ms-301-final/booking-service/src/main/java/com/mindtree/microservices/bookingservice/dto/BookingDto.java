package com.mindtree.microservices.bookingservice.dto;

public class BookingDto {
	private int bookingId;
	private int confirmationNumber;
	private String showId;
	public BookingDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	


	public BookingDto(int bookingId, int confirmationNumber, String showId) {
		super();
		this.bookingId = bookingId;
		this.confirmationNumber = confirmationNumber;
		this.showId = showId;
	}




	/**
	 * @return the bookingId
	 */
	public int getBookingId() {
		return bookingId;
	}
	/**
	 * @param bookingId the bookingId to set
	 */
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	/**
	 * @return the confirmationNumber
	 */
	public int getConfirmationNumber() {
		return confirmationNumber;
	}
	/**
	 * @param confirmationNumber the confirmationNumber to set
	 */
	public void setConfirmationNumber(int confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}




	public String getShowId() {
		return showId;
	}




	public void setShowId(String showId) {
		this.showId = showId;
	}

	
	
	
	
}
