package com.mindtree.microservices.bookingservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.elasticsearch.search.SearchService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.bookingservice.dto.BookingDto;
import com.mindtree.microservices.bookingservice.dto.ResponseDto;
import com.mindtree.microservices.bookingservice.dto.ShowsDto;
import com.mindtree.microservices.bookingservice.entity.Booking;
import com.mindtree.microservices.bookingservice.exception.BookingServiceApplicationException;
import com.mindtree.microservices.bookingservice.exception.NoBookingAvailableException;
import com.mindtree.microservices.bookingservice.exception.NoBookingFoundException;
import com.mindtree.microservices.bookingservice.exception.NoSeatsAvailableException;
import com.mindtree.microservices.bookingservice.exception.NoSuchBookingFoundException;
import com.mindtree.microservices.bookingservice.exception.NoSuchShowAvailableException;
import com.mindtree.microservices.bookingservice.proxy.ShowsService;
import com.mindtree.microservices.bookingservice.repository.BookingRepository;
import com.mindtree.microservices.bookingservice.service.impl.BookingServiceImpl;

@SpringBootTest
public class BookingServiceImplTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	private BookingServiceImpl bookingServiceImpl;
	@Mock
	private ShowsService showsService;
	@Mock
	private BookingRepository bookingRepository;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(bookingServiceImpl).build();
	}
     @Test
     public void bookShowTest() throws BookingServiceApplicationException
     {
    	 Booking booking=new Booking();
    	 
    	 ShowsDto showsDto=new ShowsDto();
         booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 booking.setShowId("S1");
    	 showsDto.setShowId("S1");
    	 showsDto.setTotalFreeSeats(4);
    	 ResponseDto<ShowsDto> response = new ResponseDto<ShowsDto>(showsDto, null,
 				"show details fetched successfully", true);
        
    	 Mockito.when(showsService.getShowById(Mockito.anyString())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
    	 Mockito.when(bookingRepository.save(booking)).thenReturn(booking);
    	 assertNotNull(bookingServiceImpl.bookShow("S1"));
     }
     @Test(expected=NoSuchShowAvailableException.class)
     public void bookShowTestForException() throws BookingServiceApplicationException
     {
Booking booking=new Booking();
    	 
    	 ShowsDto showsDto=null;
    	 booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 ResponseDto<ShowsDto> response = new ResponseDto<ShowsDto>(showsDto, null,
 				"show details fetched successfully", true);

    	 Mockito.when(showsService.getShowById(Mockito.anyString())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
    	 
    	  bookingServiceImpl.bookShow("S1");
     }
     @Test(expected=NoSeatsAvailableException.class)
     public void bookShowTestForException2() throws BookingServiceApplicationException
     {
Booking booking=new Booking();
    	 
    	 ShowsDto showsDto=new ShowsDto();
    	 booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 showsDto.setShowId("S1");
    	 showsDto.setTotalFreeSeats(0);
    	 ResponseDto<ShowsDto> response = new ResponseDto<ShowsDto>(showsDto, null,
 				"show details fetched successfully", true);

    	 Mockito.when(showsService.getShowById(Mockito.anyString())).thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
    	 
    	  bookingServiceImpl.bookShow("S1");
     }
     @Test
     public void getAllBookingsTest() throws BookingServiceApplicationException
     {
    	 Booking booking=new Booking();
    	 booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 booking.setShowId("S1");
    	 List<Booking> bookings=new ArrayList<Booking>();
    	 bookings.add(booking);
    	 Mockito.when(bookingRepository.findAll()).thenReturn(bookings);
    	 assertEquals(1, bookingServiceImpl.getAllBookings().get(0).getBookingId());
    	 assertEquals(1125, bookingServiceImpl.getAllBookings().get(0).getConfirmationNumber());
    	 assertEquals("S1", bookingServiceImpl.getAllBookings().get(0).getShowId());

          }
     @Test(expected=NoBookingFoundException.class)
     public void getAllBookingsTestForException() throws BookingServiceApplicationException
     {
    	 Booking booking=new Booking();
    	 booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 booking.setShowId("S1");
    	 List<Booking> bookings=new ArrayList<Booking>();
    	
    	 Mockito.when(bookingRepository.findAll()).thenReturn(bookings);
    	 assertEquals(1, bookingServiceImpl.getAllBookings().get(0).getBookingId());
    	 assertEquals(1125, bookingServiceImpl.getAllBookings().get(0).getConfirmationNumber());
    	 assertEquals("S1", bookingServiceImpl.getAllBookings().get(0).getShowId());

          }
     @Test
     public void getBookingByIdTest() throws BookingServiceApplicationException
     {
    	 Booking booking=new Booking();
    	 booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 booking.setShowId("S1");
    	 Mockito.when(bookingRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(booking));
    	 assertEquals(1,bookingServiceImpl.getBookingById(1).getBookingId());
    	 assertEquals(1125,bookingServiceImpl.getBookingById(1).getConfirmationNumber());
    	 assertEquals("S1",bookingServiceImpl.getBookingById(1).getShowId());

     }
     @Test(expected=NoSuchBookingFoundException.class)
     public void getBookingByIdTestForException() throws BookingServiceApplicationException
     {
    	 Booking booking=new Booking();
    	 booking.setBookingId(1);
    	 booking.setConfirmationNumber(1125);
    	 booking.setShowId("S1");
    	 bookingServiceImpl.getBookingById(1);

     }
}
