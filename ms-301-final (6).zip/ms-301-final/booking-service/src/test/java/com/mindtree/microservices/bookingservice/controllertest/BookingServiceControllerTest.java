package com.mindtree.microservices.bookingservice.controllertest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.bookingservice.controller.BookingServiceController;
import com.mindtree.microservices.bookingservice.dto.BookingDto;
import com.mindtree.microservices.bookingservice.dto.ShowsDto;
import com.mindtree.microservices.bookingservice.entity.Booking;
import com.mindtree.microservices.bookingservice.exception.BookingServiceApplicationException;
import com.mindtree.microservices.bookingservice.proxy.ShowsService;
import com.mindtree.microservices.bookingservice.service.BookingService;

@SpringBootTest
public class BookingServiceControllerTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	private BookingServiceController bookingServiceController;
	@Mock
	private BookingService bookingService;
	

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(bookingServiceController).build();
	}
    @Test
	public void bookShowTest() {
		Booking booking=new Booking();
		booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		booking.setShowId("S1");
		try {
			Mockito.when(bookingService.bookShow(Mockito.anyString())).thenReturn(booking);
		} catch (BookingServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(1, bookingServiceController.bookShow("S1").getBookingId());
			assertEquals(1123, bookingServiceController.bookShow("S1").getConfirmationNumber());
			assertEquals("S1", bookingServiceController.bookShow("S1").getShowId());

		} catch (BookingServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
    @Test
    public void getBookingById()
    {
    	BookingDto booking=new BookingDto();
    	booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		booking.setShowId("S1");   
		try {
			Mockito.when(bookingService.getBookingById(Mockito.anyInt())).thenReturn(booking);
		} catch (BookingServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(1, bookingServiceController.getBookingById(1).getBookingId());
			assertEquals(1123, bookingServiceController.getBookingById(1).getConfirmationNumber());
			assertEquals("S1", bookingServiceController.getBookingById(1).getShowId());

		} catch (BookingServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
    @Test
    public void getAllBookings()
    {   List<BookingDto> bookings=new ArrayList<BookingDto>();
    	BookingDto booking=new BookingDto();
    	booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		booking.setShowId("S1"); 
		bookings.add(booking);
		try {
			Mockito.when(bookingService.getAllBookings()).thenReturn(bookings);
		} catch (BookingServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			assertEquals(1, bookingServiceController.getAllBookings().get(0).getBookingId());
			assertEquals(1123, bookingServiceController.getAllBookings().get(0).getConfirmationNumber());
			assertEquals("S1", bookingServiceController.getAllBookings().get(0).getShowId());

		} catch (BookingServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
	
}
