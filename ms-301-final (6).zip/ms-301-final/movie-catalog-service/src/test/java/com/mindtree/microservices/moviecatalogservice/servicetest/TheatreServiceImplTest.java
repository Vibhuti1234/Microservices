package com.mindtree.microservices.moviecatalogservice.servicetest;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.moviecatalogservice.dto.AddressDto;
import com.mindtree.microservices.moviecatalogservice.dto.RestrictionsDto;
import com.mindtree.microservices.moviecatalogservice.dto.TheatreDto;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.AddressRepository;
import com.mindtree.microservices.moviecatalogservice.repository.MovieRepository;
import com.mindtree.microservices.moviecatalogservice.repository.RestrictionsRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ReviewRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ScreenRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ShowsRepository;
import com.mindtree.microservices.moviecatalogservice.repository.TheatreRepository;
import com.mindtree.microservices.moviecatalogservice.service.impl.MovieServiceImpl;
import com.mindtree.microservices.moviecatalogservice.service.impl.ScreenServiceImpl;
import com.mindtree.microservices.moviecatalogservice.service.impl.ShowServiceImpl;
import com.mindtree.microservices.moviecatalogservice.service.impl.TheatreServiceImpl;

@SpringBootTest
public class TheatreServiceImplTest{
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	MovieServiceImpl movieServiceImpl;
	@InjectMocks
	ScreenServiceImpl screenServiceImpl;
	@InjectMocks
	ShowServiceImpl  showServiceImpl;
	@InjectMocks
	TheatreServiceImpl theatreServiceImpl;
	
	@Mock
	AddressRepository addressRepository;
	
	@Mock
	MovieRepository movieRepository;
	@Mock
	RestrictionsRepository restrictionsRepository;
	@Mock
	ReviewRepository reviewRepository;
	@Mock 
	ScreenRepository screenRepository;
	@Mock
	ShowsRepository showsRepository;
	@Mock
	TheatreRepository theatreRepository;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(theatreServiceImpl).build();
	}
	@Test
	public void addTheatreTest()
	{
		TheatreDto theatreDto=new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		theatreDto.setParkingFacilityAvailable("car parking");
		theatreDto.setNoOfScreens(3);
	 TheatreDto theatreDtoRes= theatreServiceImpl.addTheatre(theatreDto);
	 assertEquals("T1", theatreDtoRes.getTheatreId());
	}
	@Test
	public void assignAdressDetailsToTheatreTest() throws MovieCatalogServiceApplicationException
	{
		AddressDto addressDto=new AddressDto();
		addressDto.setAddressId("A1");
		addressDto.setLine1("l1");
		addressDto.setLine1("l2");
		addressDto.setLine1("l3");
		addressDto.setCity("Kolkata");
		addressDto.setState("WB");
		addressDto.setPin("234441");
		addressDto.setLongitude(4);
		addressDto.setLatitude(4);
        Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
		String theatreId="T1";
		List<Theatre> theatres=new ArrayList<Theatre>();
		theatres.add(theatre);

	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		
      AddressDto addressDtoRes = theatreServiceImpl.assignAdressDetailsToTheatre(addressDto, theatreId);
      assertEquals("A1", addressDtoRes.getAddressId());
	}
	@Test(expected=NoSuchTheatreFoundException.class)
	public void assignAdressDetailsToTheatreTestForException() throws MovieCatalogServiceApplicationException
	{
		AddressDto addressDto=new AddressDto();
		addressDto.setAddressId("A1");
		addressDto.setLine1("l1");
		addressDto.setLine1("l2");
		addressDto.setLine1("l3");
		addressDto.setCity("Kolkata");
		addressDto.setState("WB");
		addressDto.setPin("234441");
		addressDto.setLongitude(4);
		addressDto.setLatitude(4);
        Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
		String theatreId="T2";
		List<Theatre> theatres=new ArrayList<Theatre>();
		theatres.add(theatre);
	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
       theatreServiceImpl.assignAdressDetailsToTheatre(addressDto, theatreId);
	}
	@Test
	public void provideRestrictionToTheatreTest() throws MovieCatalogServiceApplicationException
	{
		RestrictionsDto restrictionsDto=new RestrictionsDto();
		restrictionsDto.setRestrictionId(1);
		restrictionsDto.setFoodAllowed("chips");
		restrictionsDto.setNoOfBagsAllowed(2);
		Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
        List<Theatre> theatres=new ArrayList<Theatre>();
		theatres.add(theatre);
		String theatreId="T1";
    	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		RestrictionsDto restrictionsDtoRes=theatreServiceImpl.provideRestrictionToTheatre(restrictionsDto, theatreId);
		assertEquals(1,restrictionsDtoRes.getRestrictionId());
	}
	@Test(expected=NoSuchTheatreFoundException.class)
	public void provideRestrictionToTheatreTestForException() throws MovieCatalogServiceApplicationException
	{
		RestrictionsDto restrictionsDto=new RestrictionsDto();
		restrictionsDto.setRestrictionId(1);
		restrictionsDto.setFoodAllowed("chips");
		restrictionsDto.setNoOfBagsAllowed(2);
		Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
        List<Theatre> theatres=new ArrayList<Theatre>();
		theatres.add(theatre);
		String theatreId="T2";
    	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		theatreServiceImpl.provideRestrictionToTheatre(restrictionsDto, theatreId);
	
	}
	@Test
	public void fetchAllTheatersTest() throws MovieCatalogServiceApplicationException
	{
		Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
        Theatre theatre2=new  Theatre();
        theatre2.setTheatreId("T2");
        theatre2.setTheatreName("Theatre2");
        List<Theatre> theatres=new ArrayList<Theatre>();
		theatres.add(theatre);
		theatres.add(theatre2);
    	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
    	List<TheatreDto> theatreDtos=theatreServiceImpl.fetchAllTheaters();
    	assertNotNull(theatreDtos);

		
	}
	@Test(expected=NoSuchTheatreFoundException.class)
	public void fetchAllTheatersTestIfNoTheatersAreAvailable() throws MovieCatalogServiceApplicationException
	{
		Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
        Theatre theatre2=new  Theatre();
        theatre2.setTheatreId("T2");
        theatre2.setTheatreName("Theatre2");
        List<Theatre> theatres=new ArrayList<Theatre>();
    	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
    	theatreServiceImpl.fetchAllTheaters();
    	
        

		
	}
	@Test
	public void fetchTheaterByIdTest() throws MovieCatalogServiceApplicationException
	{
		Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
        Theatre theatre2=new  Theatre();
        theatre2.setTheatreId("T2");
        theatre2.setTheatreName("Theatre2");
        List<Theatre> theatres=new ArrayList<Theatre>();
        theatres.add(theatre);
        theatres.add(theatre2);
        String theatreId="T1";
    	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
    	assertEquals("Theatre1",theatreServiceImpl.fetchTheaterById(theatreId).getTheatreName());

        
	}
	@Test(expected=NoSuchTheatreFoundException.class)
	public void fetchTheaterByIdTestForException() throws MovieCatalogServiceApplicationException 
	{
		Theatre theatre=new Theatre();
        theatre.setTheatreId("T1");
        theatre.setTheatreName("Theatre1");
        Theatre theatre2=new  Theatre();
        theatre2.setTheatreId("T2");
        theatre2.setTheatreName("Theatre2");
        List<Theatre> theatres=new ArrayList<Theatre>();
        theatres.add(theatre);
        theatres.add(theatre2);
        String theatreId="T3";
    	Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
    	theatreServiceImpl.fetchTheaterById(theatreId);
        
        
	}


}

