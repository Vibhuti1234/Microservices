package com.mindtree.microservices.moviecatalogservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.ShowsDto;
import com.mindtree.microservices.moviecatalogservice.entity.Screen;
import com.mindtree.microservices.moviecatalogservice.entity.Shows;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoShowsFoundException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchScreenFoundException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchShowFoundException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.AddressRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ScreenRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ShowsRepository;
import com.mindtree.microservices.moviecatalogservice.repository.TheatreRepository;
import com.mindtree.microservices.moviecatalogservice.service.impl.ShowServiceImpl;

@SpringBootTest
public class ShowServiceImplTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	ShowServiceImpl showServiceImpl;

	@Mock
	ShowsRepository showsRepository;
	@Mock
	ScreenRepository screenRepository;
	@Mock
	private TheatreRepository theatreRepository;
	@Mock
	private AddressRepository addressRepository;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(showServiceImpl).build();
	}

	@Test
	public void addShowsTest() {
		ShowsDto showsDto = new ShowsDto();
		showsDto.setShowId("S1");
		showsDto.setDuration("2 hrs");
		showsDto.setNumberOfRows(5);
		assertEquals("S1", showServiceImpl.addShows(showsDto).getShowId());
	}

	@Test
	public void assignShowsToTheatreTest() throws MovieCatalogServiceApplicationException {
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		String theatreId = "T1";
		List<Screen> screens = new ArrayList<>();
		Screen screen = new Screen();
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		String screenId = "Sc1";
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh1";
		show.setDuration("3 hrs");
		shows.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shows);
		assertEquals("Sh1", showServiceImpl.assignShowsToTheatre(showId, screenId, theatreId).getShowId());

	}

	@Test(expected = NoSuchTheatreFoundException.class)
	public void assignShowsToTheatreTestForException() throws MovieCatalogServiceApplicationException {
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		String theatreId = "T2";
		List<Screen> screens = new ArrayList<>();
		Screen screen = new Screen();
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		String screenId = "Sc1";
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh1";
		show.setDuration("3 hrs");
		shows.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shows);
		showServiceImpl.assignShowsToTheatre(showId, screenId, theatreId);

	}

	@Test(expected = NoSuchScreenFoundException.class)
	public void assignShowsToTheatreTestForException2() throws MovieCatalogServiceApplicationException {
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		String theatreId = "T1";
		List<Screen> screens = new ArrayList<>();
		Screen screen = new Screen();
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		String screenId = "Sc2";
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh1";
		show.setDuration("3 hrs");
		shows.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shows);
		showServiceImpl.assignShowsToTheatre(showId, screenId, theatreId);

	}

	@Test(expected = NoSuchShowFoundException.class)
	public void assignShowsToTheatreTestForException3() throws MovieCatalogServiceApplicationException {
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		String theatreId = "T1";
		List<Screen> screens = new ArrayList<>();
		Screen screen = new Screen();
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		String screenId = "Sc1";
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh2";
		show.setDuration("3 hrs");
		shows.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shows);
		showServiceImpl.assignShowsToTheatre(showId, screenId, theatreId);

	}

	@Test
	public void assignMoviesToTheatreTest() throws MovieCatalogServiceApplicationException {
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("KFG");
		movieDto.setRating(4);
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		List<Screen> screens = new ArrayList<>();
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh1";
		show.setDuration("3 hrs");
		shows.add(show);
		Screen screen = new Screen();
		screen.setShows(shows);
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		String theatreId = "T1";
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		assertEquals("M1", showServiceImpl.assignMoviesToTheatre(movieDto, showId, theatreId).getMovieId());

	}

	@Test(expected = NoSuchTheatreFoundException.class)
	public void assignMoviesToTheatreTestForException() throws MovieCatalogServiceApplicationException {
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("KFG");
		movieDto.setRating(4);
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		List<Screen> screens = new ArrayList<>();
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh1";
		show.setDuration("3 hrs");
		shows.add(show);
		Screen screen = new Screen();
		screen.setShows(shows);
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		String theatreId = "T2";
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		showServiceImpl.assignMoviesToTheatre(movieDto, showId, theatreId);

	}

	@Test(expected = NoShowsFoundException.class)
	public void assignMoviesToTheatreTestForException2() throws MovieCatalogServiceApplicationException {
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("KFG");
		movieDto.setRating(4);
		Theatre theatre = new Theatre();
		theatre.setTheatreId("T1");
		theatre.setTheatreName("Theatre1");
		List<Screen> screens = new ArrayList<>();
		List<Shows> shows = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		String showId = "Sh2";
		show.setDuration("3 hrs");
		shows.add(show);
		Screen screen = new Screen();
		screen.setShows(shows);
		screen.setScreenId("Sc1");
		screen.setScreenName("Screen1");
		screens.add(screen);
		theatre.setScreens(screens);
		String theatreId = "T1";
		List<Theatre> theatres = new ArrayList<Theatre>();
		theatres.add(theatre);
		Mockito.when(theatreRepository.findAll()).thenReturn(theatres);
		showServiceImpl.assignMoviesToTheatre(movieDto, showId, theatreId);

	}

	@Test
	public void getAllShowsTest() throws MovieCatalogServiceApplicationException {
		List<Shows> shList = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		show.setDuration("3 hrs");
		shList.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shList);
		assertEquals("Sh1", showServiceImpl.getAllShows().get(0).getShowId());

	}

	@Test(expected = NoShowsFoundException.class)
	public void getAllShowsTestForException() throws MovieCatalogServiceApplicationException {
		List<Shows> shList = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		show.setDuration("3 hrs");
		Mockito.when(showsRepository.findAll()).thenReturn(shList);
		showServiceImpl.getAllShows();

	}

	@Test
	public void getShowByIdTest() throws MovieCatalogServiceApplicationException {
		String showId = "Sh1";
		List<Shows> shList = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		show.setDuration("3 hrs");
		shList.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shList);
		assertEquals("Sh1", showServiceImpl.getShowById(showId).getShowId());
	}

	@Test(expected = NoSuchShowFoundException.class)
	public void getShowByIdTestForException() throws MovieCatalogServiceApplicationException {
		String showId = "Sh2";
		List<Shows> shList = new ArrayList<>();
		Shows show = new Shows();
		show.setShowId("Sh1");
		show.setDuration("3 hrs");
		shList.add(show);
		Mockito.when(showsRepository.findAll()).thenReturn(shList);
		showServiceImpl.getShowById(showId);
	}

	


	

	

	
	

}
