package com.mindtree.microservices.moviecatalogservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.moviecatalogservice.dto.ReviewDto;
import com.mindtree.microservices.moviecatalogservice.entity.Movie;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchMovieFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.MovieRepository;
import com.mindtree.microservices.moviecatalogservice.service.impl.MovieServiceImpl;

@SpringBootTest
public class MovieServiceImplTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	MovieServiceImpl movieServiceImpl;
	@Mock
	MovieRepository movieRepository;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(movieServiceImpl).build();
	}
@Test
public void addReviewsToMoviesTest() throws MovieCatalogServiceApplicationException
{
	ReviewDto reviewDto=new ReviewDto();
	reviewDto.setReviewDetails("Very Good Movie");
	reviewDto.setReviewerId("R1");
    String movieId="M1";
    Movie movie=new Movie();
    movie.setMovieId("M1");
    movie.setMovieName("Movie1");
    List<Movie> movies=new ArrayList<Movie>();
    movies.add(movie);
    Mockito.when(movieRepository.findAll()).thenReturn(movies);
    assertEquals("R1", movieServiceImpl.addReviewsToMovies(reviewDto, movieId).getReviewerId());
    assertNotEquals("R2", movieServiceImpl.addReviewsToMovies(reviewDto, movieId).getReviewerId());

}
@Test(expected=NoSuchMovieFoundException.class)
public void addReviewsToMoviesTestForException() throws MovieCatalogServiceApplicationException
{
	ReviewDto reviewDto=new ReviewDto();
	reviewDto.setReviewDetails("Very Good Movie");
	reviewDto.setReviewerId("R1");
    String movieId="M2";
    Movie movie=new Movie();
    movie.setMovieId("M1");
    movie.setMovieName("Movie1");
    List<Movie> movies=new ArrayList<Movie>();
    movies.add(movie);
    Mockito.when(movieRepository.findAll()).thenReturn(movies);
     movieServiceImpl.addReviewsToMovies(reviewDto, movieId);
}
@Test
public void fetchAllMoviesTest() throws MovieCatalogServiceApplicationException
{
	 Movie movie=new Movie();
	    movie.setMovieId("M1");
	    movie.setMovieName("Movie1");
	    List<Movie> movies=new ArrayList<Movie>();
	    movies.add(movie);
	    Mockito.when(movieRepository.findAll()).thenReturn(movies);
	    assertEquals("M1", movieServiceImpl.fetchAllMovies().get(0).getMovieId());

}
@Test(expected=NoSuchMovieFoundException.class)
public void fetchAllMoviesTestForException() throws MovieCatalogServiceApplicationException
{
	 Movie movie=new Movie();
	    movie.setMovieId("M1");
	    movie.setMovieName("Movie1");
	    List<Movie> movies=new ArrayList<Movie>();
	    Mockito.when(movieRepository.findAll()).thenReturn(movies);
	    movieServiceImpl.fetchAllMovies();

}
@Test
public void fetchMovieByIdTest() throws MovieCatalogServiceApplicationException
{String movieId="M1";
Movie movie =new Movie();
movie.setMovieId("M1");
movie.setMovieName("Movie1");

Mockito.when(movieRepository.findById(Mockito.any())).thenReturn(Optional.of(movie));
assertEquals("M1",movieServiceImpl.fetchMovieById(movieId).getMovieId());

	
}
@Test(expected=NoSuchMovieFoundException.class)
public void fetchMovieByIdTestForException() throws MovieCatalogServiceApplicationException
{String movieId="M2";
Movie movie=new Movie();
movie.setMovieId("M1");
movie.setMovieName("Movie1");
movieServiceImpl.fetchMovieById(movieId);	
}
}
