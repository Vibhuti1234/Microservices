package com.mindtree.microservices.moviecatalogservice.service;

import java.util.List;

import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.ReviewDto;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;

public interface MovieService {

	ReviewDto addReviewsToMovies(ReviewDto reviewDto, String movieId) throws MovieCatalogServiceApplicationException;

	List<MovieDto> fetchAllMovies() throws MovieCatalogServiceApplicationException;

	MovieDto fetchMovieById(String movieId) throws MovieCatalogServiceApplicationException;

}
