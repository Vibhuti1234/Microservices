package com.mindtree.microservices.moviecatalogservice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.microservices.moviecatalogservice.entity.Shows;

public class ScreenDto {
	private String screenId;

	private String screenName;
	private String screentype;
	private int capacity;
	private int totalNoOfSeats;
	private int totalDamagedSeats;
	private int numberOfRows;
	@JsonIgnore
	private List<Shows> shows;

	public ScreenDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ScreenDto(String screenId, String screenName, String screentype, int capacity, int totalNoOfSeats,
			int totalDamagedSeats, int numberOfRows, List<Shows> shows) {
		super();
		this.screenId = screenId;
		this.screenName = screenName;
		this.screentype = screentype;
		this.capacity = capacity;
		this.totalNoOfSeats = totalNoOfSeats;
		this.totalDamagedSeats = totalDamagedSeats;
		this.numberOfRows = numberOfRows;
		this.shows = shows;
	}

	/**
	 * @return the screenId
	 */
	public String getScreenId() {
		return screenId;
	}

	/**
	 * @param screenId the screenId to set
	 */
	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	/**
	 * @return the screenName
	 */
	public String getScreenName() {
		return screenName;
	}

	/**
	 * @param screenName the screenName to set
	 */
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	/**
	 * @return the screentype
	 */
	public String getScreentype() {
		return screentype;
	}

	/**
	 * @param screentype the screentype to set
	 */
	public void setScreentype(String screentype) {
		this.screentype = screentype;
	}

	/**
	 * @return the capacity
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * @param capacity the capacity to set
	 */
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	/**
	 * @return the totalNoOfSeats
	 */
	public int getTotalNoOfSeats() {
		return totalNoOfSeats;
	}

	/**
	 * @param totalNoOfSeats the totalNoOfSeats to set
	 */
	public void setTotalNoOfSeats(int totalNoOfSeats) {
		this.totalNoOfSeats = totalNoOfSeats;
	}

	/**
	 * @return the totalDamagedSeats
	 */
	public int getTotalDamagedSeats() {
		return totalDamagedSeats;
	}

	/**
	 * @param totalDamagedSeats the totalDamagedSeats to set
	 */
	public void setTotalDamagedSeats(int totalDamagedSeats) {
		this.totalDamagedSeats = totalDamagedSeats;
	}

	/**
	 * @return the numberOfRows
	 */
	public int getNumberOfRows() {
		return numberOfRows;
	}

	/**
	 * @param numberOfRows the numberOfRows to set
	 */
	public void setNumberOfRows(int numberOfRows) {
		this.numberOfRows = numberOfRows;
	}

	/**
	 * @return the shows
	 */
	public List<Shows> getShows() {
		return shows;
	}

	/**
	 * @param shows the shows to set
	 */
	public void setShows(List<Shows> shows) {
		this.shows = shows;
	}

}
