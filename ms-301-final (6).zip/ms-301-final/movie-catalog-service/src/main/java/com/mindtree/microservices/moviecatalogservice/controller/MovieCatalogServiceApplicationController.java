package com.mindtree.microservices.moviecatalogservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.microservices.moviecatalogservice.dto.AddressDto;
import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.ResponseDto;
import com.mindtree.microservices.moviecatalogservice.dto.RestrictionsDto;
import com.mindtree.microservices.moviecatalogservice.dto.ReviewDto;
import com.mindtree.microservices.moviecatalogservice.dto.ScreenDto;
import com.mindtree.microservices.moviecatalogservice.dto.ShowsDto;
import com.mindtree.microservices.moviecatalogservice.dto.TheatreDto;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.service.MovieService;
import com.mindtree.microservices.moviecatalogservice.service.ScreenService;
import com.mindtree.microservices.moviecatalogservice.service.ShowService;
import com.mindtree.microservices.moviecatalogservice.service.TheatreService;

@RestController
@RequestMapping("/")
public class MovieCatalogServiceApplicationController {
	@Autowired
	private TheatreService theatreService;
	@Autowired
	private MovieService movieService;
	@Autowired
	private ShowService showService;
	@Autowired
	private ScreenService screenService;

	@PostMapping(value = "/addTheatre")
	public ResponseEntity<ResponseDto<TheatreDto>> addTheatre(@RequestBody TheatreDto theatreDto) {
		ResponseDto<TheatreDto> response = new ResponseDto<TheatreDto>(theatreService.addTheatre(theatreDto), null,
				"Theatre Added Successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "/assignAdressDetailsToTheatre/{theatreId}")
	public ResponseEntity<ResponseDto<AddressDto>> assignAdressDetailsToTheatre(@RequestBody AddressDto addressDto,
			@PathVariable String theatreId) throws MovieCatalogServiceApplicationException {
		ResponseDto<AddressDto> response = new ResponseDto<AddressDto>(
				theatreService.assignAdressDetailsToTheatre(addressDto, theatreId), null,
				"address details added successfully", true);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "provideRestrictionToTheatre/{theatreId}")
	public ResponseEntity<ResponseDto<RestrictionsDto>> provideRestrictionToTheatre(
			@RequestBody RestrictionsDto restrictionsDto, @PathVariable String theatreId)
			throws MovieCatalogServiceApplicationException {
		ResponseDto<RestrictionsDto> response = new ResponseDto<RestrictionsDto>(
				theatreService.provideRestrictionToTheatre(restrictionsDto, theatreId), null,
				"restrictions details added successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "allocateScreensToTheatre/{theatreId}")
	public ResponseEntity<ResponseDto<ScreenDto>> allocateScreensToTheatre(@RequestBody ScreenDto screenDto,
			@PathVariable String theatreId) throws MovieCatalogServiceApplicationException {
		ResponseDto<ScreenDto> response = new ResponseDto<ScreenDto>(
				screenService.allocateScreensToTheatre(screenDto, theatreId), null, "screen allocated successfully",
				true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "addShows")
	public ResponseEntity<ResponseDto<ShowsDto>> addShows(@RequestBody ShowsDto showsDto) {
		ResponseDto<ShowsDto> response = new ResponseDto<ShowsDto>(showService.addShows(showsDto), null,
				"show added successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "assignShowsToTheatre/{showId}/{screenId}/{theatreId}")
	public ResponseEntity<ResponseDto<ShowsDto>> assignShowsToTheatre(@PathVariable String showId,
			@PathVariable String screenId, @PathVariable String theatreId)
			throws MovieCatalogServiceApplicationException {
		ResponseDto<ShowsDto> response = new ResponseDto<ShowsDto>(
				showService.assignShowsToTheatre(showId, screenId, theatreId), null, "show assigned successfully",
				true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "assignMoviesToTheatre/{showId}/{theatreId}")
	public ResponseEntity<ResponseDto<MovieDto>> assignMoviesToTheatre(@RequestBody MovieDto movieDto,
			@PathVariable String showId, @PathVariable String theatreId)
			throws MovieCatalogServiceApplicationException {
		ResponseDto<MovieDto> response = new ResponseDto<MovieDto>(
				showService.assignMoviesToTheatre(movieDto, showId, theatreId), null, "show assigned successfully",
				true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@PostMapping(value = "addReviewsToMovies/{movieId}")
	public ResponseEntity<ResponseDto<ReviewDto>> addReviewsToMovies(@RequestBody ReviewDto reviewDto,
			@PathVariable String movieId) throws MovieCatalogServiceApplicationException {
		ResponseDto<ReviewDto> response = new ResponseDto<ReviewDto>(
				movieService.addReviewsToMovies(reviewDto, movieId), null, "review added successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "getAllShows")
	public ResponseEntity<ResponseDto<List<ShowsDto>>> getAllShows() throws MovieCatalogServiceApplicationException {
		ResponseDto<List<ShowsDto>> response = new ResponseDto<List<ShowsDto>>(showService.getAllShows(), null,
				"all shows fetched successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "getShowById/{showId}")
	public ResponseEntity<ResponseDto<ShowsDto>> getShowById(@PathVariable("showId") String showId)
			throws MovieCatalogServiceApplicationException {
		ResponseDto<ShowsDto> response = new ResponseDto<ShowsDto>(showService.getShowById(showId), null,
				"show details fetched successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetchAllMovies")
	public ResponseEntity<ResponseDto<List<MovieDto>>> fetchAllMovies() throws MovieCatalogServiceApplicationException {

		ResponseDto<List<MovieDto>> response = new ResponseDto<List<MovieDto>>(movieService.fetchAllMovies(), null,
				"all movies fetched successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetchAllTheaters")
	public ResponseEntity<ResponseDto<List<TheatreDto>>> fetchAllTheaters()
			throws MovieCatalogServiceApplicationException {

		ResponseDto<List<TheatreDto>> response = new ResponseDto<List<TheatreDto>>(theatreService.fetchAllTheaters(),
				null, "all theatres fetched successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetchMovieById/{movieId}")
	public ResponseEntity<ResponseDto<MovieDto>> fetchMovieById(@PathVariable String movieId)
			throws MovieCatalogServiceApplicationException {

		ResponseDto<MovieDto> response = new ResponseDto<MovieDto>(movieService.fetchMovieById(movieId), null,
				"movie details fetched  successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetchTheaterById/{theatreId}")
	public ResponseEntity<ResponseDto<TheatreDto>> fetchTheaterById(@PathVariable String theatreId)
			throws MovieCatalogServiceApplicationException {

		ResponseDto<TheatreDto> response = new ResponseDto<TheatreDto>(theatreService.fetchTheaterById(theatreId), null,
				" theatre details fetched successfully", true);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

}
