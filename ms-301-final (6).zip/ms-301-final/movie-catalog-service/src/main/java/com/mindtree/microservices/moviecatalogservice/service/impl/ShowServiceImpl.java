package com.mindtree.microservices.moviecatalogservice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.ShowsDto;
import com.mindtree.microservices.moviecatalogservice.entity.Movie;
import com.mindtree.microservices.moviecatalogservice.entity.Screen;
import com.mindtree.microservices.moviecatalogservice.entity.Shows;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoShowsFoundException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchScreenFoundException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchShowFoundException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.ScreenRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ShowsRepository;
import com.mindtree.microservices.moviecatalogservice.repository.TheatreRepository;
import com.mindtree.microservices.moviecatalogservice.service.ShowService;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ShowServiceImpl implements ShowService {
	private static Shows shows = new Shows();

	@Autowired
	private ShowsRepository showsRepository;
	@Autowired
	private TheatreRepository theatreRepository;
	@Autowired
	private ScreenRepository screenRepository;
	Logger logger = Logger.getLogger(ShowServiceImpl.class.getName());

	ModelMapper modelMapper = new ModelMapper();

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ShowsDto addShows(ShowsDto showsDto) {
		// TODO Auto-generated method stub
		Shows shows = convertDtoToEntity(showsDto);
		shows.setTotalBookedSeats(0);
		shows.setTotalFreeSeats(shows.getTotalNoOfSeats() - shows.getTotalDamagedSeats());
		showsRepository.save(shows);
		return showsDto;
	}

	private Shows convertDtoToEntity(ShowsDto showsDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(showsDto, Shows.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ShowsDto assignShowsToTheatre(String showId, String screenId, String theatreId)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no theatre of such Id then it will throw no theatre found exception");
		Theatre theatre = theatreRepository.findAll().stream().filter(i -> i.getTheatreId().equals(theatreId)).findAny()
				.orElseThrow(() -> new NoSuchTheatreFoundException("No Theatre Found of this Id:"));
		logger.warning("if there is no screen  of such Id then it will throw no screen found exception");

		Screen screen = theatre.getScreens().stream().filter(i -> i.getScreenId().equals(screenId)).findAny()
				.orElseThrow(() -> new NoSuchScreenFoundException("No such screen found exception"));
		logger.warning("if there is no show  of such Id then it will throw no show  found exception");
		Shows shows = showsRepository.findAll().stream().filter(i -> i.getShowId().equals(showId)).findAny()
				.orElseThrow(() -> new NoSuchShowFoundException("No such show found :"));
		screen.getShows().add(shows);
		screenRepository.save(screen);

		return convertEntityToDto(shows);
	}

	private ShowsDto convertEntityToDto(Shows shows) {
		// TODO Auto-generated method stub
		return modelMapper.map(shows, ShowsDto.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public MovieDto assignMoviesToTheatre(MovieDto movieDto, String showId, String theatreId)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no theatre of such Id then it will throw no theatre found exception");
		Theatre theatre = theatreRepository.findAll().stream().filter(i -> i.getTheatreId().equals(theatreId)).findAny()
				.orElseThrow(() -> new NoSuchTheatreFoundException("No Theatre Found of this Id:"));

		theatre.getScreens().stream().forEach(i -> {
			i.getShows().stream().forEach(j -> {
				if (j.getShowId().equals(showId)) {
					shows = j;
				}
			});
		});

		if (shows.getShowId() == null) {
			throw new NoShowsFoundException("No shows are available");
		}

		Movie movieDetails = convertDtoToEntity(movieDto);
		shows.setMovieDetails(movieDetails);
		showsRepository.save(shows);

		return movieDto;
	}

	private Movie convertDtoToEntity(MovieDto movieDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(movieDto, Movie.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<ShowsDto> getAllShows() throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<Shows> showsList = new ArrayList<>();
		showsList = showsRepository.findAll();
		logger.warning("if there is no shows details available   then it will throw no shows found exception");
		if (showsList.size() == 0 || showsList.isEmpty()) {
			throw new NoShowsFoundException("No shows are available");
		}

		List<ShowsDto> showsDtos = showsList.stream().map(entity -> convertEntityToDto(entity))
				.collect(Collectors.toList());
		return showsDtos;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public ShowsDto getShowById(String showId) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no show  of such Id then it will throw no show found exception");
		Shows shows = showsRepository.findAll().stream().filter(i -> i.getShowId().equals(showId)).findAny()
				.orElseThrow(() -> new NoSuchShowFoundException("No such show available for this id:"));
		if (shows.getTotalFreeSeats() > 0) {
			shows.setTotalBookedSeats(shows.getTotalBookedSeats() + 1);
			System.out.println(shows.getTotalBookedSeats());
			shows.setTotalFreeSeats(shows.getTotalFreeSeats() - 1);
			System.out.println(shows.getTotalFreeSeats());
		}
		updateShows(shows);

		return convertEntityToDto(shows);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public void updateShows(Shows shows) {
		// TODO Auto-generated method stub
		showsRepository.save(shows);
	}

}
