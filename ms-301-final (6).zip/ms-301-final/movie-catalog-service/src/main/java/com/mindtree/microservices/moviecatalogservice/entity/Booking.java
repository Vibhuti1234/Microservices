package com.mindtree.microservices.moviecatalogservice.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int bookingId;
	//@Column(unique=true)
	private int confirmationNumber;
	/*@OneToOne(targetEntity = Shows.class,cascade=CascadeType.ALL)
	//@JoinColumn(name="bookingId")
	private Shows shows;*/
	
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Booking(int bookingId, int confirmationNumber) {
		super();
		this.bookingId = bookingId;
		this.confirmationNumber = confirmationNumber;
	
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getConfirmationNumber() {
		return confirmationNumber;
	}
	public void setConfirmationNumber(int confirmationNumber) {
		this.confirmationNumber = confirmationNumber;
	}
	
	
	
	
	

}
