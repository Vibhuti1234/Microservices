package com.mindtree.microservices.moviecatalogservice.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Theatre {
	@Id
   private String theatreId;
	
   private String theatreName;
   @OneToOne(mappedBy="theatre",cascade=CascadeType.ALL)
   private Address address;
   
   private String parkingFacilityAvailable;
   private int noOfScreens;
   @OneToOne(mappedBy="theatre",cascade=CascadeType.ALL)
   private Restrictions restrictions;
   @OneToMany(cascade=CascadeType.ALL)
  	@JoinColumn(name="theatreId")
     private List<Screen> screens=new ArrayList<Screen>();

public Theatre() {
	super();
	// TODO Auto-generated constructor stub
}





public Theatre(String theatreId, String theatreName, Address address, String parkingFacilityAvailable, int noOfScreens,
		Restrictions restrictions, List<com.mindtree.microservices.moviecatalogservice.entity.Screen> screens) {
	super();
	this.theatreId = theatreId;
	this.theatreName = theatreName;
	this.address = address;
	this.parkingFacilityAvailable = parkingFacilityAvailable;
	this.noOfScreens = noOfScreens;
	this.restrictions = restrictions;
	this.screens = screens;
}





public Restrictions getRestrictions() {
	return restrictions;
}


public void setRestrictions(Restrictions restrictions) {
	this.restrictions = restrictions;
}


public String getTheatreId() {
	return theatreId;
}
public void setTheatreId(String theatreId) {
	this.theatreId = theatreId;
}
public String getTheatreName() {
	return theatreName;
}
public void setTheatreName(String theatreName) {
	this.theatreName = theatreName;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}

public String getParkingFacilityAvailable() {
	return parkingFacilityAvailable;
}
public void setParkingFacilityAvailable(String parkingFacilityAvailable) {
	this.parkingFacilityAvailable = parkingFacilityAvailable;
}
public int getNoOfScreens() {
	return noOfScreens;
}
public void setNoOfScreens(int noOfScreens) {
	this.noOfScreens = noOfScreens;
}





public List<Screen> getScreens() {
	return screens;
}





public void setScreens(List<Screen> screens) {
	this.screens = screens;
}

   

}
