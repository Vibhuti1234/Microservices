package com.mindtree.microservices.moviecatalogservice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mindtree.microservices.moviecatalogservice.entity.Address;
import com.mindtree.microservices.moviecatalogservice.entity.Restrictions;
import com.mindtree.microservices.moviecatalogservice.entity.Screen;

public class TheatreDto {

	private String theatreId;
	private String theatreName;
	@JsonIgnore
	private Address address;
	private String parkingFacilityAvailable;
	private int noOfScreens;
	@JsonIgnore
	private Restrictions restrictions;
	@JsonIgnore
	private List<Screen> screens;

	public TheatreDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TheatreDto(String theatreId, String theatreName, Address address, String parkingFacilityAvailable,
			int noOfScreens, Restrictions restrictions, List<Screen> screens) {
		super();
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.address = address;
		this.parkingFacilityAvailable = parkingFacilityAvailable;
		this.noOfScreens = noOfScreens;
		this.restrictions = restrictions;
		this.screens = screens;
	}

	public String getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getParkingFacilityAvailable() {
		return parkingFacilityAvailable;
	}

	public void setParkingFacilityAvailable(String parkingFacilityAvailable) {
		this.parkingFacilityAvailable = parkingFacilityAvailable;
	}

	public int getNoOfScreens() {
		return noOfScreens;
	}

	public void setNoOfScreens(int noOfScreens) {
		this.noOfScreens = noOfScreens;
	}

	public Restrictions getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(Restrictions restrictions) {
		this.restrictions = restrictions;
	}

	public List<Screen> getScreens() {
		return screens;
	}

	public void setScreens(List<Screen> screens) {
		this.screens = screens;
	}

}
