package com.mindtree.microservices.moviecatalogservice.service;

import com.mindtree.microservices.moviecatalogservice.dto.ScreenDto;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;

public interface ScreenService {

	ScreenDto allocateScreensToTheatre(ScreenDto screenDto, String theatreId)
			throws MovieCatalogServiceApplicationException;

}
