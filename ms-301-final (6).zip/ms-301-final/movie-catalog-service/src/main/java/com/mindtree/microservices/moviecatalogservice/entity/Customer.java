package com.mindtree.microservices.moviecatalogservice.entity;

import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	@Id
	private String email;
	private String firstName;
	private String lastName;
	@Column(unique=true)
	private String phoneNumber;
	private String userName;
	private String userId;
	
	@OneToMany(cascade=CascadeType.PERSIST)
	@JoinColumn(name="customer_id")
	private List<Booking> bookings=new ArrayList<Booking>();
	@ElementCollection
	private List<String> userPreferences;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String email, String firstName, String lastName, String phoneNumber, String userName, String userId,
			List<Booking> bookings, List<String> userPreferences) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.userName = userName;
		this.userId = userId;
		this.bookings = bookings;
		this.userPreferences = userPreferences;
	}
	public List<String> getUserPreferences() {
		return userPreferences;
	}
	public void setUserPreferences(List<String> userPreferences) {
		this.userPreferences = userPreferences;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public List<Booking> getBookings() {
		return bookings;
	}
	public void setBookings(List<Booking> bookings) {
		this.bookings = bookings;
	}
	
	
	
	

}
