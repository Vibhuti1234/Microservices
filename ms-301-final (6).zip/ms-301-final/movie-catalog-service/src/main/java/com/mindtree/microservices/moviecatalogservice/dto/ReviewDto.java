package com.mindtree.microservices.moviecatalogservice.dto;

public class ReviewDto {
	private String reviewerId;
	private String reviewDetails;

	public ReviewDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReviewDto(String reviewerId, String reviewDetails) {
		super();
		this.reviewerId = reviewerId;
		this.reviewDetails = reviewDetails;
	}

	/**
	 * @return the reviewerId
	 */
	public String getReviewerId() {
		return reviewerId;
	}

	/**
	 * @param reviewerId the reviewerId to set
	 */
	public void setReviewerId(String reviewerId) {
		this.reviewerId = reviewerId;
	}

	/**
	 * @return the reviewDetails
	 */
	public String getReviewDetails() {
		return reviewDetails;
	}

	/**
	 * @param reviewDetails the reviewDetails to set
	 */
	public void setReviewDetails(String reviewDetails) {
		this.reviewDetails = reviewDetails;
	}

}
