package com.mindtree.microservices.moviecatalogservice.service.impl;

import java.util.logging.Logger;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.microservices.moviecatalogservice.dto.ScreenDto;
import com.mindtree.microservices.moviecatalogservice.entity.Screen;
import com.mindtree.microservices.moviecatalogservice.entity.Theatre;
import com.mindtree.microservices.moviecatalogservice.exception.CapacityFullException;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.TheatreRepository;
import com.mindtree.microservices.moviecatalogservice.service.ScreenService;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ScreenServiceImpl implements ScreenService {

	@Autowired
	private TheatreRepository theatreRepository;
	private ModelMapper modelMapper = new ModelMapper();
	Logger logger = Logger.getLogger(ScreenServiceImpl.class.getName());

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ScreenDto allocateScreensToTheatre(ScreenDto screenDto, String theatreId)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no theatre of such Id then it will throw no theatre found exception");
		Theatre theatre = theatreRepository.findAll().stream().filter(i -> i.getTheatreId().equals(theatreId)).findAny()
				.orElseThrow(() -> new NoSuchTheatreFoundException("No Theatre Found of this Id:"));
		if (theatre.getNoOfScreens() <= 0) {
			throw new CapacityFullException("theatre capacity full:");
		}
		Screen screen = convertDtoToEntity(screenDto);
		theatre.getScreens().add(screen);
		theatre.setNoOfScreens(theatre.getNoOfScreens() - 1);
		theatreRepository.saveAndFlush(theatre);

		return screenDto;
	}

	private Screen convertDtoToEntity(ScreenDto screenDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(screenDto, Screen.class);
	}

}
