package com.mindtree.microservices.moviecatalogservice.service;

import java.util.List;

import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.ShowsDto;
import com.mindtree.microservices.moviecatalogservice.entity.Shows;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;

public interface ShowService {

	ShowsDto addShows(ShowsDto showsDto);

	ShowsDto assignShowsToTheatre(String showId, String screenId, String theatreId)
			throws MovieCatalogServiceApplicationException;

	MovieDto assignMoviesToTheatre(MovieDto movieDto, String showId, String theatreId)
			throws MovieCatalogServiceApplicationException;

	List<ShowsDto> getAllShows() throws MovieCatalogServiceApplicationException;

	ShowsDto getShowById(String showId) throws MovieCatalogServiceApplicationException;

	void updateShows(Shows shows);

}
