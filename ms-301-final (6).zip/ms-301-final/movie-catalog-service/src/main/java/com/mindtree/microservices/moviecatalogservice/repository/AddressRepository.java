package com.mindtree.microservices.moviecatalogservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.microservices.moviecatalogservice.entity.Address;

@Repository
public interface AddressRepository extends JpaRepository<Address, String> {

}
