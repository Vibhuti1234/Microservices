package com.mindtree.microservices.moviecatalogservice.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.microservices.moviecatalogservice.dto.MovieDto;
import com.mindtree.microservices.moviecatalogservice.dto.ReviewDto;
import com.mindtree.microservices.moviecatalogservice.entity.Movie;
import com.mindtree.microservices.moviecatalogservice.entity.Review;
import com.mindtree.microservices.moviecatalogservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.moviecatalogservice.exception.NoSuchMovieFoundException;
import com.mindtree.microservices.moviecatalogservice.repository.MovieRepository;
import com.mindtree.microservices.moviecatalogservice.repository.ShowsRepository;
import com.mindtree.microservices.moviecatalogservice.service.MovieService;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class MovieServiceImpl implements MovieService {
	@Autowired
	ShowsRepository showsRepository;
	@Autowired
	private MovieRepository movieRepository;
	Logger logger = Logger.getLogger(MovieServiceImpl.class.getName());
	ModelMapper modelMapper = new ModelMapper();

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	public ReviewDto addReviewsToMovies(ReviewDto reviewDto, String movieId)
			throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no movie of such Id then it will throw no movie found exception");
		Movie movie = movieRepository.findAll().stream().filter(i -> i.getMovieId().equals(movieId)).findAny()
				.orElseThrow(() -> new NoSuchMovieFoundException("No movie Found exception:"));
		Review review = convertDtoToEntity(reviewDto);
		movie.getReviews().add(review);
		movieRepository.save(movie);

		return reviewDto;
	}

	private Review convertDtoToEntity(ReviewDto reviewDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(reviewDto, Review.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public List<MovieDto> fetchAllMovies() throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no movie in database then it will throw no movie found exception");

		if (movieRepository.findAll().isEmpty() || movieRepository.findAll() == null) {
			throw new NoSuchMovieFoundException("No movie found");
		}
		List<MovieDto> movieDtos = new ArrayList<MovieDto>();
		movieDtos = movieRepository.findAll().stream().map(entity -> convertEntityToDto(entity))
				.collect(Collectors.toList());
		return movieDtos;
	}

	private MovieDto convertEntityToDto(Movie entity) {
		// TODO Auto-generated method stub
		return modelMapper.map(entity, MovieDto.class);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	public MovieDto fetchMovieById(String movieId) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		logger.warning("if there is no movie of such id in database then it will throw no such  movie found exception");
		Movie movie = movieRepository.findById(movieId)
				.orElseThrow(() -> new NoSuchMovieFoundException("No Such Movie Found Of Such Id:"));
		return convertEntityToDto(movie);
	}

}
