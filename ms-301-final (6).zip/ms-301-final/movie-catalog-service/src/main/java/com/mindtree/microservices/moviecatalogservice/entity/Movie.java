package com.mindtree.microservices.moviecatalogservice.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Movie {
	@Id
	private String movieId;
	@Column(unique=true)
	private String movieName;
	private String actors;
	private String plot;
	private int rating;
	private byte poster;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="movie_id")
	private List<Review> reviews=new ArrayList<Review>();
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Movie(String movieId, String movieName, String actors, String plot, int rating, byte poster,
			List<Review> reviews) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.actors = actors;
		this.plot = plot;
		this.rating = rating;
		this.poster = poster;
		this.reviews = reviews;
	}


	public String getMovieId() {
		return movieId;
	}
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getActors() {
		return actors;
	}
	public void setActors(String actors) {
		this.actors = actors;
	}
	public String getPlot() {
		return plot;
	}
	public void setPlot(String plot) {
		this.plot = plot;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	public byte getPoster() {
		return poster;
	}
	public void setPoster(byte poster) {
		this.poster = poster;
	}


	public List<Review> getReviews() {
		return reviews;
	}


	public void setReviews(List<Review> reviews) {
		this.reviews = reviews;
	}
	
	
	

}
