package com.mindtree.microservices.moviecatalogservice.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Review {
	@Id
	private String reviewerId;
	private String reviewDetails;
	public Review() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Review(String reviewerId, String reviewDetails) {
		super();
		this.reviewerId = reviewerId;
		this.reviewDetails = reviewDetails;
	}
	public String getReviewerId() {
		return reviewerId;
	}
	public void setReviewerId(String reviewerId) {
		this.reviewerId = reviewerId;
	}
	public String getReviewDetails() {
		return reviewDetails;
	}
	public void setReviewDetails(String reviewDetails) {
		this.reviewDetails = reviewDetails;
	}
	

}
