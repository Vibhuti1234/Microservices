package com.mindtree.zuulgateway.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class ZullController {
	@GetMapping(value = "get/urls")
	public List<String> runningServicesUrlsList() {
		List<String> urls = new ArrayList<String>();
		String a = "movie-catalog-service=> http://localhost:8762/movie-catalog/swagger-ui.html";
		String b = "booking-service=>http://localhost:8762/booking/swagger-ui.html";
		String c = "user-service=>http://localhost:8762/user/swagger-ui.html";
		String d = "search-service=>http://localhost:8762/search/swagger-ui.html";
		urls.add(a);
		urls.add(b);
		urls.add(c);
		urls.add(d);
		return urls;
	}

}
