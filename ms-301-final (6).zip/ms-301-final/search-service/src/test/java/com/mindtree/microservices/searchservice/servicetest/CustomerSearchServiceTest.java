package com.mindtree.microservices.searchservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.searchservice.dto.CustomerDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsCustomerDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.EsCustomerDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.impl.CustomerSearchServiceImpl;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoCustomerFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchCustomerFoundException;
import com.mindtree.microservices.searchservice.proxy.CustomerSearchServiceProxy;

@SpringBootTest
public class CustomerSearchServiceTest {
	static String email;
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	CustomerSearchServiceImpl customerSearchServiceImpl;
	@Mock
	private CustomerSearchServiceProxy customerSearchServiceProxy;
	@Mock
	private EsCustomerDtoRepository esCustomerDtoRepository;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(customerSearchServiceImpl).build();
	}

	@Test
	public void fetchAllCustomersTest() {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerDto = new CustomerDto();
		customerDto.setEmail("kumarvibhuti8@gmail.com");
		customerDto.setPhoneNumber("9140169184");
		customerDtos.add(customerDto);
		Mockito.when(customerSearchServiceProxy.fetchAllCustomers())
				.thenReturn(ResponseEntity.status(HttpStatus.OK).body(customerDtos));
		List<EsCustomerDto> esCustomerDtos = new ArrayList<>();
		EsCustomerDto esCustomerDto = new EsCustomerDto(customerDto);
		esCustomerDtos.add(esCustomerDto);
		Collection<EsCustomerDto> customers = esCustomerDtos;
		Iterable<EsCustomerDto> iterable = customers;
		Mockito.when(esCustomerDtoRepository.findAll()).thenReturn(iterable);
		try {
			customerSearchServiceImpl.fetchAllCustomers().forEach(i -> {
				email = i.getEmail();
			});
		} catch (NoCustomerFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("kumarvibhuti8@gmail.com", email);
		assertNotEquals("kumarvibhuti9@gmail.com", email);

	}

	@Test(expected = NoCustomerFoundException.class)
	public void fetchAllCustomersTestForException() throws NoCustomerFoundException {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerDto = new CustomerDto();
		customerDto.setEmail("kumarvibhuti8@gmail.com");
		customerDto.setPhoneNumber("9140169184");
		Mockito.when(customerSearchServiceProxy.fetchAllCustomers())
				.thenReturn(ResponseEntity.status(HttpStatus.OK).body(customerDtos));
		List<EsCustomerDto> esCustomerDtos = new ArrayList<>();
		EsCustomerDto esCustomerDto = new EsCustomerDto(customerDto);
		esCustomerDtos.add(esCustomerDto);
		Collection<EsCustomerDto> customers = esCustomerDtos;
		Iterable<EsCustomerDto> iterable = customers;
		Mockito.when(esCustomerDtoRepository.findAll()).thenReturn(iterable);
		customerSearchServiceImpl.fetchAllCustomers();

	}

	@Test
	public void fetchCustomerByEmailTest() {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerDto = new CustomerDto();
		String email = "kumarvibhuti8@gmail.com";
		customerDto.setEmail("kumarvibhuti8@gmail.com");
		customerDto.setPhoneNumber("9140169184");
		customerDtos.add(customerDto);
		Mockito.when(customerSearchServiceProxy.fetchAllCustomers())
				.thenReturn(ResponseEntity.status(HttpStatus.OK).body(customerDtos));
		EsCustomerDto esCustomerDto = new EsCustomerDto(customerDto);
		Mockito.when(esCustomerDtoRepository.findById(Mockito.any())).thenReturn(Optional.of(esCustomerDto));
		try {
			assertEquals("kumarvibhuti8@gmail.com", customerSearchServiceImpl.fetchCustomerByEmail(email).getEmail());
			assertEquals("9140169184", customerSearchServiceImpl.fetchCustomerByEmail(email).getPhoneNumber());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test(expected = NoCustomerFoundException.class)
	public void fetchCustomerByEmailTestForException() throws MovieCatalogServiceApplicationException {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerDto = new CustomerDto();
		String email = "kumarvibhuti8@gmail.com";
		customerDto.setEmail("kumarvibhuti8@gmail.com");
		customerDto.setPhoneNumber("9140169184");
		Mockito.when(customerSearchServiceProxy.fetchAllCustomers())
				.thenReturn(ResponseEntity.status(HttpStatus.OK).body(customerDtos));
		EsCustomerDto esCustomerDto = new EsCustomerDto(customerDto);
		Mockito.when(esCustomerDtoRepository.findById(Mockito.any())).thenReturn(Optional.of(esCustomerDto));

		customerSearchServiceImpl.fetchCustomerByEmail(email);

	}
	@Test(expected = NoSuchCustomerFoundException.class)
	public void fetchCustomerByEmailTestForException2() throws MovieCatalogServiceApplicationException {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerDto = new CustomerDto();
		String email = "kumarvibhuti8@gmail.com";
		customerDto.setEmail("kumarvibhuti8@gmail.com");
		customerDto.setPhoneNumber("9140169184");
		customerDtos.add(customerDto);
		Mockito.when(customerSearchServiceProxy.fetchAllCustomers())
				.thenReturn(ResponseEntity.status(HttpStatus.OK).body(customerDtos));
		customerSearchServiceImpl.fetchCustomerByEmail(email);

	}

}
