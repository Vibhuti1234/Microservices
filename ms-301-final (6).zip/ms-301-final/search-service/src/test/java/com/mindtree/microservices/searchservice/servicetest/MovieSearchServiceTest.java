package com.mindtree.microservices.searchservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.searchservice.dto.MovieDto;
import com.mindtree.microservices.searchservice.dto.ResponseDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsMovieDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.EsMovieDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.impl.MovieSearchServiceImpl;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoMovieFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchMovieFoundException;
import com.mindtree.microservices.searchservice.proxy.SearchServiceProxy;

@SpringBootTest
public class MovieSearchServiceTest {
	static String movieId;
	static String movieName;
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	MovieSearchServiceImpl movieSearchServiceImpl;
	@Mock
	private EsMovieDtoRepository esMovieDtoRepository;
	@Mock
	private SearchServiceProxy searchServiceProxy;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(movieSearchServiceImpl).build();
	}

	@Test
	public void fetchAllMoviesTest() {
		List<MovieDto> movieDtos = new ArrayList<MovieDto>();
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("Movie1");
		movieDtos.add(movieDto);
		ResponseDto<List<MovieDto>> response = new ResponseDto<List<MovieDto>>(movieDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllMovies())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EsMovieDto> esMovieDtos = new ArrayList<>();
		EsMovieDto esMovieDto = new EsMovieDto(movieDto);
		esMovieDtos.add(esMovieDto);
		Collection<EsMovieDto> result = esMovieDtos;
		Iterable<EsMovieDto> iterable = result;
		Mockito.when(esMovieDtoRepository.findAll()).thenReturn(iterable);
		try {
			movieSearchServiceImpl.fetchAllMovies().forEach(i -> {
				movieId = i.getMovieId();
				movieName = i.getMovieName();
			});
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("M1", movieId);
		assertEquals("Movie1", movieName);

	}

	@Test(expected = NoMovieFoundException.class)
	public void fetchAllMoviesTestForException() throws MovieCatalogServiceApplicationException {
		List<MovieDto> movieDtos = new ArrayList<MovieDto>();
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("Movie1");
		ResponseDto<List<MovieDto>> response = new ResponseDto<List<MovieDto>>(movieDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllMovies())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<EsMovieDto> esMovieDtos = new ArrayList<>();
		EsMovieDto esMovieDto = new EsMovieDto(movieDto);
		esMovieDtos.add(esMovieDto);
		Collection<EsMovieDto> result = esMovieDtos;
		Iterable<EsMovieDto> iterable = result;
		Mockito.when(esMovieDtoRepository.findAll()).thenReturn(iterable);

		movieSearchServiceImpl.fetchAllMovies();

	}

	@Test
	public void fetchMovieByIdTest() {
		List<MovieDto> movieDtos = new ArrayList<MovieDto>();
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("Movie1");
		movieDtos.add(movieDto);
		ResponseDto<List<MovieDto>> response = new ResponseDto<List<MovieDto>>(movieDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllMovies())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		EsMovieDto esMovieDto = new EsMovieDto(movieDto);

		Mockito.when(esMovieDtoRepository.findById(Mockito.anyString())).thenReturn(Optional.of(esMovieDto));

		try {
			assertEquals("M1", movieSearchServiceImpl.fetchMovieById("M1").getMovieId());
			assertEquals("Movie1", movieSearchServiceImpl.fetchMovieById("M1").getMovieName());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test(expected = NoMovieFoundException.class)
	public void fetchMovieByIdTestForException() throws MovieCatalogServiceApplicationException {
		List<MovieDto> movieDtos = new ArrayList<MovieDto>();
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("Movie1");
		ResponseDto<List<MovieDto>> response = new ResponseDto<List<MovieDto>>(movieDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllMovies())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		EsMovieDto esMovieDto = new EsMovieDto(movieDto);

		Mockito.when(esMovieDtoRepository.findById(Mockito.anyString())).thenReturn(Optional.of(esMovieDto));

		movieSearchServiceImpl.fetchMovieById("M1");

	}

	@Test(expected = NoSuchMovieFoundException.class)
	public void fetchMovieByIdTestForException2() throws MovieCatalogServiceApplicationException {
		List<MovieDto> movieDtos = new ArrayList<MovieDto>();
		MovieDto movieDto = new MovieDto();
		movieDto.setMovieId("M1");
		movieDto.setMovieName("Movie1");
		movieDtos.add(movieDto);
		ResponseDto<List<MovieDto>> response = new ResponseDto<List<MovieDto>>(movieDtos, null,
				"all movies details fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllMovies())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		movieSearchServiceImpl.fetchMovieById("M1");

	}

}
