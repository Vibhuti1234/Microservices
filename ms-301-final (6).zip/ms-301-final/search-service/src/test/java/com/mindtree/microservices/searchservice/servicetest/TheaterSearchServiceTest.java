package com.mindtree.microservices.searchservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.searchservice.dto.ResponseDto;
import com.mindtree.microservices.searchservice.dto.TheatreDto;
import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchTheatreDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.ElasticSearchTheatreDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.impl.TheatreSearchServiceImpl;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoSuchTheatreFoundException;
import com.mindtree.microservices.searchservice.exception.NoTheatreFoundException;
import com.mindtree.microservices.searchservice.proxy.SearchServiceProxy;

@SpringBootTest
public class TheaterSearchServiceTest {
	static String id;
	static String name;

	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	TheatreSearchServiceImpl theatreSearchServiceImpl;
	@Mock
	private SearchServiceProxy searchServiceProxy;
	@Mock
	private ElasticSearchTheatreDtoRepository elasticSearchTheatreDtoRepository;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(theatreSearchServiceImpl).build();
	}

	@Test
	public void fetchAllTheatreTest() {
		List<TheatreDto> theatreDtos = new ArrayList<TheatreDto>();
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		theatreDtos.add(theatreDto);
		ResponseDto<List<TheatreDto>> response = new ResponseDto<List<TheatreDto>>(theatreDtos, null,
				"all theatres fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllTheaters())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<ElasticSearchTheatreDto> elasticSearchTheatreDtos = new ArrayList<>();
		ElasticSearchTheatreDto elasticSearchTheatreDto = new ElasticSearchTheatreDto(theatreDto);
		elasticSearchTheatreDtos.add(elasticSearchTheatreDto);
		Collection<ElasticSearchTheatreDto> result = elasticSearchTheatreDtos;
		Iterable<ElasticSearchTheatreDto> iterable = result;
		Mockito.when(elasticSearchTheatreDtoRepository.findAll()).thenReturn(iterable);
		try {
			theatreSearchServiceImpl.fetchAllTheatre().forEach(i -> {
				this.id = i.getTheatreId();
				this.name = i.getTheatreName();
			});
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals("T1", this.id);
		assertEquals("Theatre1", this.name);

	}

	@Test(expected = NoTheatreFoundException.class)
	public void fetchAllTheatreTestForException() throws MovieCatalogServiceApplicationException {
		List<TheatreDto> theatreDtos = new ArrayList<TheatreDto>();
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		ResponseDto<List<TheatreDto>> response = new ResponseDto<List<TheatreDto>>(theatreDtos, null,
				"all theatres fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllTheaters())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<ElasticSearchTheatreDto> elasticSearchTheatreDtos = new ArrayList<>();
		ElasticSearchTheatreDto elasticSearchTheatreDto = new ElasticSearchTheatreDto(theatreDto);
		elasticSearchTheatreDtos.add(elasticSearchTheatreDto);
		Collection<ElasticSearchTheatreDto> result = elasticSearchTheatreDtos;
		Iterable<ElasticSearchTheatreDto> iterable = result;
		Mockito.when(elasticSearchTheatreDtoRepository.findAll()).thenReturn(iterable);

		theatreSearchServiceImpl.fetchAllTheatre();

	}

	@Test
	public void fetchTheatreByIdTest() {
		List<TheatreDto> theatreDtos = new ArrayList<TheatreDto>();
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		theatreDtos.add(theatreDto);
		ResponseDto<List<TheatreDto>> response = new ResponseDto<List<TheatreDto>>(theatreDtos, null,
				"all theatres fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllTheaters())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ElasticSearchTheatreDto elasticSearchTheatreDto = new ElasticSearchTheatreDto(theatreDto);
		Mockito.when(elasticSearchTheatreDtoRepository.findById(Mockito.any()))
				.thenReturn(Optional.of(elasticSearchTheatreDto));

		try {
			assertEquals("T1", theatreSearchServiceImpl.fetchTheatreById("T1").getTheatreId());
			assertEquals("Theatre1", theatreSearchServiceImpl.fetchTheatreById("T1").getTheatreName());

		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(expected = NoTheatreFoundException.class)
	public void fetchTheatreByIdTestForException() throws MovieCatalogServiceApplicationException {
		List<TheatreDto> theatreDtos = new ArrayList<TheatreDto>();
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		ResponseDto<List<TheatreDto>> response = new ResponseDto<List<TheatreDto>>(theatreDtos, null,
				"all theatres fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllTheaters())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ElasticSearchTheatreDto elasticSearchTheatreDto = new ElasticSearchTheatreDto(theatreDto);
		Mockito.when(elasticSearchTheatreDtoRepository.findById(Mockito.any()))
				.thenReturn(Optional.of(elasticSearchTheatreDto));

		theatreSearchServiceImpl.fetchTheatreById("T1");

	}

	@Test(expected = NoSuchTheatreFoundException.class)
	public void fetchTheatreByIdTestForException2() throws MovieCatalogServiceApplicationException {
		List<TheatreDto> theatreDtos = new ArrayList<TheatreDto>();
		TheatreDto theatreDto = new TheatreDto();
		theatreDto.setTheatreId("T1");
		theatreDto.setTheatreName("Theatre1");
		theatreDtos.add(theatreDto);
		ResponseDto<List<TheatreDto>> response = new ResponseDto<List<TheatreDto>>(theatreDtos, null,
				"all theatres fetched successfully", true);

		try {
			Mockito.when(searchServiceProxy.fetchAllTheaters())
					.thenReturn(ResponseEntity.status(HttpStatus.OK).body(response));
		} catch (MovieCatalogServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		theatreSearchServiceImpl.fetchTheatreById("T1");

	}

}
