  package com.mindtree.microservices.searchservice.dto;

public class MovieDto {

	private String movieId;
	private String movieName;
	private String actors;
	private String plot;
	private int rating;
	private byte poster;
	public MovieDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MovieDto(String movieId, String movieName, String actors, String plot, int rating, byte poster) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.actors = actors;
		this.plot = plot;
		this.rating = rating;
		this.poster = poster;
	}
	public String getMovieId() {
		return movieId;
	}
	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getActors() {
		return actors;
	}
	public void setActors(String actors) {
		this.actors = actors;
	}
	public String getPlot() {
		return plot;
	}
	public void setPlot(String plot) {
		this.plot = plot;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public byte getPoster() {
		return poster;
	}
	public void setPoster(byte poster) {
		this.poster = poster;
	}
	
}
