package com.mindtree.microservices.searchservice.elasticsearchservice;

import java.util.List;

import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchTheatreDto;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoTheatreFoundException;

public interface TheatreSearchService {

	Iterable<ElasticSearchTheatreDto> fetchAllTheatre() throws MovieCatalogServiceApplicationException;

	ElasticSearchTheatreDto fetchTheatreById(String theatreId) throws MovieCatalogServiceApplicationException;

	List<ElasticSearchTheatreDto> fetchTheatreByName(String name)
			throws NoTheatreFoundException, MovieCatalogServiceApplicationException;
}
