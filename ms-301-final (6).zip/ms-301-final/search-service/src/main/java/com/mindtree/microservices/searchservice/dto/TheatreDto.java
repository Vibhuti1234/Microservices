package com.mindtree.microservices.searchservice.dto;

public class TheatreDto {

	 private String theatreId;
	   private String theatreName;
	   
	   private String parkingFacilityAvailable;

	public TheatreDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TheatreDto(String theatreId, String theatreName, String parkingFacilityAvailable) {
		super();
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.parkingFacilityAvailable = parkingFacilityAvailable;
	}

	public String getTheatreId() {
		return theatreId;
	}

	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}

	public String getTheatreName() {
		return theatreName;
	}

	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}

	public String getParkingFacilityAvailable() {
		return parkingFacilityAvailable;
	}

	public void setParkingFacilityAvailable(String parkingFacilityAvailable) {
		this.parkingFacilityAvailable = parkingFacilityAvailable;
	}
	   
	   
}
