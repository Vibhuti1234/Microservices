package com.mindtree.microservices.searchservice.elasticsearchservice.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.ElasticSearchServiceController;
import com.mindtree.microservices.searchservice.dto.CustomerDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsCustomerDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.EsCustomerDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.CustomerSearchService;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoCustomerFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchCustomerFoundException;
import com.mindtree.microservices.searchservice.proxy.CustomerSearchServiceProxy;

@Service
public class CustomerSearchServiceImpl implements CustomerSearchService {
	private static Logger logger = LogManager.getLogger(ElasticSearchServiceController.class);
	@Autowired
	private CustomerSearchServiceProxy customerSearchServiceProxy;
	@Autowired
	private EsCustomerDtoRepository esCustomerDtoRepository;

	@Override
	public Iterable<EsCustomerDto> fetchAllCustomers() throws NoCustomerFoundException {
		// TODO Auto-generated method stub
		List<CustomerDto> customerDtos = customerSearchServiceProxy.fetchAllCustomers().getBody();
		if(customerDtos==null || customerDtos.isEmpty())
		{
			throw new NoCustomerFoundException("No customer details available since no one registered till now!");
		}
		for (CustomerDto customerDto : customerDtos) {

			esCustomerDtoRepository.save(new EsCustomerDto(customerDto));

		}
		return esCustomerDtoRepository.findAll();
	}

	@Override
	public EsCustomerDto fetchCustomerByEmail(String email) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<CustomerDto> customerDtos = customerSearchServiceProxy.fetchAllCustomers().getBody();
		if(customerDtos==null || customerDtos.isEmpty())
		{
			throw new NoCustomerFoundException("No customer details available since no one registered till now!");
		}
		for (CustomerDto customerDto : customerDtos) {

			esCustomerDtoRepository.save(new EsCustomerDto(customerDto));

		}
		logger.warn("if No such customer  email found then it will throw  NoSuchCustomerFoundException!");

		EsCustomerDto esCustomerDto = esCustomerDtoRepository.findById(email)
				.orElseThrow(() -> new NoSuchCustomerFoundException("This Email id is not registered or present!"));
		return esCustomerDto;
	}

}
