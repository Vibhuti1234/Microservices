package com.mindtree.microservices.searchservice.elasticsearch;

import java.util.List;

import javax.persistence.Id;

import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.elasticsearch.annotations.Document;

import com.mindtree.microservices.searchservice.dto.CustomerDto;

@Document(indexName="customer",type="customer")
public class EsCustomerDto {
	@Id
	private String id;
	private String email;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String userName;
	private String userId;
	private List<String> userPreferences;
	public EsCustomerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@PersistenceConstructor
	public EsCustomerDto(String id,String email, String firstName, String lastName, String phoneNumber, String userName,
			String userId, List<String> userPreferences) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.userName = userName;
		this.userId = userId;
		this.userPreferences = userPreferences;
		this.id=id;
	}
	public EsCustomerDto(CustomerDto customerDto) {
	     this.id=customerDto.getEmail();
		this.email = customerDto.getEmail();
		this.firstName = customerDto.getFirstName();
		this.lastName = customerDto.getLastName();
		this.phoneNumber = customerDto.getPhoneNumber();
		this.userName = customerDto.getUserName();
		this.userId = customerDto.getUserId();
		this.userPreferences = customerDto.getUserPreferences();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<String> getUserPreferences() {
		return userPreferences;
	}
	public void setUserPreferences(List<String> userPreferences) {
		this.userPreferences = userPreferences;
	}
	
	

}
