package com.mindtree.microservices.searchservice.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mindtree.microservices.searchservice.dto.BookingDto;

@FeignClient(name="booking-service")
public interface BookingSearchServiceProxy {
	@GetMapping(value="getBookingById/{bookingId}")
	public BookingDto getBookingById(@PathVariable int bookingId) ;
	@GetMapping(value="getAllBookings")
	public List<BookingDto> getAllBookings();

}
