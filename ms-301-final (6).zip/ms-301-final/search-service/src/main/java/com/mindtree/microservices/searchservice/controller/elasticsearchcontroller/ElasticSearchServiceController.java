package com.mindtree.microservices.searchservice.controller.elasticsearchcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchBookingDto;
import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchTheatreDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsCustomerDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsMovieDto;
import com.mindtree.microservices.searchservice.elasticsearch.EsShowsDto;
import com.mindtree.microservices.searchservice.elasticsearchservice.BookingSearchService;
import com.mindtree.microservices.searchservice.elasticsearchservice.CustomerSearchService;
import com.mindtree.microservices.searchservice.elasticsearchservice.MovieSearchService;
import com.mindtree.microservices.searchservice.elasticsearchservice.ShowSearchService;
import com.mindtree.microservices.searchservice.elasticsearchservice.TheatreSearchService;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoCustomerFoundException;

@RestController
@RequestMapping("/")
public class ElasticSearchServiceController {
	@Autowired
	private BookingSearchService bookingSearchService;
	@Autowired
	private TheatreSearchService theatreSearchService;
	@Autowired
	private CustomerSearchService customerSearchService;
	@Autowired
	private ShowSearchService showSearchService;
	@Autowired
	private MovieSearchService movieSearchService;

	@GetMapping(value = "fetch/bookings")
	public ResponseEntity<Iterable<ElasticSearchBookingDto>> getAllBookings()
			throws MovieCatalogServiceApplicationException {
		Iterable<ElasticSearchBookingDto> response = bookingSearchService.getAllBookings();
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	@GetMapping(value = "fetch/booking/{bookingId}")
	public ResponseEntity<ElasticSearchBookingDto> getBookingById(@PathVariable int bookingId)
			throws MovieCatalogServiceApplicationException {
		ElasticSearchBookingDto esBookingDto = bookingSearchService.getBookingById(bookingId);
		return ResponseEntity.status(HttpStatus.OK).body(esBookingDto);

	}

	@GetMapping(value = "fetch/theatres")
	public ResponseEntity<Iterable<ElasticSearchTheatreDto>> fetchAllTheatre()
			throws MovieCatalogServiceApplicationException {
		Iterable<ElasticSearchTheatreDto> response = theatreSearchService.fetchAllTheatre();
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/theatre/{theatreId}")
	public ResponseEntity<ElasticSearchTheatreDto> fetchTheatreById(@PathVariable String theatreId)
			throws MovieCatalogServiceApplicationException {
		ElasticSearchTheatreDto response = theatreSearchService.fetchTheatreById(theatreId);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/customers")
	public ResponseEntity<Iterable<EsCustomerDto>> fetchAllCustomers() throws NoCustomerFoundException {
		Iterable<EsCustomerDto> response = customerSearchService.fetchAllCustomers();
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/customer/{email}")
	public ResponseEntity<EsCustomerDto> fetchCustomerByEmail(@PathVariable String email)
			throws MovieCatalogServiceApplicationException {
		EsCustomerDto response = customerSearchService.fetchCustomerByEmail(email);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/shows")
	public ResponseEntity<Iterable<EsShowsDto>> fetchAllShows() throws MovieCatalogServiceApplicationException {
		Iterable<EsShowsDto> response = showSearchService.fetchAllShows();
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/show/{showId}")
	public ResponseEntity<EsShowsDto> fetcShowById(@PathVariable String showId)
			throws MovieCatalogServiceApplicationException {
		EsShowsDto response = showSearchService.fetchShowById(showId);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/movies")
	public ResponseEntity<Iterable<EsMovieDto>> fetchAllMovies() throws MovieCatalogServiceApplicationException {
		Iterable<EsMovieDto> response = movieSearchService.fetchAllMovies();
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/movie/{movieId}")
	public ResponseEntity<EsMovieDto> fetchMovieById(@PathVariable String movieId)
			throws MovieCatalogServiceApplicationException {

		EsMovieDto response = movieSearchService.fetchMovieById(movieId);

		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/theatre/byname/{name}")
	public ResponseEntity<List<ElasticSearchTheatreDto>> fetchTheatreByName(@PathVariable String name)
			throws MovieCatalogServiceApplicationException {
		List<ElasticSearchTheatreDto> response = theatreSearchService.fetchTheatreByName(name);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

}
