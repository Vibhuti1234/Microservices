package com.mindtree.microservices.searchservice.elasticsearchservice;

import com.mindtree.microservices.searchservice.elasticsearch.EsCustomerDto;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoCustomerFoundException;

public interface CustomerSearchService {

	Iterable<EsCustomerDto> fetchAllCustomers() throws NoCustomerFoundException;

	EsCustomerDto fetchCustomerByEmail(String email) throws MovieCatalogServiceApplicationException;

}
