package com.mindtree.microservices.searchservice.elasticsearch;

import javax.persistence.Id;

import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.elasticsearch.annotations.Document;

import com.mindtree.microservices.searchservice.dto.TheatreDto;
@Document(indexName="theatres",type="theatres")
public class ElasticSearchTheatreDto {
	@Id
	private String id;
	 private String theatreId;
	   private String theatreName;
	   
	   private String parkingFacilityAvailable;

	public ElasticSearchTheatreDto() {
	
		// TODO Auto-generated constructor stub
	}
     @PersistenceConstructor
	public ElasticSearchTheatreDto(String id, String theatreId, String theatreName, String parkingFacilityAvailable) {
		this.id = id;
		this.theatreId = theatreId;
		this.theatreName = theatreName;
		this.parkingFacilityAvailable = parkingFacilityAvailable;
	}
     
	public ElasticSearchTheatreDto(TheatreDto theatreDto) {
		this.id=theatreDto.getTheatreId();
		this.theatreId = theatreDto.getTheatreId();
		this.theatreName = theatreDto.getTheatreName();
		this.parkingFacilityAvailable = theatreDto.getParkingFacilityAvailable();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTheatreId() {
		return theatreId;
	}
	public void setTheatreId(String theatreId) {
		this.theatreId = theatreId;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public String getParkingFacilityAvailable() {
		return parkingFacilityAvailable;
	}
	public void setParkingFacilityAvailable(String parkingFacilityAvailable) {
		this.parkingFacilityAvailable = parkingFacilityAvailable;
	}
     

}
