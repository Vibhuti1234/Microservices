package com.mindtree.microservices.searchservice.elasticsearchservice;

import java.util.List;

import com.mindtree.microservices.searchservice.dto.BookingDto;
import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchBookingDto;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;

public interface BookingSearchService {


	Iterable<ElasticSearchBookingDto> getAllBookings() throws MovieCatalogServiceApplicationException;

	ElasticSearchBookingDto getBookingById(int bookingId) throws MovieCatalogServiceApplicationException;

}
