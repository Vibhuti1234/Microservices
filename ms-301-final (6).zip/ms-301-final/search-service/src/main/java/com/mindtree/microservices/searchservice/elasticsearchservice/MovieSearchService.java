package com.mindtree.microservices.searchservice.elasticsearchservice;

import com.mindtree.microservices.searchservice.elasticsearch.EsMovieDto;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;

public interface MovieSearchService {

	Iterable<EsMovieDto> fetchAllMovies() throws MovieCatalogServiceApplicationException;

	EsMovieDto fetchMovieById(String movieId) throws MovieCatalogServiceApplicationException;

}
