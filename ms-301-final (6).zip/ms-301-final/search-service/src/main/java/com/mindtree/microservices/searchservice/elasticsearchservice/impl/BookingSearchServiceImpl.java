package com.mindtree.microservices.searchservice.elasticsearchservice.impl;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.searchservice.controller.elasticsearchcontroller.ElasticSearchServiceController;
import com.mindtree.microservices.searchservice.dto.BookingDto;
import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchBookingDto;
import com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository.ElasticSearchBookingDtoRepository;
import com.mindtree.microservices.searchservice.elasticsearchservice.BookingSearchService;
import com.mindtree.microservices.searchservice.exception.MovieCatalogServiceApplicationException;
import com.mindtree.microservices.searchservice.exception.NoBookingFoundException;
import com.mindtree.microservices.searchservice.exception.NoSuchBookingFoundException;
import com.mindtree.microservices.searchservice.proxy.BookingSearchServiceProxy;
@Service
public class BookingSearchServiceImpl implements BookingSearchService {
	private static Logger logger = LogManager.getLogger(ElasticSearchServiceController.class);
	@Autowired
	ElasticSearchBookingDtoRepository esBookingDtoRepository;
	@Autowired 
	private BookingSearchServiceProxy bookingSearchServiceProxy;
	
	ElasticSearchBookingDto esBookingDto=new ElasticSearchBookingDto();



	
	public Iterable<ElasticSearchBookingDto> getAllBookings() throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<BookingDto> bookingDtos=bookingSearchServiceProxy.getAllBookings();
		if(bookingDtos==null || bookingDtos.isEmpty())
		{
			throw new NoBookingFoundException("there is no booking done yet so no booking data available!");
		}
		for (BookingDto bookingDto : bookingDtos) {
			esBookingDtoRepository.save(new ElasticSearchBookingDto(bookingDto));
		}
		Iterable<ElasticSearchBookingDto> esBookingDtos =  esBookingDtoRepository.findAll();
		
		return esBookingDtos;
	}

	public  Iterable<ElasticSearchBookingDto> getAllBookingsFallBack()
	
	{
		return null;
	}
	@Override
	public ElasticSearchBookingDto getBookingById(int bookingId) throws MovieCatalogServiceApplicationException {
		// TODO Auto-generated method stub
		List<BookingDto> bookingDtos=bookingSearchServiceProxy.getAllBookings();
		if(bookingDtos==null || bookingDtos.isEmpty())
		{
			throw new NoBookingFoundException("there is no booking done yet so no booking data available!");
		}
		for (BookingDto bookingDto : bookingDtos) {
			esBookingDtoRepository.save(new ElasticSearchBookingDto(bookingDto));
		}
		String id=""+bookingId;
		logger.warn("if No such booking id found then it will throw  NoSuchBookingFoundExceptio!");
		esBookingDto= esBookingDtoRepository.findById(id).orElseThrow(()->new NoSuchBookingFoundException("Booking not found"));
	
		return esBookingDto;
	}

}
