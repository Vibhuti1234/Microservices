package com.mindtree.microservices.searchservice.elasticsearch.elasticsearchrepository;

import java.util.List;

import org.springframework.data.elasticsearch.annotations.Query;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.microservices.searchservice.elasticsearch.ElasticSearchTheatreDto;

@Repository
public interface ElasticSearchTheatreDtoRepository extends ElasticsearchRepository<ElasticSearchTheatreDto, String> {
	@Query("{\"bool\": {\"must\": [{\"match\": {\"theatreName\": \"?0\"}}]}}")
     List<ElasticSearchTheatreDto> searchTheatreByName(String theatreName);
}
