package com.mindtree.microservices.userservice.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.microservices.userservice.dto.BookingDto1;
import com.mindtree.microservices.userservice.dto.CustomerDto;
import com.mindtree.microservices.userservice.entity.Booking;
import com.mindtree.microservices.userservice.entity.Customer;
import com.mindtree.microservices.userservice.exception.InvalidBookingException;
import com.mindtree.microservices.userservice.exception.InvalidEmailException;
import com.mindtree.microservices.userservice.exception.NoBookingFoundException;
import com.mindtree.microservices.userservice.exception.NoCustomerFoundException;
import com.mindtree.microservices.userservice.exception.NoRegisteredCustomerException;
import com.mindtree.microservices.userservice.exception.UserServiceApplicationException;
import com.mindtree.microservices.userservice.proxy.MovieCatalogServiceProxy;
import com.mindtree.microservices.userservice.repository.CustomerRepository;
import com.mindtree.microservices.userservice.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private MovieCatalogServiceProxy movieCatalogServiceProxy;
	@Autowired
	private CustomerRepository customerRepository;
	private ModelMapper modelMapper = new ModelMapper();

	public String customerShowBooking(String email, int bookingId) throws UserServiceApplicationException {
		// TODO Auto-generated method stub

		Customer customer = customerRepository.findById(email).orElseThrow(
				() -> new NoRegisteredCustomerException("You are not an registered customer ,please register!"));
		BookingDto1 bookingDto1 = movieCatalogServiceProxy.getBookingById(bookingId);
		if (bookingDto1 == null) {
			throw new InvalidBookingException("This show booking is not available right now");
		}
		Booking booking = convertDtoToEntity(bookingDto1);
		customer.getBookings().add(booking);
		customerRepository.saveAndFlush(customer);

		return "your booking is successfull";
	}

	public String customerShowBookingFallback(String email, int bookingId) {
		return "unable to reach the server please try again later!";
	}

	private Booking convertDtoToEntity(BookingDto1 bookingDto1) {
		// TODO Auto-generated method stub
		return modelMapper.map(bookingDto1, Booking.class);
	}

	@Override
	public CustomerDto addingCustomerDetails(CustomerDto customerDto) {
		// TODO Auto-generated method stub
		Customer customer = convertDtoToEntity(customerDto);
		customerRepository.save(customer);
		return customerDto;
	}

	private Customer convertDtoToEntity(CustomerDto customerDto) {
		// TODO Auto-generated method stub
		return modelMapper.map(customerDto, Customer.class);
	}

	@Override
	public List<CustomerDto> fetchAllCustomers() throws UserServiceApplicationException {
		// TODO Auto-generated method stub
		List<CustomerDto> customerDtos = customerRepository.findAll().stream()
				.map(customer -> convertEntityToDto(customer)).collect(Collectors.toList());
		if (customerDtos == null || customerDtos.isEmpty()) {
			throw new NoCustomerFoundException("No  data  found since no body had registered");
		}
		return customerDtos;
	}

	private CustomerDto convertEntityToDto(Customer customer) {
		// TODO Auto-generated method stub
		return modelMapper.map(customer, CustomerDto.class);
	}

	@Override
	public CustomerDto fetchCustomerByEmail(String email) throws UserServiceApplicationException {
		// TODO Auto-generated method stub
		Customer customer = customerRepository.findById(email).orElseThrow(
				() -> new NoCustomerFoundException("Please check this email id is not registered yet sighn up now!"));
		return convertEntityToDto(customer);
	}

	@Override
	public List<BookingDto1> fetchAllBookingsByCustomerEmail(String email)
			throws InvalidEmailException, NoBookingFoundException {
		// TODO Auto-generated method stub
		Customer customer = customerRepository.findById(email)
				.orElseThrow(() -> new InvalidEmailException("This email is invalid or unregistered!"));
		List<Booking> bookings = customer.getBookings();
		if (bookings.isEmpty() || bookings == null) {
			throw new NoBookingFoundException("No booking found for this id!");
		}
		List<BookingDto1> bookingDto1s = bookings.stream().map(booking -> convertEntityToDto(booking))
				.collect(Collectors.toList());
		return bookingDto1s;
	}

	private BookingDto1 convertEntityToDto(Booking booking) {
		// TODO Auto-generated method stub
		return modelMapper.map(booking, BookingDto1.class);
	}

}
