package com.mindtree.microservices.userservice.service;

import java.util.List;

import com.mindtree.microservices.userservice.dto.BookingDto1;
import com.mindtree.microservices.userservice.dto.CustomerDto;
import com.mindtree.microservices.userservice.exception.InvalidEmailException;
import com.mindtree.microservices.userservice.exception.NoBookingFoundException;
import com.mindtree.microservices.userservice.exception.UserServiceApplicationException;

public interface UserService {

	String customerShowBooking(String email, int bookingId) throws UserServiceApplicationException;

	CustomerDto addingCustomerDetails(CustomerDto customerDto);

	List<CustomerDto> fetchAllCustomers() throws UserServiceApplicationException;

	CustomerDto fetchCustomerByEmail(String email) throws UserServiceApplicationException;

	List<BookingDto1> fetchAllBookingsByCustomerEmail(String email)
			throws InvalidEmailException, NoBookingFoundException;

}
