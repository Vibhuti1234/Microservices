package com.mindtree.microservices.userservice.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CustomerDto {
	private String email;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String userName;
	private String userId;
	@JsonIgnore
	private List<BookingDto1> bookings = new ArrayList<BookingDto1>();
	private List<String> userPreferences;

	public CustomerDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDto(String email, String firstName, String lastName, String phoneNumber, String userName,
			String userId, List<BookingDto1> bookings, List<String> userPreferences) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.userName = userName;
		this.userId = userId;
		this.bookings = bookings;
		this.userPreferences = userPreferences;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<BookingDto1> getBookings() {
		return bookings;
	}

	public void setBookings(List<BookingDto1> bookings) {
		this.bookings = bookings;
	}

	public List<String> getUserPreferences() {
		return userPreferences;
	}

	public void setUserPreferences(List<String> userPreferences) {
		this.userPreferences = userPreferences;
	}

}
