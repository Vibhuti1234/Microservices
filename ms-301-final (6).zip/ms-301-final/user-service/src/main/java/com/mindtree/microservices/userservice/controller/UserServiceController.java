package com.mindtree.microservices.userservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.microservices.userservice.dto.BookingDto1;
import com.mindtree.microservices.userservice.dto.CustomerDto;
import com.mindtree.microservices.userservice.exception.InvalidEmailException;
import com.mindtree.microservices.userservice.exception.NoBookingFoundException;
import com.mindtree.microservices.userservice.exception.UserServiceApplicationException;
import com.mindtree.microservices.userservice.service.UserService;

@RestController
@RequestMapping("/api/book")
public class UserServiceController {

	@Autowired
	private UserService userService;

	@PostMapping(value = "adding/customer/details")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<CustomerDto> addingCustomerDetails(@RequestBody CustomerDto customerDto) {
		CustomerDto response = userService.addingCustomerDetails(customerDto);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	@PutMapping(value = "customerShowBooking/{customerEmail}/{bookingId}")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<String> customerShowBooking(@PathVariable String customerEmail, @PathVariable int bookingId)
			throws UserServiceApplicationException {

		String response = userService.customerShowBooking(customerEmail, bookingId);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	@GetMapping(value = "fetch/customers")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<List<CustomerDto>> fetchAllCustomers() throws UserServiceApplicationException {
		List<CustomerDto> response = userService.fetchAllCustomers();
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/customer/{email}")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<CustomerDto> fetchCustomerByEmail(@PathVariable String email)
			throws UserServiceApplicationException {
		CustomerDto response = userService.fetchCustomerByEmail(email);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	@GetMapping(value = "fetch/bookings/{email}")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<List<BookingDto1>> fetchAllBookingsByCustomerEmail(@PathVariable String email)
			throws InvalidEmailException, NoBookingFoundException {
		List<BookingDto1> response = userService.fetchAllBookingsByCustomerEmail(email);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}
	
	

}
