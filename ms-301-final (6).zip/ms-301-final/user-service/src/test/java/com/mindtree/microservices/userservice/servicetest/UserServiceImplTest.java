package com.mindtree.microservices.userservice.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.microservices.userservice.dto.BookingDto1;
import com.mindtree.microservices.userservice.dto.CustomerDto;
import com.mindtree.microservices.userservice.entity.Booking;
import com.mindtree.microservices.userservice.entity.Customer;
import com.mindtree.microservices.userservice.exception.InvalidBookingException;
import com.mindtree.microservices.userservice.exception.InvalidEmailException;
import com.mindtree.microservices.userservice.exception.NoBookingFoundException;
import com.mindtree.microservices.userservice.exception.NoCustomerFoundException;
import com.mindtree.microservices.userservice.exception.NoRegisteredCustomerException;
import com.mindtree.microservices.userservice.exception.UserServiceApplicationException;
import com.mindtree.microservices.userservice.proxy.MovieCatalogServiceProxy;
import com.mindtree.microservices.userservice.repository.CustomerRepository;
import com.mindtree.microservices.userservice.service.impl.UserServiceImpl;

@SpringBootTest
public class UserServiceImplTest {
	@Autowired
	MockMvc mockMvc;
	@InjectMocks
	private UserServiceImpl userServiceImpl;
	@Mock
	private MovieCatalogServiceProxy movieCatalogServiceProxy;
	@Mock
	private CustomerRepository customerRepository;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(userServiceImpl).build();
	}

	@Test
	public void customerShowBookingTest() {
		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));

		BookingDto1 bookingDto1 = new BookingDto1();
		bookingDto1.setBookingId(1);

		Mockito.when(movieCatalogServiceProxy.getBookingById(Mockito.anyInt())).thenReturn(bookingDto1);

		try {
			assertNotNull(userServiceImpl.customerShowBooking("kumarvibhuti8@gmail.com", 1));
		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test(expected = NoRegisteredCustomerException.class)
	public void customerShowBookingTestForException() throws UserServiceApplicationException {
		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");

		BookingDto1 bookingDto1 = new BookingDto1();
		bookingDto1.setBookingId(1);

		Mockito.when(movieCatalogServiceProxy.getBookingById(Mockito.anyInt())).thenReturn(bookingDto1);

		userServiceImpl.customerShowBooking("kumarvibhuti8@gmail.com", 1);

	}

	@Test(expected = InvalidBookingException.class)
	public void customerShowBookingTestForException2() throws UserServiceApplicationException {
		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));

		BookingDto1 bookingDto1 = null;

		Mockito.when(movieCatalogServiceProxy.getBookingById(Mockito.anyInt())).thenReturn(bookingDto1);

		userServiceImpl.customerShowBooking("kumarvibhuti8@gmail.com", 1);

	}

	@Test
	public void addingCustomerDetails() {
		CustomerDto customerdto = new CustomerDto();
		customerdto.setEmail("kumarvibhuti8@gmail.com");
		customerdto.setUserName("Vibhuti123");
		assertEquals("kumarvibhuti8@gmail.com", userServiceImpl.addingCustomerDetails(customerdto).getEmail());
		assertEquals("Vibhuti123", userServiceImpl.addingCustomerDetails(customerdto).getUserName());

	}

	@Test
	public void fetchAllCustomers() {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerdto = new CustomerDto();
		customerdto.setEmail("kumarvibhuti8@gmail.com");
		customerdto.setUserName("Vibhuti123");
		customerDtos.add(customerdto);
		List<Customer> customers = new ArrayList<Customer>();
		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		customers.add(customer);
		Mockito.when(customerRepository.findAll()).thenReturn(customers);
		try {
			assertEquals("kumarvibhuti8@gmail.com", userServiceImpl.fetchAllCustomers().get(0).getEmail());
			assertEquals("Vibhuti123", userServiceImpl.fetchAllCustomers().get(0).getUserName());

		} catch (UserServiceApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test(expected = NoCustomerFoundException.class)
	public void fetchAllCustomersForException() throws UserServiceApplicationException {
		List<CustomerDto> customerDtos = new ArrayList<CustomerDto>();
		CustomerDto customerdto = new CustomerDto();
		customerdto.setEmail("kumarvibhuti8@gmail.com");
		customerdto.setUserName("Vibhuti123");

		List<Customer> customers = new ArrayList<Customer>();
		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		Mockito.when(customerRepository.findAll()).thenReturn(customers);

		userServiceImpl.fetchAllCustomers();

	}

	@Test
	public void fetchCustomerByEmail() throws UserServiceApplicationException {

		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));

		assertEquals("kumarvibhuti8@gmail.com", userServiceImpl.fetchCustomerByEmail("xyz").getEmail());
		assertEquals("Vibhuti123", userServiceImpl.fetchCustomerByEmail("xyz").getUserName());

	}

	@Test(expected = NoCustomerFoundException.class)
	public void fetchCustomerByEmailForException() throws UserServiceApplicationException {

		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");

		userServiceImpl.fetchCustomerByEmail("xyz");

	}

	@Test
	public void fetchAllBookingsByCustomerEmail() throws UserServiceApplicationException {

		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		List<Booking> bookings = new ArrayList<>();
		Booking booking = new Booking();
		booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		bookings.add(booking);
		customer.setBookings(bookings);
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		assertEquals(1, userServiceImpl.fetchAllBookingsByCustomerEmail("hhh").get(0).getBookingId());
		assertEquals(1123, userServiceImpl.fetchAllBookingsByCustomerEmail("hhh").get(0).getConfirmationNumber());

	}

	@Test(expected = InvalidEmailException.class)
	public void fetchAllBookingsByCustomerEmailForException() throws UserServiceApplicationException {

		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		List<Booking> bookings = new ArrayList<>();
		Booking booking = new Booking();
		booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		bookings.add(booking);
		customer.setBookings(bookings);
		userServiceImpl.fetchAllBookingsByCustomerEmail("hhh");

	}

	@Test(expected = NoBookingFoundException.class)
	public void fetchAllBookingsByCustomerEmailForException2() throws UserServiceApplicationException {

		Customer customer = new Customer();
		customer.setEmail("kumarvibhuti8@gmail.com");
		customer.setUserName("Vibhuti123");
		List<Booking> bookings = new ArrayList<>();
		Booking booking = new Booking();
		booking.setBookingId(1);
		booking.setConfirmationNumber(1123);
		customer.setBookings(bookings);
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));

		userServiceImpl.fetchAllBookingsByCustomerEmail("hhh");

	}

}
